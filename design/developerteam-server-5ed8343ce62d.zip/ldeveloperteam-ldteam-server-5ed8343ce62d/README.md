## Web API criada para o aplicativo do LDTeam

Esse projeto foi criado para fornecer informações necessárias ao aplicativo "**LDTeam**" da empresa **LDSoft**.

---

**Equipe responsável**

*Pasta Azul*  
**1.** Rafael Silveira de Souza  
**2.** Carolina de Medeiros Pereira  
**3.** Rodrigo Lessa de Souza Rodrigues  