USE [LDTeam];
GO
INSERT INTO [dbo].[TIPOS_NOTIFICACOES]
([Codigo],
 [Nome]
)
VALUES
('felicitacoes',
 'Felicita��es de anivers�rio'
);
GO