USE [LDTeam];
GO
INSERT INTO [dbo].[COLABORADORES]
([IdEmpresa],
 [FotoUrl],
 [Nome],
 [DataAniversario],
 [Celular],
 [Ramal],
 [IdentificadorPonto],
 [Email],
 [Ativo],
 [Departamento]
)
VALUES
 (1,'mamirato.jpg','M�rcia Maria Vairo Amirato','1972-05-11','21997262269','207',13,'mamirato@ldsoft.com.br',1,null)
,(1,'snogueira.jpg','Susane Dos Reis Nogueira','1984-05-09','21999737239','214',20,'snogueira@ldsoft.com.br',1,null)
,(1,'pcarey.jpg','Pablo Carey Fiaux Rodrigues','1981-02-22','21988932202','222',24,'pcarey@ldsoft.com.br',1,null)
,(1,'asilva.jpg','Allan Santos da Silva','1991-06-13','21970251709','224',29,'asilva@ldsoft.com.br',1,null)
,(1,'roliveira.jpg','Roger Carvalho de Oliveira','1987-02-10','21993109996','245',31,'roliveira@ldsoft.com.br',1,null)
,(1,'cbarroso.jpg','Catherine Siqueira Barroso','1988-09-20','2196112929','225',42,'cbarroso@ldsoft.com.br',1,null)
,(1,'alago.jpg','Antonieta Regina Silva do Lago','1988-06-14','21990862396','231',45,'alago@ldsoft.com.br',1,null)
,(1,'efranca.jpg','Elaine Passos Gomes de Fran�a','1987-07-12','21974347713','227',50,'efranca@ldsoft.com.br',1,null)
,(1,'mbomfim.jpg','Max Muller da Silva Bomfim','1983-01-26','21982623598','231',54,'mbomfim@ldsoft.com.br',1,null)
,(1,'rlessa.jpg','Rodrigo Lessa de Souza Rodrigues','1971-10-23','21988997240','213',57,'rlessa@ldsoft.com.br',1,null)
,(1,'tscotelaro.jpg','Thaylane Pieruccini Scotelaro','1992-02-02','21968313614','211',58,'tscotelaro@ldsoft.com.br',1,null)
,(1,'vmarques.jpg','Vinicius Luiz Arthur Marques','1984-05-28','21987700101','215',62,'vmarques@ldsoft.com.br',1,null)
,(1,'cpereira.jpg','Carolina de Medeiros Pereira','1991-07-02','21988272215','214',65,'cpereira@ldsoft.com.br',1,null)
,(1,'lescaler.jpg','Lilian Cardoso Martos Escaler','1978-04-14','11940162993','',66,'lescaler@ldsoft.com.br',1,null)
,(1,'betdsilva.jpg','Bet�nia Daniel da Silva','1981-09-10','21980823950','',70,'betdsilva@gmail.com',1,null)
,(1,'lbarcellos.jpg','Leticia Balbino Barcellos','1990-12-20','21980814686','224',71,'lbarcellos@ldsoft.com.br',1,null)
,(1,'jmartins.jpg','Johnathan Freitas Martins','1992-01-07','21969903289','226',72,'jmartins@ldsoft.com.br',1,null)
,(1,'fsander.jpg','Felipe Sander','1991-11-25','21976446262','223',78,'fsander@ldsoft.com.br',1,null)
,(1,'msantos.jpg','Monique Olimpio dos Santos','1989-11-10','21980176356','243',79,'msantos@ldsoft.com.br',1,null)
,(1,'bcosta.jpg','Bruno Costa Antonio','1988-05-23','21985649956','250',84,'bcosta@ldsoft.com.br',1,null)
,(1,'mqueiroz.jpg','Michelle Queiroz Dias Cardoso','1983-02-28','21991301067','242',90,'mqueiroz@ldsoft.com.br',1,null)
,(1,'cferreira.jpg','Carla Peres Ferreira','1987-01-17','21992204121','229',91,'cferreira@ldsoft.com.br',1,null)
,(1,'brangel.jpg','Bernardo Rodrigues Rangel','1978-01-11','21998716594','221',92,'brangel@ldsoft.com.br',1,null)
,(1,'lleorde.jpg','Leonardo da Silva Leorde','1977-05-24','21982067410','218',93,'lleorde@ldsoft.com.br',1,null)
,(1,'wsantos.jpg','Williams Rafael Pituba dos Santos','1992-08-21','21980927742','252',95,'wsantos@ldsoft.com.br',1,null)
,(1,'rsouza.jpg','Rafael Silveira de Souza','1991-08-08','21988386286','251',100,'rsouza@ldsoft.com.br',1,null)
,(1,'jmamede.jpg','Jonatas de Souza Mamede','1989-07-23','21992039884','215',102,'jmamede@ldsoft.com.br',1,null)
,(1,'pbonfante.jpg','Paulo Felipe Santoro Bonfante','1990-03-31','21980450455','206',104,'pbonfante@ldsoft.com.br',1,null)
,(1,'mfragoso.jpg','Paulo Mauricio Fragoso Maciel','1983-02-26','21972953466','202',105,'mfragoso@ldsoft.com.br',1,null)--
,(1,'sbecker.jpg','Stelio Becker','1986-04-23','21976436868','212',106,'sbecker@ldsoft.com.br',1,null)
,(1,'csantos.jpg','Cl�udio de Souza Santos','1966-07-07','219872136309','205',107,'csantos@ldsoft.com.br',1,null)
,(1,'lvieira.jpg','Leonardo Barreto Vieira','1975-05-01','21964500954','249',108,'lvieira@ldsoft.com.br',1,null)
,(1,'ibonfim.jpg','Isabella Rozendo do Bonfim','1987-05-11','21972863910','240',109,'ibonfim@ldsoft.com.br',1,null)
,(1,'iredlien.jpg','Iasmym Brito Redlien','1995-02-16','21983014700','203',null,'iredlien@ldsoft.com.br',1,'Suporte')
,(1,'jteixeira.jpg','Juliana Machado Teixeira','1997-01-18','21991436353','203',null,'jteixeira@ldsoft.com.br',1,'Suporte')
,(1,'ecaldeira.jpg','Eduardo Henrique da Rocha Caldeira Pinto Amaral','06/02/1988','21999936955','240',null,'ecaldeira@ldsoft.com.br',1,'Marketing e Vendas')
,(1,'hpaulino.jpg','Humberto Paulino','1992-06-18','21979283803','203',null,'hpaulino@ldsoft.com.br',1,'Suporte')
,(1,'gsilva.jpg','Gabriela Gomes da Silva','1996-09-09','21947381110','215',null,'gsilva@ldsoft.com.br',1,'Desenvolvimento')
,(1,'gnascimento.jpg','Geovana do Nascimento Silva','1995-02-22','21974841606','230',110,'gnascimento@ldsoft.com.br',1,null)
,(1,'mlessa.jpg','Marcos Jos� Alves Lessa','1958-11-07','21988495228','228',null,'mlessa@ldsoft.com.br',1,'Administrativo Financeiro')
,(1,'vlourenco.jpg','Vitor Nascimento Louren�o','1995-09-21','21988540345','240',null,'vlourenco@ldsoft.com.br',1,'Desenvolvimento')
,(1,'alau.jpg','Aline de Oliveira Lau','1977-03-30','21984305575','221',111,'alau@ldsoft.com.br',1,null)
,(1,'duffles.jpg','Luiz Corr�a Duffles de Andrade','1963-10-07','','216',null,'duffles@ldsoft.com.br',1,'Diretoria')
,(1,'ltoco.jpg','Leonardo Alves Toco','1974-09-08','','217',null,'ltoco@ldsoft.com.br',1,'Diretoria')
,(1,'besteves.jpg','Breno Esteves da silva','1990-08-07','21981747224','240',112,'besteves@ldsoft.com.br',1,'Marketing e Vendas')
GO