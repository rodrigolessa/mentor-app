USE [LDTeam];
GO
SET IDENTITY_INSERT [dbo].[TIPOS_CONTAS_ACESSOS_TIPOS_CAMPOS] ON;
GO
INSERT INTO [dbo].[TIPOS_CONTAS_ACESSOS_TIPOS_CAMPOS]
([Id],
 [Codigo],
 [Nome]
)
VALUES
(1,
 'text',
 'Texto'
),
(2,
 'datetime',
 'Data'
),
(3,
 'number',
 'N�mero'
),
(4,
 'tel',
 'Celular'
),
(5,
 'email',
 'E-mail'
);
GO
SET IDENTITY_INSERT [dbo].[TIPOS_CONTAS_ACESSOS_TIPOS_CAMPOS] OFF;
GO