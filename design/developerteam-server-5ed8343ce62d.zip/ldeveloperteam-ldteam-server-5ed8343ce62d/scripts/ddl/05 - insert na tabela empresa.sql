USE [LDTeam];
GO
SET IDENTITY_INSERT [dbo].[EMPRESAS] ON;
GO
INSERT INTO [dbo].[EMPRESAS]
([Id],
 [Codigo],
 [Nome],
 [Telefone],
 [LogoUrl],
 [Ativo]
)
VALUES
(1,
 'ldsoft',
 'LDsoft',
 '+55 21 2613-3656',
 'http://home.ldsoft.com.br/wp-content/uploads/2015/07/LDSOFT-60.png',
 1
);
GO
SET IDENTITY_INSERT [dbo].[EMPRESAS] OFF;
GO