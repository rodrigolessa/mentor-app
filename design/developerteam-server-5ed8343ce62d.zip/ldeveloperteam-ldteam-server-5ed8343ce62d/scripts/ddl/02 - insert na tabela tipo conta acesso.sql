USE [LDTeam];
GO
SET IDENTITY_INSERT [dbo].[TIPOS_CONTAS_ACESSOS] ON;
GO
INSERT INTO [dbo].[TIPOS_CONTAS_ACESSOS]
([Id],
 [Nome],
 [LogoUrl],
 [Ativo],
 [DataDesativacao]
)
VALUES
(1,
 'Ticket Restaurante',
 'ticket.png',
 1,
 NULL
),
(2,
 'Ticket Alimenta��o',
 'ticket.png',
 1,
 NULL
),
(3,
 'Riocard',
 'riocard.png',
 1,
 NULL
);
GO
SET IDENTITY_INSERT [dbo].[TIPOS_CONTAS_ACESSOS] OFF;
GO