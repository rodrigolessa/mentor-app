USE [LDTeam];
GO
INSERT INTO [dbo].[TIPOS_CONTAS_ACESSOS_CAMPOS]
([IdTipoContaAcesso],
 [IdTipoContaAcessoTipoCampo],
 [Nome]
)
VALUES
(1,
 3,
 'N�mero do cart�o'
),
(1,
 1,
 'Apelido'
),
(2,
 3,
 'N�mero do cart�o'
),
(2,
 1,
 'Apelido'
),
(3,
 3,
 'N�mero do cart�o'
),
(3,
 1,
 'Apelido'
);
GO