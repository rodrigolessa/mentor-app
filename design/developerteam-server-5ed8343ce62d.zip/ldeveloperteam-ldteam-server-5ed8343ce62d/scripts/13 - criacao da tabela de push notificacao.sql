USE [LDTeam]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[PUSH_NOTIFICACOES](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Titulo] [varchar](50) NOT NULL,
	[Subtitulo] [varchar](50) NULL,
	[Corpo] [varchar](150) NOT NULL,
	[ValorDestino] [varchar](50) NULL,
	[Identificador] [varchar](max) NULL,
	[DataEnvio] [datetime2](7) NOT NULL,
	[EhTodos] [bit] NOT NULL,
	[EhDepartamento] [bit] NOT NULL,
	[EhUsuario] [bit] NOT NULL,
	[EhRecorrente] [bit] NOT NULL,
	[MinutosRecorrente] [int] NOT NULL,
	[Finalizado] [bit] NOT NULL,
 CONSTRAINT [PK_PUSH_NOTIFICACOES] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO


