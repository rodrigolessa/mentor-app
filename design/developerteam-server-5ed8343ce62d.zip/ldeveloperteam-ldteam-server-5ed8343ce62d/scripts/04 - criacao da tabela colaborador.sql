USE [LDTeam]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[COLABORADORES](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[IdEmpresa] [int] NOT NULL,
	[FotoUrl] [varchar](max) NULL,
	[Nome] [varchar](max) NOT NULL,
	[DataAniversario] [datetime] NULL,
	[Celular] [varchar](50) NULL,
	[Ramal] [varchar](50) NULL,
	[Departamento] [varchar](50) NULL,
	[IdentificadorPonto] [varchar](50) NULL,
	[Email] [varchar](max) NULL,
	[Senha] [varchar](max) NULL,
	[TokenPushNotification] [varchar](max) NULL,
	[EhBeta] [bit] NOT NULL,
	[DataCadastro] [datetime2](7) NOT NULL,
	[Ativo] [bit] NOT NULL,
	[DataDesativacao] [datetime2](7) NULL,
 CONSTRAINT [PK_COLABORADORES] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

ALTER TABLE [dbo].[COLABORADORES] ADD  CONSTRAINT [DF_COLABORADORES_EhBeta]  DEFAULT ((0)) FOR [EhBeta]
GO

ALTER TABLE [dbo].[COLABORADORES] ADD  CONSTRAINT [DF_COLABORADORES_DataCadastro]  DEFAULT (getdate()) FOR [DataCadastro]
GO

ALTER TABLE [dbo].[COLABORADORES]  WITH CHECK ADD  CONSTRAINT [FK_COLABORADORES_EMPRESAS] FOREIGN KEY([IdEmpresa])
REFERENCES [dbo].[EMPRESAS] ([Id])
GO

ALTER TABLE [dbo].[COLABORADORES] CHECK CONSTRAINT [FK_COLABORADORES_EMPRESAS]
GO


