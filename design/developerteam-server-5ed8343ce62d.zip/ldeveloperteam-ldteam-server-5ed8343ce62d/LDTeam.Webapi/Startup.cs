﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using LDTeam.Webapi.Authorization;
using LDTeam.Infrastructure.Ldteam;
using LDTeam.Infrastructure.Ponto;
using LDTeam.Webapi.Utilities;
using Swashbuckle.AspNetCore.Swagger;
using Microsoft.Extensions.PlatformAbstractions;
using System.IO;

namespace LDTeam.Webapi
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors(o => o.AddPolicy("MyPolicy", builder =>
            {
                builder.AllowAnyOrigin()
                    .AllowAnyMethod()
                    .AllowAnyHeader();
            }));

            //USANDO CUSTOM TOKEN
            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = CustomAuthOptions.DefaultSchemeName;
                options.DefaultChallengeScheme = CustomAuthOptions.DefaultSchemeName;
            })
            .AddCustomAuth(o => { });

            services.AddEntityFrameworkSqlServer()
                .AddDbContext<PontoContext>(
                    options => options.UseSqlServer(
                        Configuration.GetConnectionString("PontoContext")));

            services.AddEntityFrameworkSqlServer()
                .AddDbContext<LdteamContext>(
                    options => options.UseSqlServer(
                        Configuration.GetConnectionString("LdteamContext")));

            services.AddMvc();

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1",
                    new Info
                    {
                        Title = "LDTeam",
                        Version = "v1",
                        Description = "API Help",
                        Contact = new Contact
                        {
                            Name = "Pasta Azul",
                            Email = "pastaazul@ldsoft.com.br"
                        }
                    });

                var caminhoAplicacao = PlatformServices.Default.Application.ApplicationBasePath;
                var nomeAplicacao = PlatformServices.Default.Application.ApplicationName;
                var caminhoXmlDoc = Path.Combine(caminhoAplicacao, $"{nomeAplicacao}.xml");

                c.IncludeXmlComments(caminhoXmlDoc);
            });
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseAPIErrorHandler();
            }
            else
            {
                app.UseAPIErrorHandler();
                app.UseExceptionHandler();
            }

            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("../swagger/v1/swagger.json", "LDTeam");
            });

            app.UseCors("MyPolicy");
            app.UseAuthentication();
            app.UseMvc();
        }
    }
}
