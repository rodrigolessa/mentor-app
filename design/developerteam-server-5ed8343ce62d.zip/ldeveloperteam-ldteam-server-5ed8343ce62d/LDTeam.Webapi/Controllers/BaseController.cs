﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using LDTeam.Application.Models.Response;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using LDTeam.Infrastructure.Ldteam.Entities;

namespace LDTeam.Webapi.Controllers
{
    public class BaseController : Controller
    {
        protected BaseResponse<Colaborador> ObterColaboradorRequest()
        {
            return (BaseResponse<Colaborador>)Request.HttpContext.Items.Where(c => c.Key.ToString() == "colaborador").Select(c => c.Value).FirstOrDefault();
        }
    }
}
