using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using LDTeam.Application.App;
using LDTeam.Webapi.Authorization;
using LDTeam.Application.Models.Response;
using Microsoft.Extensions.Configuration;
using LDTeam.Application.Models;
using LDTeam.Infrastructure.Ldteam.Entities;

namespace LDTeam.Webapi.Controllers
{
    [Authorize]
    [Route("api/calendario")]
    public class CalendarioController : BaseController
    {
        private readonly IConfiguration _configuration;

        public CalendarioController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet]
        [Route("")]
        public BaseResponse<Calendario> Obter(string dataInicial, string dataFinal)
        {
            BaseResponse<Calendario> cReturn = new BaseResponse<Calendario>();

            using (CalendarioAppService _calendarioAppService = new CalendarioAppService(_configuration))
            {
                BaseResponse<Colaborador> funcionario = ObterColaboradorRequest();

                if (funcionario.Autorizado)
                {
                    _calendarioAppService.ColaboradorLogado = funcionario.Objeto;
                    cReturn = _calendarioAppService.Obter(dataInicial, dataFinal);
                }
                else
                {
                    cReturn.Mensagens = funcionario.Mensagens;
                }

                cReturn.TempoLevado = _calendarioAppService.swTempoRequisicao.Elapsed;
                cReturn.Autorizado = funcionario.Autorizado;
            }

            return cReturn;
        }
    }
}
