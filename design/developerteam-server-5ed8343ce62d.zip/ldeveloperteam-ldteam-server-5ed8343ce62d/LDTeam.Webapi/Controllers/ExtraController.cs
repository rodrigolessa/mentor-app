using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using LDTeam.Application.App;
using LDTeam.Webapi.Authorization;
using LDTeam.Application.Models.Response;
using Microsoft.Extensions.Configuration;
using LDTeam.Infrastructure.Ldteam;
using LDTeam.Infrastructure.Ponto;
using LDTeam.Infrastructure.Ldteam.Entities;
using LDTeam.Application.Models;

namespace LDTeam.Webapi.Controllers
{
    [Authorize]
    [Route("api/extra")]
    public class ExtraController : BaseController
    {
        private readonly IConfiguration _configuration;
        private readonly LdteamContext _ldteamContext;
        private readonly PontoContext _pontoContext;

        public ExtraController(IConfiguration configuration, LdteamContext ldteamContext, PontoContext pontoContext)
        {
            _configuration = configuration;
            _ldteamContext = ldteamContext;
            _pontoContext = pontoContext;
        }

        [HttpGet]
        [Route("pitacos/obterRanking")]
        public BaseResponse<List<PitacosRanking>> PitacosObterRanking()
        {
            BaseResponse<List<PitacosRanking>> rReturn = new BaseResponse<List<PitacosRanking>>();

            using (ExtraAppService _extraAppService = new ExtraAppService(_configuration, _ldteamContext, _pontoContext))
            {
                BaseResponse<Colaborador> funcionario = ObterColaboradorRequest();

                if (funcionario.Autorizado)
                {
                    _extraAppService.ColaboradorLogado = funcionario.Objeto;
                    rReturn = _extraAppService.PitacosObterRanking();
                }
                else
                {
                    rReturn.Mensagens = funcionario.Mensagens;
                }

                rReturn.TempoLevado = _extraAppService.swTempoRequisicao.Elapsed;
                rReturn.Autorizado = funcionario.Autorizado;
            }

            return rReturn;
        }

        [HttpGet]
        [Route("pitacos/obterMeusPitacos")]
        public BaseResponse<List<PitacosMeusPitacos>> PitacosObterMeusPitacos(string email, string senha)
        {
            BaseResponse<List<PitacosMeusPitacos>> rReturn = new BaseResponse<List<PitacosMeusPitacos>>();

            using (ExtraAppService _extraAppService = new ExtraAppService(_configuration, _ldteamContext, _pontoContext))
            {
                BaseResponse<Colaborador> funcionario = ObterColaboradorRequest();

                if (funcionario.Autorizado)
                {
                    _extraAppService.ColaboradorLogado = funcionario.Objeto;
                    rReturn = _extraAppService.PitacosObterMeusPitacos(email, senha);
                }
                else
                {
                    rReturn.Mensagens = funcionario.Mensagens;
                }

                rReturn.TempoLevado = _extraAppService.swTempoRequisicao.Elapsed;
                rReturn.Autorizado = funcionario.Autorizado;
            }

            return rReturn;
        }

        [HttpGet]
        [Route("pitacos/salvarPlacar")]
        public BaseResponse<bool> PitacosSalvarPlacar(string email, string senha, string id, string placarA, string placarB)
        {
            BaseResponse<bool> rReturn = new BaseResponse<bool>();

            using (ExtraAppService _extraAppService = new ExtraAppService(_configuration, _ldteamContext, _pontoContext))
            {
                BaseResponse<Colaborador> funcionario = ObterColaboradorRequest();

                if (funcionario.Autorizado)
                {
                    _extraAppService.ColaboradorLogado = funcionario.Objeto;
                    rReturn = _extraAppService.PitacosSalvarPlacar(email, senha, id, placarA, placarB);
                }
                else
                {
                    rReturn.Mensagens = funcionario.Mensagens;
                }

                rReturn.TempoLevado = _extraAppService.swTempoRequisicao.Elapsed;
                rReturn.Autorizado = funcionario.Autorizado;
            }

            return rReturn;
        }
    }
}
