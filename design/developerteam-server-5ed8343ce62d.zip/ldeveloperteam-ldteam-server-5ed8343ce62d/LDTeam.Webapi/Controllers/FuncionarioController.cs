using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using LDTeam.Application.App;
using LDTeam.Webapi.Authorization;
using LDTeam.Application.Models.Response;
using Microsoft.Extensions.Configuration;
using LDTeam.Infrastructure.Ldteam;
using LDTeam.Webapi.Request;
using LDTeam.Application.Models;
using LDTeam.Infrastructure.Ponto;
using LDTeam.Infrastructure.Ldteam.Entities;
using LDTeam.Webapi.Utilities;

namespace LDTeam.Webapi.Controllers
{
    [Authorize]
    [Route("api/funcionario")]
    public class FuncionarioController : BaseController
    {
        private readonly IConfiguration _configuration;
        private readonly LdteamContext _ldteamContext;
        private readonly PontoContext _pontoContext;

        public FuncionarioController(IConfiguration configuration, LdteamContext ldteamContext, PontoContext pontoContext)
        {
            _configuration = configuration;
            _ldteamContext = ldteamContext;
            _pontoContext = pontoContext;
        }

        [HttpGet]
        [Route("")]
        public BaseResponse<Colaborador> Obter()
        {
            return ObterColaboradorRequest();
        }

        [HttpGet]
        [Route("listar")]
        public BaseResponse<List<Colaborador>> Listar()
        {
            BaseResponse<List<Colaborador>> cReturn = new BaseResponse<List<Colaborador>>();

            using (FuncionarioAppService _funcionarioAppService = new FuncionarioAppService(_configuration, _ldteamContext, _pontoContext))
            {
                BaseResponse<Colaborador> funcionario = ObterColaboradorRequest();

                if (funcionario.Autorizado)
                {
                    _funcionarioAppService.ColaboradorLogado = funcionario.Objeto;
                    cReturn = _funcionarioAppService.Listar();
                }
                else
                {
                    cReturn.Mensagens = funcionario.Mensagens;
                }

                cReturn.TempoLevado = _funcionarioAppService.swTempoRequisicao.Elapsed;
                cReturn.Autorizado = funcionario.Autorizado;
            }

            return cReturn;
        }

        [HttpGet]
        [Route("listarAniversariantes")]
        public BaseResponse<List<Colaborador>> ListarAniversariantes()
        {
            BaseResponse<List<Colaborador>> cReturn = new BaseResponse<List<Colaborador>>();

            using (FuncionarioAppService _funcionarioAppService = new FuncionarioAppService(_configuration, _ldteamContext, _pontoContext))
            {
                BaseResponse<Colaborador> funcionario = ObterColaboradorRequest();

                if (funcionario.Autorizado)
                {
                    _funcionarioAppService.ColaboradorLogado = funcionario.Objeto;
                    cReturn = _funcionarioAppService.ListarAniversariantes();
                }
                else
                {
                    cReturn.Mensagens = funcionario.Mensagens;
                }

                cReturn.TempoLevado = _funcionarioAppService.swTempoRequisicao.Elapsed;
                cReturn.Autorizado = funcionario.Autorizado;
            }

            return cReturn;
        }

        [HttpGet]
        [Route("listarFelicitacoes")]
        public BaseResponse<List<Felicitacao>> ListarFelicitacoes()
        {
            BaseResponse<List<Felicitacao>> cReturn = new BaseResponse<List<Felicitacao>>();

            using (FuncionarioAppService _funcionarioAppService = new FuncionarioAppService(_configuration, _ldteamContext, _pontoContext))
            {
                BaseResponse<Colaborador> funcionario = ObterColaboradorRequest();

                if (funcionario.Autorizado)
                {
                    _funcionarioAppService.ColaboradorLogado = funcionario.Objeto;
                    cReturn = _funcionarioAppService.ListarFelicitacoes();
                }
                else
                {
                    cReturn.Mensagens = funcionario.Mensagens;
                }

                cReturn.TempoLevado = _funcionarioAppService.swTempoRequisicao.Elapsed;
                cReturn.Autorizado = funcionario.Autorizado;
            }

            return cReturn;
        }

        [HttpPost]
        [Route("adicionarFelicitacao")]
        public BaseResponse<bool> AdicionarFelicitacao([FromBody]Felicitacao felicitacao)
        {
            BaseResponse<bool> fReturn = new BaseResponse<bool>();

            using (FuncionarioAppService _funcionarioAppService = new FuncionarioAppService(_configuration, _ldteamContext, _pontoContext))
            {
                BaseResponse<Colaborador> funcionario = ObterColaboradorRequest();

                if (funcionario.Autorizado)
                {
                    _funcionarioAppService.ColaboradorLogado = funcionario.Objeto;
                    fReturn = _funcionarioAppService.AdicionarFelicitacao(felicitacao);
                }
                else
                {
                    fReturn.Mensagens = funcionario.Mensagens;
                }

                fReturn.TempoLevado = _funcionarioAppService.swTempoRequisicao.Elapsed;
                fReturn.Autorizado = funcionario.Autorizado;
            }

            return fReturn;
        }

        [HttpPost]
        [Route("salvarTokenPushNotification")]
        public BaseResponse<bool> SalvarTokenPushNotification([FromBody]string token)
        {
            BaseResponse<bool> fReturn = new BaseResponse<bool>();

            using (FuncionarioAppService _funcionarioAppService = new FuncionarioAppService(_configuration, _ldteamContext, _pontoContext))
            {
                BaseResponse<Colaborador> funcionario = ObterColaboradorRequest();

                if (funcionario.Autorizado)
                {
                    _funcionarioAppService.ColaboradorLogado = funcionario.Objeto;
                    fReturn = _funcionarioAppService.SalvarTokenPushNotification(token);
                }
                else
                {
                    fReturn.Mensagens = funcionario.Mensagens;
                }

                fReturn.TempoLevado = _funcionarioAppService.swTempoRequisicao.Elapsed;
                fReturn.Autorizado = funcionario.Autorizado;
            }

            return fReturn;
        }

        [HttpGet]
        [Route("obterTiposContasAcessos")]
        public BaseResponse<List<TipoContaAcesso>> ObterTiposContasAcessos()
        {
            BaseResponse<List<TipoContaAcesso>> tReturn = new BaseResponse<List<TipoContaAcesso>>();

            using (FuncionarioAppService _funcionarioAppService = new FuncionarioAppService(_configuration, _ldteamContext, _pontoContext))
            {
                BaseResponse<Colaborador> funcionario = ObterColaboradorRequest();

                if (funcionario.Autorizado)
                {
                    _funcionarioAppService.ColaboradorLogado = funcionario.Objeto;
                    tReturn = _funcionarioAppService.ObterTiposContasAcessos();
                }
                else
                {
                    tReturn.Mensagens = funcionario.Mensagens;
                }

                tReturn.TempoLevado = _funcionarioAppService.swTempoRequisicao.Elapsed;
                tReturn.Autorizado = funcionario.Autorizado;
            }

            return tReturn;
        }

        [HttpPost]
        [Route("adicionarContaAcesso")]
        public BaseResponse<bool> AdicionarContaAcesso([FromBody]AdicionarContaAcessoRequest request)
        {
            BaseResponse<bool> aReturn = new BaseResponse<bool>();

            using (FuncionarioAppService _funcionarioAppService = new FuncionarioAppService(_configuration, _ldteamContext, _pontoContext))
            {
                BaseResponse<Colaborador> funcionario = ObterColaboradorRequest();

                if (funcionario.Autorizado)
                {
                    _funcionarioAppService.ColaboradorLogado = funcionario.Objeto;
                    aReturn = _funcionarioAppService.AdicionarContaAcesso(request);
                }
                else
                {
                    aReturn.Mensagens = funcionario.Mensagens;
                }

                aReturn.TempoLevado = _funcionarioAppService.swTempoRequisicao.Elapsed;
                aReturn.Autorizado = funcionario.Autorizado;
            }

            return aReturn;
        }

        [HttpDelete]
        [Route("removerContaAcesso")]
        public BaseResponse<bool> RemoverContaAcesso(int id)
        {
            BaseResponse<bool> rReturn = new BaseResponse<bool>();

            using (FuncionarioAppService _funcionarioAppService = new FuncionarioAppService(_configuration, _ldteamContext, _pontoContext))
            {
                BaseResponse<Colaborador> funcionario = ObterColaboradorRequest();

                if (funcionario.Autorizado)
                {
                    _funcionarioAppService.ColaboradorLogado = funcionario.Objeto;
                    rReturn = _funcionarioAppService.RemoverContaAcesso(id);
                }
                else
                {
                    rReturn.Mensagens = funcionario.Mensagens;
                }

                rReturn.TempoLevado = _funcionarioAppService.swTempoRequisicao.Elapsed;
                rReturn.Autorizado = funcionario.Autorizado;
            }

            return rReturn;
        }

        [HttpGet]
        [Route("obterContasAcesso")]
        public BaseResponse<List<ColaboradorContaAcesso>> ObterContasAcesso()
        {
            BaseResponse<List<ColaboradorContaAcesso>> cReturn = new BaseResponse<List<ColaboradorContaAcesso>>();

            using (FuncionarioAppService _funcionarioAppService = new FuncionarioAppService(_configuration, _ldteamContext, _pontoContext))
            {
                BaseResponse<Colaborador> funcionario = ObterColaboradorRequest();

                if (funcionario.Autorizado)
                {
                    _funcionarioAppService.ColaboradorLogado = funcionario.Objeto;
                    cReturn = _funcionarioAppService.ObterContasAcesso();
                }
                else
                {
                    cReturn.Mensagens = funcionario.Mensagens;
                }

                cReturn.TempoLevado = _funcionarioAppService.swTempoRequisicao.Elapsed;
                cReturn.Autorizado = funcionario.Autorizado;
            }

            return cReturn;
        }

        [HttpGet]
        [Route("obterCartoesTicket")]
        public BaseResponse<List<CartaoTicket>> ObterCartoesTicket()
        {
            BaseResponse<List<CartaoTicket>> cReturn = new BaseResponse<List<CartaoTicket>>();

            using (FuncionarioAppService _funcionarioAppService = new FuncionarioAppService(_configuration, _ldteamContext, _pontoContext))
            {
                BaseResponse<Colaborador> funcionario = ObterColaboradorRequest();

                if (funcionario.Autorizado)
                {
                    _funcionarioAppService.ColaboradorLogado = funcionario.Objeto;
                    cReturn = _funcionarioAppService.ObterCartoesTicket();
                }
                else
                {
                    cReturn.Mensagens = funcionario.Mensagens;
                }

                cReturn.TempoLevado = _funcionarioAppService.swTempoRequisicao.Elapsed;
                cReturn.Autorizado = funcionario.Autorizado;
            }

            return cReturn;
        }

        [HttpDelete]
        [Route("removerCartaoTicket")]
        public BaseResponse<bool> RemoverCartaoTicket(string numero)
        {
            BaseResponse<bool> rReturn = new BaseResponse<bool>();

            using (FuncionarioAppService _funcionarioAppService = new FuncionarioAppService(_configuration, _ldteamContext, _pontoContext))
            {
                BaseResponse<Colaborador> funcionario = ObterColaboradorRequest();

                if (funcionario.Autorizado)
                {
                    _funcionarioAppService.ColaboradorLogado = funcionario.Objeto;
                    rReturn = _funcionarioAppService.RemoverCartaoTicket(numero);
                }
                else
                {
                    rReturn.Mensagens = funcionario.Mensagens;
                }

                rReturn.TempoLevado = _funcionarioAppService.swTempoRequisicao.Elapsed;
                rReturn.Autorizado = funcionario.Autorizado;
            }

            return rReturn;
        }

        [HttpGet]
        [Route("enviarFeedback")]
        public BaseResponse<bool> EnviarFeedback(string mensagem)
        {
            BaseResponse<bool> rReturn = new BaseResponse<bool>();
            BaseResponse<Colaborador> funcionario = ObterColaboradorRequest();

            if (funcionario.Autorizado)
            {
                if (string.IsNullOrWhiteSpace(mensagem))
                {
                    rReturn.Mensagens = new List<string>() { "A mensagem � obrigat�ria!" };
                }
                else
                {
                    EmailHelper email = new EmailHelper("desenvolvimento", false, 25, "apol@ldsoft.com.br", "");
                    rReturn.Objeto = email.Enviar(funcionario.Objeto.Email, "pastaazul@ldsoft.com.br", "Feedback", mensagem.Replace("\r\n", "<br />").Replace("&", "&amp;"));
                }
            }
            else
            {
                rReturn.Mensagens = funcionario.Mensagens;
            }

            rReturn.Autorizado = funcionario.Autorizado;

            return rReturn;
        }

        [HttpPost]
        [Route("cadastrarCartaoTicket")]
        public BaseResponse<bool> CadastrarCartaoTicket(string numero, string tipo)
        {
            BaseResponse<bool> cReturn = new BaseResponse<bool>();

            using (FuncionarioAppService _funcionarioAppService = new FuncionarioAppService(_configuration, _ldteamContext, _pontoContext))
            {
                BaseResponse<Colaborador> funcionario = ObterColaboradorRequest();

                if (funcionario.Autorizado)
                {
                    _funcionarioAppService.ColaboradorLogado = funcionario.Objeto;
                    cReturn = _funcionarioAppService.CadastrarCartaoTicket(numero, tipo);
                }
                else
                {
                    cReturn.Mensagens = funcionario.Mensagens;
                }

                cReturn.TempoLevado = _funcionarioAppService.swTempoRequisicao.Elapsed;
                cReturn.Autorizado = funcionario.Autorizado;
            }

            return cReturn;
        }

        [HttpGet]
        [Route("obterCartaoRiocard")]
        public BaseResponse<Riocard> ObterCartaoRiocard(string email, string senha, string cartao)
        {
            BaseResponse<Riocard> rReturn = new BaseResponse<Riocard>();

            using (FuncionarioAppService _funcionarioAppService = new FuncionarioAppService(_configuration, _ldteamContext, _pontoContext))
            {
                BaseResponse<Colaborador> funcionario = ObterColaboradorRequest();

                if (funcionario.Autorizado)
                {
                    _funcionarioAppService.ColaboradorLogado = funcionario.Objeto;
                    rReturn = _funcionarioAppService.ObterCartaoRiocard(email, senha, cartao);
                }
                else
                {
                    rReturn.Mensagens = funcionario.Mensagens;
                }

                rReturn.TempoLevado = _funcionarioAppService.swTempoRequisicao.Elapsed;
                rReturn.Autorizado = funcionario.Autorizado;
            }

            return rReturn;
        }
    }
}
