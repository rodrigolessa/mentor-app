using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using LDTeam.Application.App;
using LDTeam.Webapi.Authorization;
using LDTeam.Application.Models.Response;
using Microsoft.Extensions.Configuration;
using LDTeam.Infrastructure.Ponto;
using LDTeam.Infrastructure.Ldteam.Entities;
using LDTeam.Application.Models;

namespace LDTeam.Webapi.Controllers
{
    [Authorize]
    [Route("api/ponto")]
    public class PontoController : BaseController
    {
        private readonly IConfiguration _configuration;
        private readonly PontoContext _pontoContext;

        public PontoController(IConfiguration configuration, PontoContext pontoContext)
        {
            _configuration = configuration;
            _pontoContext = pontoContext;
        }

        [HttpGet]
        [Route("obterSaldo")]
        public BaseResponse<SaldoResponse> ObterSaldo()
        {
            BaseResponse<SaldoResponse> sReturn = new BaseResponse<SaldoResponse>();

            using (PontoAppService _pontoAppService = new PontoAppService(_configuration, _pontoContext))
            {
                BaseResponse<Colaborador> funcionario = ObterColaboradorRequest();

                if (funcionario.Autorizado)
                {
                    _pontoAppService.ColaboradorLogado = funcionario.Objeto;
                    sReturn = _pontoAppService.ObterSaldo();
                }
                else
                {
                    sReturn.Mensagens = funcionario.Mensagens;
                }

                sReturn.TempoLevado = _pontoAppService.swTempoRequisicao.Elapsed;
                sReturn.Autorizado = funcionario.Autorizado;
            }

            return sReturn;
        }

        [HttpGet]
        [Route("obterErrosPonto")]
        public BaseResponse<List<ErroPonto>> ObterErrosPonto()
        {
            BaseResponse<List<ErroPonto>> eReturn = new BaseResponse<List<ErroPonto>>();

            using (PontoAppService _pontoAppService = new PontoAppService(_configuration, _pontoContext))
            {
                BaseResponse<Colaborador> funcionario = ObterColaboradorRequest();

                if (funcionario.Autorizado)
                {
                    _pontoAppService.ColaboradorLogado = funcionario.Objeto;
                    eReturn = _pontoAppService.ObterErrosPonto();
                }
                else
                {
                    eReturn.Mensagens = funcionario.Mensagens;
                }

                eReturn.TempoLevado = _pontoAppService.swTempoRequisicao.Elapsed;
                eReturn.Autorizado = funcionario.Autorizado;
            }

            return eReturn;
        }

        [HttpGet]
        [Route("obterConsumo")]
        public BaseResponse<List<ConsumoPonto>> ObterConsumo(string dataInicial, string dataFinal)
        {
            BaseResponse<List<ConsumoPonto>> cReturn = new BaseResponse<List<ConsumoPonto>>();

            using (PontoAppService _pontoAppService = new PontoAppService(_configuration, _pontoContext))
            {
                BaseResponse<Colaborador> funcionario = ObterColaboradorRequest();

                if (funcionario.Autorizado)
                {
                    _pontoAppService.ColaboradorLogado = funcionario.Objeto;
                    cReturn = _pontoAppService.ObterConsumo(dataInicial, dataFinal);
                }
                else
                {
                    cReturn.Mensagens = funcionario.Mensagens;
                }

                cReturn.TempoLevado = _pontoAppService.swTempoRequisicao.Elapsed;
                cReturn.Autorizado = funcionario.Autorizado;
            }

            return cReturn;
        }
    }
}
