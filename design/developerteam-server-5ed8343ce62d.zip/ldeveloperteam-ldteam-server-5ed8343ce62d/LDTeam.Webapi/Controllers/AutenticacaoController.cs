﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using LDTeam.Application.Models.Response;
using Microsoft.AspNetCore.Authorization;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.IdentityModel.Tokens;
using System.Security.Claims;
using Microsoft.Extensions.Configuration;
using LDTeam.Application.App;
using LDTeam.Webapi.Request;
using LDTeam.Infrastructure.Ldteam;
using LDTeam.Infrastructure.Ponto;
using LDTeam.Infrastructure.Ldteam.Entities;

namespace LDTeam.Webapi.Controllers
{
    [AllowAnonymous]
    [Route("api/autenticacao")]
    public class AutenticacaoController : BaseController
    {
        private readonly IConfiguration _configuration;
        private readonly LdteamContext _ldteamContext;
        private readonly PontoContext _pontoContext;

        public AutenticacaoController(IConfiguration configuration, LdteamContext ldteamContext, PontoContext pontoContext)
        {
            _configuration = configuration;
            _ldteamContext = ldteamContext;
            _pontoContext = pontoContext;
        }

        [HttpPost]
        [Route("efetuarLogin")]
        public BaseResponse<ColaboradorResponse> EfetuarLogin([FromBody]FuncionarioRequest request)
        {
            BaseResponse<ColaboradorResponse> uReturn = new BaseResponse<ColaboradorResponse>();

            using (AutenticacaoAppService _autenticacaoAppService = new AutenticacaoAppService(_configuration, _ldteamContext, _pontoContext))
            {
                _autenticacaoAppService.CodigoEmpresa = this.Request.Headers["CodigoEmpresa"];
                uReturn = _autenticacaoAppService.EfetuarLogin(request.Usuario, request.Senha, request.Sistema);
                uReturn.TempoLevado = _autenticacaoAppService.swTempoRequisicao.Elapsed;
                uReturn.Autorizado = uReturn.Mensagens.Count == 0;
            }

            return uReturn;
        }
    }
}
