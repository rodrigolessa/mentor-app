using System.Collections.Generic;
using System.Net.Http;
using System;
using System.Web;
using LDTeam.Application.Models.Response;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Authentication;

namespace LDTeam.Webapi.Authorization
{
    public class CustomAuthOptions : AuthenticationSchemeOptions
    {
        public static string DefaultSchemeName = "";
        public static string BearerSchemeName = "bearer";
        public static string BasicSchemeName = "basic";
    }
}