using System.Collections.Generic;
using System.Net.Http;
using System;
using System.Web;
using LDTeam.Application.Models.Response;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Logging;
using System.Text.Encodings.Web;
using System.Security.Principal;
using Microsoft.Net.Http.Headers;
using LDTeam.Infrastructure.Ldteam;
using LDTeam.Application.App;
using Microsoft.Extensions.Configuration;
using LDTeam.Infrastructure.Ponto;
using LDTeam.Infrastructure.Ldteam.Entities;

namespace LDTeam.Webapi.Authorization
{
    internal class CustomAuthHandler : AuthenticationHandler<CustomAuthOptions>
    {
        private const string HttpContextName = "MS_HttpContext";
        private const string RemoteEndpointMessage = "System.ServiceModel.Channels.RemoteEndpointMessageProperty";
        private const string OwinContext = "MS_OwinContext";
        private readonly IConfiguration _configuration;
        private readonly LdteamContext _ldteamContext;
        private readonly PontoContext _pontoContext;

        public CustomAuthHandler(IOptionsMonitor<CustomAuthOptions> options, ILoggerFactory logger, UrlEncoder encoder, ISystemClock clock, IConfiguration configuration, LdteamContext ldteamContext, PontoContext pontoContext) : base(options, logger, encoder, clock)
        {
            _configuration = configuration;
            _ldteamContext = ldteamContext;
            _pontoContext = pontoContext;
        }

        protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
        {
            BaseResponse<Colaborador> cReturn = new BaseResponse<Colaborador>();
            string scheme = string.Empty;
            string token = string.Empty;

            if (!string.IsNullOrWhiteSpace(Request.Headers[HeaderNames.Authorization]))
            {
                var authToken = Request.Headers[HeaderNames.Authorization].ToString();

                if (authToken.Split(' ').Length > 1)
                {
                    scheme = authToken.Split(' ')[0].Trim();
                    token = authToken.Split(' ')[1].Trim();
                }
                else
                {
                    token = authToken.Trim();
                }
            }

            if (!string.IsNullOrWhiteSpace(token))
            {
                using (AutenticacaoAppService _autenticacaoAppService = new AutenticacaoAppService(_configuration, _ldteamContext, _pontoContext))
                {
                    _autenticacaoAppService.CodigoEmpresa = this.Request.Headers["CodigoEmpresa"];
                    cReturn = _autenticacaoAppService.VerificarToken(token);
                    cReturn.TempoLevado = _autenticacaoAppService.swTempoRequisicao.Elapsed;
                }
            }
            else
            {
                cReturn.Mensagens.Add("Colaborador não encontrado!");
            }

            cReturn.Autorizado = cReturn.Mensagens.Count == 0;

            Request.HttpContext.Items.Add("colaborador", cReturn);

            var user = new GenericPrincipal(new GenericIdentity("User"), null);
            var ticket = new AuthenticationTicket(user, new AuthenticationProperties(), CustomAuthOptions.DefaultSchemeName);

            await Task.Delay(0);

            return AuthenticateResult.Success(ticket);
        }

        protected string GetHostAdress(HttpRequestMessage request)
        {
            if (request.Properties.ContainsKey(HttpContextName))
            {
                dynamic ctx = request.Properties[HttpContextName];

                if (ctx != null)
                {
                    return ctx.Request.UserHostAddress;
                }
            }

            if (request.Properties.ContainsKey(RemoteEndpointMessage))
            {
                dynamic remoteEndpoint = request.Properties[RemoteEndpointMessage];

                if (remoteEndpoint != null)
                {
                    return remoteEndpoint.Address;
                }
            }

            if (request.Properties.ContainsKey(OwinContext))
            {
                dynamic ctx = request.Properties[OwinContext];

                if (ctx != null)
                {
                    return ctx.Request.RemoteIpAddress;
                }
            }

            return "0.0.0.0";
        }

        protected string GetHostName(HttpRequestMessage request)
        {
            if (request != null)
            {
                if (request.Properties.ContainsKey(HttpContextName))
                {
                    dynamic ctx = request.Properties[HttpContextName];

                    if (ctx != null)
                    {
                        return ctx.Request.UserHostName;
                    }
                }

                return "Não encontrado";
            }
            else
            {
                return "Não encontrado";
            }
        }
    }
}