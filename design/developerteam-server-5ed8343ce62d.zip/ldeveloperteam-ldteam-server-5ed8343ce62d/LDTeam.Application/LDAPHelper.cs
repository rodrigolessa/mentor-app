using System;
using System.Collections.Generic;
using System.Linq;
using Novell.Directory.Ldap;
using LDTeam.Application.Models;

namespace LDTeam.Application
{
    public class LDAPHelper
    {
        public static DateTime DataUltimaAtualizacaoFuncionarios { get; set; }
        public static DateTime DataUltimaAtualizacaoGrupos { get; set; }
        public static List<Funcionario> Funcionarios { get; set; }
        public static HashSet<string> Grupos { get; set; }
        private static ILdapConnection ConexaoAD { get; set; }

        public static void AtualizarListaFuncionarios()
        {
            /*if (Grupos == null || DataUltimaAtualizacaoGrupos.AddMinutes(60) < DateTime.Now)
            {
                Grupos = SearchForGroup("");
                DataUltimaAtualizacaoGrupos = DateTime.Now;
            }*/

            if (Funcionarios == null || DataUltimaAtualizacaoFuncionarios.AddMinutes(60 * 12) < DateTime.Now)
            {
                //Funcionarios = SearchForUser(Grupos);
                Funcionarios = SearchForUser();
                DataUltimaAtualizacaoFuncionarios = DateTime.Now;
            }
        }

        public static List<Funcionario> ObterFuncionarios(string usuario, string senha, string host, string dominio, int porta)
        {
            ConexaoAD = GetConnection(usuario, senha, host, dominio, porta);

            AtualizarListaFuncionarios();

            List<Funcionario> fReturn = new List<Funcionario>();

            foreach (var item in Funcionarios)
            {
                fReturn.Add(new Funcionario(item));
            }

            return fReturn;
        }

        // public static bool Validar(string usuario, string senha)
        // {
        //     AtualizarListaFuncionarios();
        //     LdapConnection ldapConn = new LdapConnection() { SecureSocketLayer = true };

        //     try
        //     {
        //         if (Funcionarios != null)
        //         {
        //             Funcionario funcionario = Funcionarios.FirstOrDefault(f => f.SAM.ToUpper() == usuario.ToUpper());

        //             if (funcionario != null)
        //             {
        //                 ldapConn.Connect("jupiter", 3269);
        //                 ldapConn.Bind(funcionario.DN, senha);

        //                 if (ldapConn.Bound)
        //                 {
        //                     return true;
        //                 }
        //             }
        //         }
        //     }
        //     catch (LdapException)
        //     {
        //     }

        //     return false;
        // }

        // public static Funcionario ObterFuncionario(string SAM)
        // {
        //     return Funcionarios.FirstOrDefault(c => SAM != null && c.SAM != null && c.SAM.ToUpper() == SAM.ToUpper());
        // }

        public static bool Validar(string usuario, string senha, string host, string dominio, int porta)
        {
            LdapConnection ldapConn = new LdapConnection() { SecureSocketLayer = true };

            try
            {
                ldapConn.Connect(host, porta);
                ldapConn.Bind(dominio + @"\" + usuario, senha);

                if (ldapConn.Bound)
                {
                    return true;
                }
            }
            catch (LdapException)
            {
            }

            return false;
        }

        static ILdapConnection GetConnection(string usuario, string senha, string host, string dominio, int porta)
        {
            LdapConnection ldapConn = new LdapConnection() { SecureSocketLayer = true };

            try
            {
                ldapConn.Connect(host, porta);
                ldapConn.Bind(dominio + @"\" + usuario, senha);
            }
            catch (LdapException e)
            {
                Console.WriteLine("Error: " + e.LdapErrorMessage);
                ldapConn.Bind(null, null);
            }

            return ldapConn;
        }

        static HashSet<string> SearchForGroup(string groupName)
        {
            var groups = new HashSet<string>();

            var searchBase = string.Empty;
            var filter = $"(objectClass=group)(cn={groupName})";
            var search = ConexaoAD.Search(searchBase, LdapConnection.SCOPE_SUB, filter, null, false);

            while (search.HasMore())
            {
                LdapEntry nextEntry = null;
                try
                {
                    nextEntry = search.Next();
                }
                catch (LdapException e)
                {
                    Console.WriteLine("Error: " + e.LdapErrorMessage);
                    // Exception is thrown, go for next entry
                    continue;
                }

                Console.WriteLine("\n" + nextEntry.DN);
                LdapAttributeSet attributeSet = nextEntry.getAttributeSet();
                System.Collections.IEnumerator ienum = attributeSet.GetEnumerator();

                while (ienum.MoveNext())
                {
                    LdapAttribute attribute = (LdapAttribute)ienum.Current;
                    string attributeName = attribute.Name;
                    string attributeVal = attribute.StringValue;
                    Console.WriteLine(attributeName + "value:" + attributeVal);
                }

                groups.Add(nextEntry.DN);
                var childGroups = GetChildren(string.Empty, nextEntry.DN);
                foreach (var child in childGroups)
                {
                    groups.Add(child);
                }
            }

            return groups;
        }

        static HashSet<string> GetChildren(string searchBase, string groupDn, string objectClass = "group")
        {
            var listNames = new HashSet<string>();

            var filter = $"(&(objectClass={objectClass})(memberOf={groupDn}))";
            var search = ConexaoAD.Search(searchBase, LdapConnection.SCOPE_SUB, filter, null, false);

            while (search.HasMore())
            {
                var nextEntry = search.Next();
                listNames.Add(nextEntry.DN);
                var children = GetChildren(string.Empty, nextEntry.DN);
                foreach (var child in children)
                {
                    listNames.Add(child);
                }
            }

            return listNames;
        }

        static List<Funcionario> SearchForUser(HashSet<string> groups = null)
        {
            var funcionarios = new List<Funcionario>();

            foreach (var item in groups)
            {
                string groupFilter = $"(memberOf=CN=USUARIOS,OU=USUARIOS,DC=lcdinterno,DC=com,DC=br)";
                var searchBase = "";
                string filter = $"(&(objectClass=person){groupFilter})";
                var search = ConexaoAD.Search(searchBase, LdapConnection.SCOPE_SUB, filter, null, false);

                while (search.HasMore())
                {
                    var nextEntry = search.Next();
                    var email = (nextEntry.getAttribute("mail") != null ? nextEntry.getAttribute("mail").StringValue : "");
                    var nome = (nextEntry.getAttribute("name") != null ? nextEntry.getAttribute("name").StringValue : "");
                    var ramal = (nextEntry.getAttribute("TELEPHONENUMBER") != null ? nextEntry.getAttribute("TELEPHONENUMBER").StringValue : "Sem Ramal");
                    var ativo = (nextEntry.getAttribute("useraccountcontrol") != null ? nextEntry.getAttribute("useraccountcontrol").StringValue : "");
                    var sam = (nextEntry.getAttribute("SAMACCOUNTNAME") != null ? nextEntry.getAttribute("SAMACCOUNTNAME").StringValue : "");
                    var ultimoLogin = (nextEntry.getAttribute("LASTLOGONTIMESTAMP") != null ? nextEntry.getAttribute("LASTLOGONTIMESTAMP").StringValue : "");
                    var dataUltimoLogin = ultimoLogin != "" ? new TimeSpan(Convert.ToInt64(ultimoLogin)) : TimeSpan.MinValue;

                    if (!funcionarios.Any(u => u.Email == email) && ativo != "514")
                    {
                        Funcionario funcionario = new Funcionario();
                        funcionario.Email = email;
                        funcionario.Nome = nome;
                        funcionario.Ramal = ramal;
                        funcionario.DN = nextEntry.DN;
                        funcionario.SAM = sam;

                        funcionarios.Add(funcionario);
                    }
                }
            }

            return funcionarios;
        }

        static List<Funcionario> SearchForUser()
        {
            var funcionarios = new List<Funcionario>();

            string filter = $"(&(objectCategory=person)(objectClass=user))";
            string[] tudo = new string[] { "*", "thumbnailPhoto", "jpegPhoto", "employeeID", "mail", "useraccountcontrol" };
            LdapConstraints lc = new LdapConstraints();
            var search = ConexaoAD.Search(string.Empty, LdapConnection.SCOPE_SUB, filter, tudo, false);

            while (search.HasMore())
            {
                var nextEntry = search.Next();

                var email = (nextEntry.getAttribute("mail") != null ? nextEntry.getAttribute("mail").StringValue : "");
                var nome = (nextEntry.getAttribute("name") != null ? nextEntry.getAttribute("name").StringValue : "");
                var ramal = (nextEntry.getAttribute("TELEPHONENUMBER") != null ? nextEntry.getAttribute("TELEPHONENUMBER").StringValue : "Sem Ramal");
                var ativo = (nextEntry.getAttribute("useraccountcontrol") != null ? nextEntry.getAttribute("useraccountcontrol").StringValue : "");
                var sam = (nextEntry.getAttribute("SAMACCOUNTNAME") != null ? nextEntry.getAttribute("SAMACCOUNTNAME").StringValue : "");
                var ultimoLogin = (nextEntry.getAttribute("LASTLOGONTIMESTAMP") != null ? nextEntry.getAttribute("LASTLOGONTIMESTAMP").StringValue : "");
                var thumbnailPhoto = (nextEntry.getAttribute("thumbnailPhoto") != null ? nextEntry.getAttribute("thumbnailPhoto").StringValue : "");
                var jpegPhoto = (nextEntry.getAttribute("jpegPhoto") != null ? nextEntry.getAttribute("jpegPhoto").StringValue : "");
                var employeeID = (nextEntry.getAttribute("employeeID") != null ? nextEntry.getAttribute("employeeID").StringValue : "");

                if (!funcionarios.Any(u => u.Email == email) && ativo != "514")
                {
                    Funcionario funcionario = new Funcionario();
                    funcionario.Email = email;
                    funcionario.Nome = nome;
                    funcionario.Ramal = ramal;
                    funcionario.DN = nextEntry.DN;
                    funcionario.SAM = sam;

                    funcionarios.Add(funcionario);
                }
            }

            return funcionarios;
        }
    }
}
