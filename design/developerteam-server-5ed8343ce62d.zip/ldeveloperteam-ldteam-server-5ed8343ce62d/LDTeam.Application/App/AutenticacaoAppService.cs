using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using LDTeam.Application.Models.Response;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.IdentityModel.Tokens;
using System.Security.Claims;
using Microsoft.Extensions.Configuration;
using System.Text;
using System.Security.Cryptography;
using LDTeam.Infrastructure.Ldteam;
using LDTeam.Infrastructure.Ldteam.Entities;
using LDTeam.Application.Models;
using Microsoft.EntityFrameworkCore;
using LDTeam.Infrastructure.Ponto;

namespace LDTeam.Application.App
{
    public class AutenticacaoAppService : BaseAppService
    {
        private readonly IConfiguration _configuration;
        private readonly LdteamContext _ldteamContext;
        private readonly PontoContext _pontoContext;

        public AutenticacaoAppService()
        {
            swTempoRequisicao.Start();
        }

        public AutenticacaoAppService(IConfiguration configuration, LdteamContext ldteamContext, PontoContext pontoContext)
        {
            swTempoRequisicao.Start();
            _configuration = configuration;
            _ldteamContext = ldteamContext;
            _pontoContext = pontoContext;
        }

        public BaseResponse<ColaboradorResponse> EfetuarLogin(string usuario, string senha, int sistema)
        {
            BaseResponse<ColaboradorResponse> fReturn = new BaseResponse<ColaboradorResponse>();

            #region validacao

            if (string.IsNullOrWhiteSpace(CodigoEmpresa))
            {
                Resposta.Mensagens.Add("Empresa não informada!");
            }

            if (string.IsNullOrWhiteSpace(usuario))
            {
                Resposta.Mensagens.Add("Informe o usuário!");
            }

            if (string.IsNullOrWhiteSpace(senha))
            {
                Resposta.Mensagens.Add("Informe a senha!");
            }

            #endregion

            if (Resposta.Sucesso)
            {
                Empresa empresa = _ldteamContext.Empresas.Include("EmpresaConfiguracao").FirstOrDefault(e => e.Codigo == CodigoEmpresa);

                if (empresa != null)
                {
                    if (empresa.EmpresaConfiguracao != null)
                    {
                        if (empresa.EmpresaConfiguracao.UsaLoginAD)
                        {
                            if (LDAPHelper.Validar(usuario, senha, empresa.EmpresaConfiguracao.HostAD, empresa.EmpresaConfiguracao.DominioAD, empresa.EmpresaConfiguracao.PortaAD.Value))
                            {
                                var funcionarios = LDAPHelper.ObterFuncionarios(empresa.EmpresaConfiguracao.UsuarioAD, empresa.EmpresaConfiguracao.SenhaAD, empresa.EmpresaConfiguracao.HostAD, empresa.EmpresaConfiguracao.DominioAD, empresa.EmpresaConfiguracao.PortaAD.Value);
                                var colaboradorAD = funcionarios.Where(c => c.SAM.ToUpper() == usuario.ToUpper()).FirstOrDefault();

                                if (colaboradorAD != null)
                                {
                                    Colaborador colaborador = _ldteamContext.Colaboradores.Include("ContasAcessos").Include("ContasAcessos.ContasAcessosDados").Include("ContasAcessos.TipoContaAcesso").Include("ContasAcessos.ContasAcessosDados.TipoContaAcessoCampo").FirstOrDefault(c => c.Email.ToUpper() == colaboradorAD.Email.ToUpper() && c.Ativo);

                                    if (colaborador != null)
                                    {
                                        var ctsAtivo = _ldteamContext.ColaboradoresTokens.Where(c => c.IdColaborador == colaborador.Id && c.Ativo).ToList();
                                        var funcionarioPonto = _pontoContext.Funcionarios.FirstOrDefault(f => f.NumeroFolha == colaborador.IdentificadorPonto);

                                        if (ctsAtivo.Any())
                                        {
                                            foreach (var item in ctsAtivo)
                                            {
                                                if (sistema == item.Sistema || (sistema == 0 && (item.Sistema == 0 || item.Sistema == null)))
                                                {
                                                    item.Ativo = false;
                                                    item.DataDesativacao = DateTime.Now;
                                                }
                                            }

                                            _ldteamContext.SaveChanges();
                                        }

                                        ColaboradorToken ct = new ColaboradorToken
                                        {
                                            IdColaborador = colaborador.Id,
                                            DataCadastro = DateTime.Now,
                                            Ativo = true,
                                            Sistema = sistema,
                                            Token = CriptografarSHA512($"{usuario};{DateTime.Now.ToString("yyyyMMddHHmmssffff")};{Guid.NewGuid().ToString()}")
                                        };

                                        _ldteamContext.ColaboradoresTokens.Add(ct);
                                        _ldteamContext.SaveChanges();

                                        if (funcionarioPonto != null)
                                        {
                                            var departamento = _pontoContext.Departamentos.FirstOrDefault(d => d.Id == funcionarioPonto.IdDepartamento);
                                            colaborador.Departamento = departamento != null ? departamento.Descricao : (colaborador.Departamento ?? "");
                                        }

                                        colaborador.Senha = null;
                                        colaborador.Empresa = null;
                                        colaborador.Notificacoes = null;
                                        colaborador.ContasAcessos = null;

                                        fReturn.Objeto = new ColaboradorResponse
                                        {
                                            Colaborador = colaborador,
                                            Token = ct.Token
                                        };
                                    }
                                    else
                                    {
                                        Resposta.Mensagens.Add("Colaborador não encontrado!");
                                    }
                                }
                                else
                                {
                                    Resposta.Mensagens.Add("Colaborador não encontrado!");
                                }
                            }
                            else
                            {
                                Resposta.Mensagens.Add("Usuário ou senha inválidos!");
                            }
                        }
                        else if (empresa.EmpresaConfiguracao.UsaLoginEmail)
                        {
                            Resposta.Mensagens.Add("Login por e-mail está desativado!");
                        }
                        else
                        {
                            Resposta.Mensagens.Add("Empresa não habilitada para efetuar login!");
                        }
                    }
                    else
                    {
                        Resposta.Mensagens.Add("Configurações da empresa não encontradas!");
                    }
                }
                else
                {
                    Resposta.Mensagens.Add("Empresa não identificada!");
                }
            }

            fReturn.Mensagens = Resposta.Mensagens;

            return fReturn;
        }

        public BaseResponse<Colaborador> VerificarToken(string token)
        {
            BaseResponse<Colaborador> fReturn = new BaseResponse<Colaborador>();

            #region validacao

            if (string.IsNullOrWhiteSpace(CodigoEmpresa))
            {
                Resposta.Mensagens.Add("Empresa não informada!");
            }

            if (string.IsNullOrWhiteSpace(token))
            {
                Resposta.Mensagens.Add("Token nao informado!");
            }

            #endregion

            if (Resposta.Sucesso)
            {
                var ctAtivo = _ldteamContext.ColaboradoresTokens.FirstOrDefault(c => c.Token == token && c.Ativo);

                if (ctAtivo != null)
                {
                    Colaborador colaborador = _ldteamContext.Colaboradores.FirstOrDefault(c => c.Id == ctAtivo.IdColaborador && c.Empresa.Codigo == CodigoEmpresa && c.Ativo);

                    if (colaborador != null)
                    {
                        var funcionarioPonto = _pontoContext.Funcionarios.FirstOrDefault(f => f.NumeroFolha == colaborador.IdentificadorPonto);

                        if (funcionarioPonto != null)
                        {
                            var departamento = _pontoContext.Departamentos.FirstOrDefault(d => d.Id == funcionarioPonto.IdDepartamento);
                            colaborador.Departamento = departamento != null ? departamento.Descricao : (colaborador.Departamento ?? "");
                        }

                        colaborador.Senha = null;
                        colaborador.Empresa = null;
                        colaborador.Notificacoes = null;
                        colaborador.ContasAcessos = null;

                        fReturn.Objeto = colaborador;
                    }
                    else
                    {
                        Resposta.Mensagens.Add("Colaborador não encontrado!");
                    }
                }
                else
                {
                    Resposta.Mensagens.Add("Token não encontrado!");
                }
            }

            fReturn.Mensagens = Resposta.Mensagens;

            return fReturn;
        }

        private static string CriptografarSHA512(string text)
        {
            //string length 128
            var data = Encoding.ASCII.GetBytes(text);
            var hashData = new SHA512Managed().ComputeHash(data);
            var hash = string.Empty;
            foreach (var b in hashData)
                hash += b.ToString("X2");

            return hash;
        }
    }
}