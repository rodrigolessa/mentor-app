using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using HtmlAgilityPack;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Support.UI;
using RestSharp;
using LDTeam.Application.Models;

namespace LDTeam.Application.App
{
    public class RiocardService
    {
        private const string WEBSITE_ANTI_RECAPTCHA = "https://api.anti-captcha.com";
        private const string WEBSITE_KEY_ANTI_RECAPTCHA = "0c41fc7107bc4cd4cbfd3a505b5e7a10";
        private const string WEBSITE_RECAPTCHA = "https://www.cartaoriocard.com.br/minhaconta/login";
        private const string KEY_RECAPTCHA = "6LflTU8UAAAAAMri7RQtZkELFzeglAoxSzRlGp_d";

        private static string ResolverRecaptcha()
        {
            string resposta = string.Empty;

            var client = new RestClient("https://api.anti-captcha.com/createTask");
            var request = new RestRequest(Method.POST);
            request.AddHeader("content-type", "application/json");
            request.AddParameter("application/json", "{\r\n    \"clientKey\":\"" + WEBSITE_KEY_ANTI_RECAPTCHA + "\",\r\n    \"task\":\r\n        {\r\n            \"type\":\"NoCaptchaTaskProxyless\",\r\n            \"websiteURL\":\"" + WEBSITE_RECAPTCHA + "\",\r\n            \"websiteKey\":\"" + KEY_RECAPTCHA + "\"\r\n        }\r\n}", ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);

            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                AntiCaptchaCreateTaskResponse respostaAntiCaptcha = JsonConvert.DeserializeObject<AntiCaptchaCreateTaskResponse>(response.Content);

                if (respostaAntiCaptcha.taskId != 0)
                {
                    while (true)
                    {
                        var clientResult = new RestClient("https://api.anti-captcha.com/getTaskResult");
                        var requestResult = new RestRequest(Method.POST);
                        requestResult.AddHeader("content-type", "application/json");
                        requestResult.AddParameter("application/json", "{\r\n    \"clientKey\":\"" + WEBSITE_KEY_ANTI_RECAPTCHA + "\",\r\n    \"taskId\": " + respostaAntiCaptcha.taskId + "\r\n}", ParameterType.RequestBody);
                        IRestResponse responseResult = clientResult.Execute(requestResult);

                        if (responseResult.StatusCode == System.Net.HttpStatusCode.OK)
                        {
                            AntiCaptchaGetTaskResultResponse respostaAntiCaptchaResult = JsonConvert.DeserializeObject<AntiCaptchaGetTaskResultResponse>(responseResult.Content);

                            if (respostaAntiCaptchaResult.status == "ready" && respostaAntiCaptchaResult.solution != null)
                            {
                                resposta = respostaAntiCaptchaResult.solution.gRecaptchaResponse;
                                break;
                            }
                            else if (respostaAntiCaptchaResult.errorId != 0)
                            {
                                break;
                            }
                            else
                            {

                            }
                        }

                        Thread.Sleep(1000);
                    }
                }
            }

            return resposta;
        }

        public static Riocard ObterCartao(string email, string senha, string cartao)
        {
            Riocard rReturn = null;
            bool erro = false;

            //SERVIDOR
            var capabilities = DesiredCapabilities.Chrome();
            Uri url = new Uri("http://desenvolvimento:4545/wd/hub");
            var driver = new RemoteWebDriver(url, capabilities);

            // TESTE LOCAL
            // var driver = new ChromeDriver();

            driver.Navigate().GoToUrl("https://www.cartaoriocard.com.br/meuextrato/login");

            new WebDriverWait(driver, TimeSpan.FromSeconds(60)).Until(d => ((IJavaScriptExecutor)d).ExecuteScript("return (window.jQuery == null) || jQuery.active == 0").Equals(true) && ((IJavaScriptExecutor)d).ExecuteScript("return document.readyState").Equals("complete"));

            while (driver.Url != "https://www.cartaoriocard.com.br/minhaconta/principal")
            {
                IWebElement loginField = driver.FindElement(By.Name("username"));
                IWebElement passField = driver.FindElement(By.Name("password"));
                IWebElement loginButton = driver.FindElement(By.Id("formLogin"));
                IWebElement gResponseField = driver.FindElement(By.Id("g-recaptcha-response"));
                string gResponse = ResolverRecaptcha();

                loginField.SendKeys(email);
                passField.SendKeys(senha);
                ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].innerText = arguments[1];", gResponseField, gResponse);

                loginButton.Submit();

                new WebDriverWait(driver, TimeSpan.FromSeconds(60)).Until(d => ((IJavaScriptExecutor)d).ExecuteScript("return (window.jQuery == null) || jQuery.active == 0").Equals(true) && ((IJavaScriptExecutor)d).ExecuteScript("return document.readyState").Equals("complete"));

                if (driver.PageSource.Contains("E-mail e senha não conferem."))
                {
                    erro = true;
                    break;
                }
            }

            if (!erro)
            {
                driver.Navigate().GoToUrl("https://www.cartaoriocard.com.br/minhaconta/cartoes/informacoes");
                new WebDriverWait(driver, TimeSpan.FromSeconds(60)).Until(d => ((IJavaScriptExecutor)d).ExecuteScript("return (window.jQuery == null) || jQuery.active == 0").Equals(true) && ((IJavaScriptExecutor)d).ExecuteScript("return document.readyState").Equals("complete"));

                HtmlDocument map = new HtmlDocument();
                map.LoadHtml(driver.PageSource);

                HtmlNode nodeName = map.DocumentNode.SelectNodes("//div[@id='dropdownMenu1']").FirstOrDefault();
                string name = nodeName.InnerText.Replace("\r", "").Replace("\n", "").Replace("Olá, ", "").Trim();

                int cards = map.DocumentNode.SelectNodes("//div[@class='cardH']").Count;

                List<Riocard> rcs = new List<Riocard>();

                for (int i = 0; i < cards; i++)
                {
                    HtmlNode nodeCard = map.DocumentNode.SelectNodes("//div[@class='cardH']/p")[i];
                    string card = nodeCard.InnerHtml.Replace("Cartão: ", "").Replace(".", "").Replace("-", "").Trim();
                    HtmlNode nodeValue = map.DocumentNode.SelectNodes("//div[@class='cardH']/strong")[i];
                    string value = nodeValue.InnerHtml.Replace("Saldo:R$", "").Trim();
                    HtmlNode nodeId = map.DocumentNode.SelectNodes("//input[@name='nrCartao']")[i];
                    string id = nodeId.Attributes["value"].Value.Trim();

                    rcs.Add(new Riocard()
                    {
                        Recharges = new List<RiocardRecharge>(),
                        Extracts = new List<RiocardExtract>(),
                        Name = name,
                        Balance = value,
                        Number = card,
                        Id = id
                    });
                }

                var rc = rcs.OrderByDescending(r => r.Balance.Replace(".", "").Replace(",", "")).FirstOrDefault(c => c.Number == cartao.Replace(".", "").Replace("-", ""));

                if (rc == null)
                {
                    IWebElement exit = driver.FindElement(By.ClassName("exit"));
                    exit.Click();

                    rc.Extracts.Reverse();

                    driver.Dispose();
                    driver = null;

                    return rReturn;
                }

                IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
                js.ExecuteScript("javascript:verExtratoDoCartao('id_" + rc.Id + "');");

                new WebDriverWait(driver, TimeSpan.FromSeconds(60)).Until(ExpectedConditions.ElementExists((By.ClassName("tabelaExtrato"))));
                new WebDriverWait(driver, TimeSpan.FromSeconds(60)).Until(d => ((IJavaScriptExecutor)d).ExecuteScript("return (window.jQuery == null) || jQuery.active == 0").Equals(true) && ((IJavaScriptExecutor)d).ExecuteScript("return document.readyState").Equals("complete"));

                map = new HtmlDocument();
                map.LoadHtml(driver.PageSource);

                HtmlNode nodeRechargesTable = map.DocumentNode.SelectNodes("//table[@class='tabelaExtrato']").FirstOrDefault();

                for (int i = 0; i < nodeRechargesTable.ChildNodes[1].SelectNodes("tr").Count; i++)
                {
                    if (i == 0)
                    {
                        continue;
                    }

                    RiocardRecharge rr = new RiocardRecharge();
                    var item = nodeRechargesTable.ChildNodes[1].SelectNodes("tr")[i];
                    rr.Number = item.SelectNodes("td")[0].InnerText;
                    rr.Value = item.SelectNodes("td")[1].InnerText;
                    rr.Date = item.SelectNodes("td")[2].InnerText;

                    rc.Recharges.Add(rr);
                }

                HtmlNode nodeExtractsTable = map.DocumentNode.SelectNodes("//table[@class='tabelaExtrato']").LastOrDefault();

                for (int i = 0; i < nodeExtractsTable.ChildNodes[1].SelectNodes("tr").Count; i++)
                {
                    if (i == 0)
                    {
                        continue;
                    }

                    RiocardExtract re = new RiocardExtract();
                    var item = nodeExtractsTable.ChildNodes[1].SelectNodes("tr")[i];

                    re.Date = item.SelectNodes("td")[0].InnerText;
                    re.Number = item.SelectNodes("td")[1].InnerText;
                    re.Company = item.SelectNodes("td")[2].InnerText.Replace("  ", " ").Replace(" ", " ").Trim();
                    re.Line = item.SelectNodes("td")[3].InnerText.Replace("  ", " ").Replace("  ", " ").Trim();
                    re.Value = item.SelectNodes("td")[4].InnerText;
                    re.Balance = item.SelectNodes("td")[5].InnerText;

                    rc.Extracts.Add(re);
                }

                IWebElement exitButton = driver.FindElement(By.ClassName("exit"));
                exitButton.Click();

                rc.Extracts.Reverse();

                driver.Dispose();
                driver = null;

                rReturn = rc;
            }

            return rReturn;
        }
    }
}