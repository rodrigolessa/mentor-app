using System;
using System.Collections.Generic;
using System.Linq;
using LDTeam.Application.Models.Response;
using Microsoft.Extensions.Configuration;
using LDTeam.Application.Models;
using LDTeam.Infrastructure.Ldteam;
using LDTeam.Webapi.Request;
using LDTeam.Infrastructure.Ldteam.Entities;
using Microsoft.EntityFrameworkCore;
using LDTeam.Infrastructure.Ponto;

namespace LDTeam.Application.App
{
    public class ExtraAppService : BaseAppService
    {
        private readonly IConfiguration _configuration;
        private readonly LdteamContext _ldteamContext;
        private readonly PontoContext _pontoContext;

        public ExtraAppService()
        {
            swTempoRequisicao.Start();
        }

        public ExtraAppService(IConfiguration configuration, LdteamContext ldteamContext, PontoContext pontoContext)
        {
            swTempoRequisicao.Start();
            _configuration = configuration;
            _ldteamContext = ldteamContext;
            _pontoContext = pontoContext;
        }

        public BaseResponse<List<PitacosRanking>> PitacosObterRanking()
        {
            BaseResponse<List<PitacosRanking>> rReturn = new BaseResponse<List<PitacosRanking>>
            {
                Objeto = PitacosService.ObterRanking()
            };

            return rReturn;
        }

        public BaseResponse<List<PitacosMeusPitacos>> PitacosObterMeusPitacos(string email, string senha)
        {
            BaseResponse<List<PitacosMeusPitacos>> rReturn = new BaseResponse<List<PitacosMeusPitacos>>();

            var pitacos = PitacosService.ObterMeusPitacos(email, senha);

            if (pitacos != null)
            {
                rReturn.Objeto = pitacos;
            }
            else
            {
                Resposta.Mensagens.Add("Algo deu errado, verifique seu email/senha e tente novamente!");
            }

            rReturn.Mensagens = Resposta.Mensagens;

            return rReturn;
        }

        public BaseResponse<bool> PitacosSalvarPlacar(string email, string senha, string id, string placarA, string placarB)
        {
            BaseResponse<bool> rReturn = new BaseResponse<bool>();

            #region validation

            if (string.IsNullOrWhiteSpace(email))
            {
                Resposta.Mensagens.Add("O email � obrigat�rio!");
            }
            if (string.IsNullOrWhiteSpace(senha))
            {
                Resposta.Mensagens.Add("A senha � obrigat�ria!");
            }
            if (string.IsNullOrWhiteSpace(id))
            {
                Resposta.Mensagens.Add("O id � obrigat�rio!");
            }
            if (string.IsNullOrWhiteSpace(placarA))
            {
                Resposta.Mensagens.Add("O placar do time A � obrigat�rio!");
            }
            if (string.IsNullOrWhiteSpace(placarB))
            {
                Resposta.Mensagens.Add("O placar do time B � obrigat�rio!");
            }

            #endregion

            if (Resposta.Sucesso)
            {
                rReturn.Objeto = PitacosService.SalvarPlacar(email, senha, id, placarA, placarB);
            }

            rReturn.Mensagens = Resposta.Mensagens;

            return rReturn;
        }
    }
}