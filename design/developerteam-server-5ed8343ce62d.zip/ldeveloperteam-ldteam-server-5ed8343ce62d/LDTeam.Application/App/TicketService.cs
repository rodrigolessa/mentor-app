using System;
using System.Collections.Generic;
using System.Net;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;
using LDTeam.Application.Models;

namespace LDTeam.Application.App
{
    public class TicketService
    {
        public static string ObterTokenAcesso(string usuario, string senha)
        {
            string tReturn = string.Empty;

            var client = new RestClient("https://api.ticket.com.br/mobile/usuarios/v3/autenticar");
            var request = new RestRequest(Method.POST);
            request.AddHeader("Content-Type", "application/x-www-form-urlencoded");
            request.AddParameter("undefined", "Email=" + usuario + "&Password=" + senha, ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);

            if (response.StatusCode == HttpStatusCode.OK)
            {
                dynamic jObject = JObject.Parse(response.Content);
                string token = jObject["access_token"];
                string idUsuario = jObject["id_user"];

                client = new RestClient("https://api.ticket.com.br/mobile/usuarios/v3/" + idUsuario);
                request = new RestRequest(Method.GET);
                request.AddHeader("Authorization", "Bearer " + token);
                response = client.Execute(request);

                if (response.StatusCode == HttpStatusCode.OK)
                {
                    jObject = JObject.Parse(response.Content);
                    idUsuario = jObject["value"]["id"];
                    return token + ";" + idUsuario;
                }
            }

            return "";
        }

        public static List<CartaoTicket> ObterInformacaoCartoes(string usuario, string senha, int idContaAcesso)
        {
            List<CartaoTicket> cReturn = new List<CartaoTicket>();

            string retornoTokenAcesso = ObterTokenAcesso(usuario, senha);

            if (!string.IsNullOrWhiteSpace(retornoTokenAcesso))
            {
                string token = retornoTokenAcesso.Split(";")[0];
                string idUsuario = retornoTokenAcesso.Split(";")[1];

                var client = new RestClient("https://api.ticket.com.br/mobile/usuarios/v3/" + idUsuario + "/get-all-cards");
                var request = new RestRequest(Method.GET);
                request.AddHeader("Authorization", "Bearer " + token);
                IRestResponse response = client.Execute(request);

                if (response.StatusCode == HttpStatusCode.OK)
                {
                    dynamic jObject = JObject.Parse(response.Content);

                    if ((bool)jObject["success"] && jObject["value"] != null)
                    {
                        cReturn = new List<CartaoTicket>();

                        foreach (var element in jObject["value"])
                        {
                            CartaoTicket cartao = new CartaoTicket();

                            cartao.Tipo = element.balance.bin == "TRE" ? "Ticket Refeição" : element.balance.bin == "TAE" ? "Ticket Alimentação" : "Ticket";
                            cartao.Numero = element.balance.number;
                            cartao.MediaDiaria = element.balance.dailyAverage;
                            cartao.Apelido = element.balance.nickName;
                            cartao.DataProximoDeposito = element.balance.dateNextDeposit;
                            cartao.Valor = element.balance.valueParsed;
                            cartao.ValorTexto = element.balance.value;
                            cartao.Email = usuario;
                            cartao.IdContaAcesso = idContaAcesso;

                            if (element.scheduling != null)
                            {
                                cartao.Agendamentos = new List<AgendamentoCartaoTicket>();

                                foreach (var item in element.scheduling)
                                {
                                    AgendamentoCartaoTicket agendamento = new AgendamentoCartaoTicket();

                                    agendamento.Data = item.date;
                                    agendamento.Descricao = item.description;
                                    agendamento.Valor = item.valueParsed;
                                    agendamento.ValorTexto = item.value;

                                    cartao.Agendamentos.Add(agendamento);
                                }
                            }

                            if (element.release != null)
                            {
                                cartao.Gastos = new List<GastoCartaoTicket>();

                                foreach (var item in element.release)
                                {
                                    GastoCartaoTicket gasto = new GastoCartaoTicket();

                                    gasto.Data = item.date;
                                    gasto.Descricao = item.description;
                                    gasto.Valor = item.valueParsed;
                                    gasto.ValorTexto = item.value;

                                    cartao.Gastos.Add(gasto);
                                }
                            }

                            cReturn.Add(cartao);
                        }
                    }
                }
            }

            return cReturn;
        }

        public static bool CadastrarCartao(string usuario, string tipo, string numero)
        {
            bool cReturn = false;
            string retornoTokenAcesso = ""; //ObterTokenAcesso();

            if (!string.IsNullOrWhiteSpace(retornoTokenAcesso))
            {
                string token = retornoTokenAcesso.Split(";")[0];
                string idUsuario = retornoTokenAcesso.Split(";")[1];

                var client = new RestClient("https://api.ticket.com.br/mobile/usuarios/v3/" + idUsuario + "/cartoes");
                var request = new RestRequest(Method.POST);
                request.AddHeader("Authorization", "Bearer " + token);
                request.AddHeader("Content-Type", "application/x-www-form-urlencoded");
                request.AddParameter("undefined", string.Format("Number={0}&NickName={1}_{2}", numero, usuario, tipo), ParameterType.RequestBody);
                IRestResponse response = client.Execute(request);

                if (response.StatusCode == HttpStatusCode.OK)
                {
                    dynamic jObject = JObject.Parse(response.Content);

                    if ((bool)jObject.success)
                    {
                        cReturn = true;
                    }
                }
            }

            return cReturn;
        }

        public static bool RemoverCartao(string numero)
        {
            bool cReturn = false;
            string retornoTokenAcesso = ""; // ObterTokenAcesso();

            if (!string.IsNullOrWhiteSpace(retornoTokenAcesso))
            {
                string token = retornoTokenAcesso.Split(";")[0];
                string idUsuario = retornoTokenAcesso.Split(";")[1];

                var client = new RestClient("https://api.ticket.com.br/mobile/usuarios/v3/" + idUsuario + "/cartoes");
                var request = new RestRequest(Method.DELETE);
                request.AddHeader("Authorization", "Bearer " + token);
                request.AddHeader("number", numero);
                IRestResponse response = client.Execute(request);

                if (response.StatusCode == HttpStatusCode.OK)
                {
                    dynamic jObject = JObject.Parse(response.Content);

                    if ((bool)jObject.success)
                    {
                        cReturn = true;
                    }
                }
            }

            return cReturn;
        }
    }
}