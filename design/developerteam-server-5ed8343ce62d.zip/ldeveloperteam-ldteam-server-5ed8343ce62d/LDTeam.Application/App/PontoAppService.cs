using System;
using System.Collections.Generic;
using System.Linq;
using LDTeam.Application.Models.Response;
using Microsoft.Extensions.Configuration;
using LDTeam.Infrastructure.Ponto;
using LDTeam.Infrastructure.Ponto.Entities;
using LDTeam.Application.Models;

namespace LDTeam.Application.App
{
    public class PontoAppService : BaseAppService
    {
        private readonly IConfiguration _configuration;
        private readonly PontoContext _pontoContext;

        public PontoAppService()
        {
            swTempoRequisicao.Start();
        }

        public PontoAppService(IConfiguration configuration, PontoContext pontoContext)
        {
            swTempoRequisicao.Start();
            _configuration = configuration;
            _pontoContext = pontoContext;
        }

        public BaseResponse<SaldoResponse> ObterSaldo()
        {
            BaseResponse<SaldoResponse> sReturn = new BaseResponse<SaldoResponse>();
            FuncionarioPonto funcionario = _pontoContext.Funcionarios.FirstOrDefault(f => f.NumeroFolha == ColaboradorLogado.IdentificadorPonto);

            if (funcionario != null)
            {
                sReturn.Objeto = new SaldoResponse
                {
                    Periodo = ObterPeriodoPonto()
                };

                if (sReturn.Objeto.Periodo != null)
                {
                    DateTime hoje = DateTime.Now;
                    int saldo = 0;

                    CalculoPonto calculoPrimeiroDiaPeriodo = _pontoContext.Calculos.Where(c => c.Observacao == "Para compensação no período." && c.Data.Date == sReturn.Objeto.Periodo.DataInicio.Date && c.FuncionarioId == funcionario.Id).FirstOrDefault();

                    if (calculoPrimeiroDiaPeriodo != null && calculoPrimeiroDiaPeriodo.SaldoMinutosAjuste.HasValue && calculoPrimeiroDiaPeriodo.SaldoMinutosAjuste.Value != 0)
                    {
                        saldo = calculoPrimeiroDiaPeriodo.SaldoMinutosAjuste.Value;
                    }

                    List<FeriadoPonto> feriados = ObterFeriados();
                    List<AbonoParcial> abonos = _pontoContext.AbonosParciais.Where(c => c.Data.Date >= sReturn.Objeto.Periodo.DataInicio.Date && c.Data.Date < hoje.Date && c.FuncionarioId == funcionario.Id).ToList();
                    List<BatidaPonto> batidas = _pontoContext.Batidas.Where(c => c.Data.Date >= sReturn.Objeto.Periodo.DataInicio.Date && c.Data.Date < hoje.Date && c.FuncionarioId == funcionario.Id).ToList();
                    List<JustificativaLancada> justificativasLancadas = _pontoContext.JustificativasLancadas.Where(c => c.DataInicio.Date >= sReturn.Objeto.Periodo.DataInicio.Date && c.DataFim.Date <= hoje.Date && c.FuncionarioId == funcionario.Id).ToList();
                    List<Justificativa> justificativas = _pontoContext.Justificativas.ToList();

                    for (var dt = sReturn.Objeto.Periodo.DataInicio; dt < hoje.AddDays(-1); dt = dt.AddDays(1))
                    {
                        if (dt.Date >= funcionario.DataAdmissao.Date)
                        {
                            BatidaPonto batida = batidas.FirstOrDefault(b => b.Data.Date == dt.Date);
                            List<AbonoParcial> abonosDoDia = abonos.Where(b => b.Data.Date == dt.Date).ToList();
                            int saldoDia = ObterSaldoDiaBatida(dt, batida, abonosDoDia, feriados, justificativasLancadas, justificativas, false);
                            saldo += saldoDia;
                        }
                    }

                    sReturn.Objeto.Saldo = saldo.ToString();
                }
            }
            else
            {
                sReturn.Objeto = new SaldoResponse
                {
                    Saldo = "--:--"
                };
            }

            return sReturn;
        }

        public BaseResponse<List<ConsumoPonto>> ObterConsumo(string dataInicial, string dataFinal)
        {
            BaseResponse<List<ConsumoPonto>> cReturn = new BaseResponse<List<ConsumoPonto>>();
            FuncionarioPonto funcionario = _pontoContext.Funcionarios.FirstOrDefault(f => f.NumeroFolha == ColaboradorLogado.IdentificadorPonto);

            if (funcionario != null)
            {
                int limiteDatas = 5;
                DateTime dtFinal = DateTime.Now;
                DateTime dtInicial = dtFinal.AddDays(-60);

                if (!string.IsNullOrWhiteSpace(dataInicial) && !string.IsNullOrWhiteSpace(dataFinal))
                {
                    dtInicial = DateTime.Parse(dataInicial);
                    dtFinal = DateTime.Parse(dataFinal).Date >= DateTime.Now.Date ? DateTime.Now.AddDays(1) : DateTime.Parse(dataFinal);
                    limiteDatas = 0;
                }

                List<FeriadoPonto> feriados = ObterFeriados();
                List<AbonoParcial> abonos = _pontoContext.AbonosParciais.Where(c => c.FuncionarioId == funcionario.Id).OrderByDescending(c => c.Data).ToList();
                List<BatidaPonto> batidas = _pontoContext.Batidas.Where(c => c.Data.Date >= dtInicial.Date && c.Data.Date < dtFinal.Date && c.FuncionarioId == funcionario.Id).OrderByDescending(c => c.Data).ToList();
                List<JustificativaLancada> justificativasLancadas = _pontoContext.JustificativasLancadas.Where(c => c.FuncionarioId == funcionario.Id).ToList();
                List<ErroPonto> errosPonto = ObterErrosPonto().Objeto;
                List<Justificativa> justificativas = _pontoContext.Justificativas.ToList();

                cReturn.Objeto = new List<ConsumoPonto>();

                for (var dt = dtFinal.AddDays(-1); dt > dtInicial; dt = dt.AddDays(-1))
                {
                    if (dt.Date >= funcionario.DataAdmissao.Date)
                    {
                        if (cReturn.Objeto.Count(c => !c.Justificativa) == limiteDatas && limiteDatas != 0)
                        {
                            break;
                        }

                        BatidaPonto batida = batidas.FirstOrDefault(b => b.Data.Date == dt.Date);
                        List<AbonoParcial> abonosDoDia = abonos.Where(b => b.Data.Date == dt.Date).ToList();

                        ConsumoPonto consumo = new ConsumoPonto
                        {
                            Data = dt.ToString("dd/MM/yyyy"),
                            SaldoMinutos = ObterSaldoDiaBatida(dt, batida, abonosDoDia, feriados, justificativasLancadas, justificativas, true),
                            Marcacoes = ObterMarcacoes(batida),
                            Justificativa = false
                        };

                        JustificativaLancada justificativaLancada = justificativasLancadas.FirstOrDefault(c => dt.Date >= c.DataInicio.Date && dt.Date <= c.DataFim.Date);

                        if ((dt.DayOfWeek != DayOfWeek.Saturday && dt.DayOfWeek != DayOfWeek.Sunday && !feriados.Any(c => c.Data.Date == dt.Date)) || consumo.SaldoMinutos > 0 || justificativaLancada != null)
                        {
                            if (justificativaLancada != null)
                            {
                                Justificativa justificativa = _pontoContext.Justificativas.FirstOrDefault(j => j.Id == justificativaLancada.JustificativaId);

                                if (justificativa != null)
                                {
                                    consumo.Justificativa = true;
                                    consumo.Obs = justificativa.Nome + (string.IsNullOrWhiteSpace(justificativaLancada.Observacao) ? string.Empty : " - " + justificativaLancada.Observacao);
                                }
                            }

                            if (errosPonto != null)
                            {
                                ErroPonto erroPonto = errosPonto.FirstOrDefault(c => c.Data == consumo.Data);

                                if (erroPonto != null)
                                {
                                    consumo.ErroPonto = true;
                                    consumo.MensagemErroPonto = erroPonto.Nome;
                                }
                            }

                            cReturn.Objeto.Add(consumo);
                        }
                    }
                }
            }

            return cReturn;
        }

        public BaseResponse<List<ErroPonto>> ObterErrosPonto()
        {
            BaseResponse<List<ErroPonto>> eReturn = new BaseResponse<List<ErroPonto>>();

            FuncionarioPonto funcionario = _pontoContext.Funcionarios.FirstOrDefault(f => f.NumeroFolha == ColaboradorLogado.IdentificadorPonto);

            if (funcionario != null)
            {
                PeriodoPonto periodo = ObterPeriodoPonto();
                DateTime periodoInicial = periodo.DataInicio;
                DateTime periodoFinal = periodo.DataFim;
                DateTime hoje = DateTime.Now;

                List<BatidaPonto> Batidas = _pontoContext.Batidas.Where(c => c.FuncionarioId == funcionario.Id && c.Data.Date >= periodoInicial.Date && c.Data.Date <= periodoFinal.Date && c.Data.Date != hoje.Date).ToList();

                foreach (var item in Batidas)
                {
                    string erroMarcacao = string.Empty;
                    CalculoPonto calculo = _pontoContext.Calculos.FirstOrDefault(c => c.FuncionarioId == funcionario.Id && c.Data == item.Data);
                    int TotalBatidas = _pontoContext.FontesDados.Count(f => f.FuncionarioId == funcionario.Id && f.Data == item.Data && f.TipoRegistro != 3 && (f.Motivo == null || f.Motivo != "Batida duplicada"));

                    //verifica se teve batida impar
                    if (TotalBatidas % 2 != 0)
                    {
                        //verifica se a primeira saida está dentro dos parâmetros de ida para almoço e a segunda entrada está dentro dos parâmetros de volta do almoço
                        //parâmetros de ida para almoço: 11:30 até 14:00
                        //parâmetros de volta do almoço: Até 2h:30min depois da ida para o almoço
                        if (!string.IsNullOrWhiteSpace(item.Saida1) && !string.IsNullOrWhiteSpace(item.Entrada2) && Convert.ToInt32(item.Saida1.Replace(":", "")) >= 1130 && Convert.ToInt32(item.Entrada2.Replace(":", "")) <= (Convert.ToInt32(item.Saida1.Replace(":", "")) + 230))
                        {
                            erroMarcacao = "Possível erro de marcação na saída";
                        }
                        else if (!string.IsNullOrWhiteSpace(item.Saida1) && !string.IsNullOrWhiteSpace(item.Entrada2) && Convert.ToInt32(item.Saida1.Replace(":", "")) >= 1130 && Convert.ToInt32(item.Entrada2.Replace(":", "")) > (Convert.ToInt32(item.Saida1.Replace(":", "")) + 230))
                        {
                            erroMarcacao = "Possível erro de marcação na volta do almoço";
                        }
                        else if (!string.IsNullOrWhiteSpace(item.Saida2) && !string.IsNullOrWhiteSpace(item.Entrada3) && Convert.ToInt32(item.Saida2.Replace(":", "")) >= 1130 && Convert.ToInt32(item.Entrada3.Replace(":", "")) <= (Convert.ToInt32(item.Saida2.Replace(":", "")) + 230))
                        {
                            erroMarcacao = "Possível erro de marcação na saída";
                        }
                        else if (!string.IsNullOrWhiteSpace(item.Saida2) && !string.IsNullOrWhiteSpace(item.Entrada3) && Convert.ToInt32(item.Saida2.Replace(":", "")) >= 1130 && Convert.ToInt32(item.Entrada3.Replace(":", "")) > (Convert.ToInt32(item.Saida2.Replace(":", "")) + 230))
                        {
                            erroMarcacao = "Possível erro de marcação na volta do almoço";
                        }
                        else
                        {
                            erroMarcacao = "Possível erro de marcação na saída";
                        }

                        if (eReturn.Objeto == null)
                        {
                            eReturn.Objeto = new List<ErroPonto>();
                        }

                        eReturn.Objeto.Add(new ErroPonto()
                        {
                            Id = "ponto_" + item.Id.ToString(),
                            Data = item.Data.ToString("dd/MM/yyyy"),
                            Nome = erroMarcacao,
                            Marcacoes = ObterMarcacoes(item)
                        });
                    }
                }
            }
            else
            {
                //eReturn.Mensagens = new List<string>() { "Colaborador não encontrado no sistema do ponto!" };
            }

            return eReturn;
        }

        private List<string> ObterMarcacoes(BatidaPonto batida)
        {
            List<string> marcacoes = new List<string>();

            #region add marcações do dia

            if (batida == null)
            {
                return marcacoes;
            }

            if (!string.IsNullOrWhiteSpace(batida.Entrada1))
            {
                marcacoes.Add(batida.Entrada1);
            }
            if (!string.IsNullOrWhiteSpace(batida.Saida1))
            {
                marcacoes.Add(batida.Saida1);
            }
            if (!string.IsNullOrWhiteSpace(batida.Entrada2))
            {
                marcacoes.Add(batida.Entrada2);
            }
            if (!string.IsNullOrWhiteSpace(batida.Saida2))
            {
                marcacoes.Add(batida.Saida2);
            }
            if (!string.IsNullOrWhiteSpace(batida.Entrada3))
            {
                marcacoes.Add(batida.Entrada3);
            }
            if (!string.IsNullOrWhiteSpace(batida.Saida3))
            {
                marcacoes.Add(batida.Saida3);
            }
            if (!string.IsNullOrWhiteSpace(batida.Entrada4))
            {
                marcacoes.Add(batida.Entrada4);
            }
            if (!string.IsNullOrWhiteSpace(batida.Saida4))
            {
                marcacoes.Add(batida.Saida4);
            }
            if (!string.IsNullOrWhiteSpace(batida.Entrada5))
            {
                marcacoes.Add(batida.Entrada5);
            }
            if (!string.IsNullOrWhiteSpace(batida.Saida5))
            {
                marcacoes.Add(batida.Saida5);
            }

            #endregion

            return marcacoes;
        }

        private int ObterSaldoDiaBatida(DateTime Dia, BatidaPonto batida, List<AbonoParcial> abonos, List<FeriadoPonto> feriados, List<JustificativaLancada> justificativasLancada, List<Justificativa> justificativas, bool jornada)
        {
            int resposta = 0;
            DateTime? entrada1 = null;
            DateTime? saida1 = null;
            DateTime? entrada2 = null;
            DateTime? saida2 = null;
            DateTime? entrada3 = null;
            DateTime? saida3 = null;
            DateTime? entrada4 = null;
            DateTime? saida4 = null;
            DateTime? entrada5 = null;
            DateTime? saida5 = null;
            TimeSpan? ajuste = null;
            TimeSpan tempoTotal = TimeSpan.MinValue;


            if (batida != null && !string.IsNullOrWhiteSpace(batida.Entrada1))
            {
                bool sucesso = DateTime.TryParse(batida.Entrada1, out DateTime dt);
                if (sucesso) entrada1 = dt;
            }
            if (batida != null && !string.IsNullOrWhiteSpace(batida.Saida1))
            {
                bool sucesso = DateTime.TryParse(batida.Saida1, out DateTime dt);
                if (sucesso) saida1 = dt;
            }
            if (batida != null && !string.IsNullOrWhiteSpace(batida.Entrada2))
            {
                bool sucesso = DateTime.TryParse(batida.Entrada2, out DateTime dt);
                if (sucesso) entrada2 = dt;
            }
            if (batida != null && !string.IsNullOrWhiteSpace(batida.Saida2))
            {
                bool sucesso = DateTime.TryParse(batida.Saida2, out DateTime dt);
                if (sucesso) saida2 = dt;
            }
            if (batida != null && !string.IsNullOrWhiteSpace(batida.Entrada3))
            {
                bool sucesso = DateTime.TryParse(batida.Entrada3, out DateTime dt);
                if (sucesso) entrada3 = dt;
            }
            if (batida != null && !string.IsNullOrWhiteSpace(batida.Saida3))
            {
                bool sucesso = DateTime.TryParse(batida.Saida3, out DateTime dt);
                if (sucesso) saida3 = dt;
            }
            if (batida != null && !string.IsNullOrWhiteSpace(batida.Entrada4))
            {
                bool sucesso = DateTime.TryParse(batida.Entrada4, out DateTime dt);
                if (sucesso) entrada4 = dt;
            }
            if (batida != null && !string.IsNullOrWhiteSpace(batida.Saida4))
            {
                bool sucesso = DateTime.TryParse(batida.Saida4, out DateTime dt);
                if (sucesso) saida4 = dt;
            }
            if (batida != null && !string.IsNullOrWhiteSpace(batida.Entrada5))
            {
                bool sucesso = DateTime.TryParse(batida.Entrada5, out DateTime dt);
                if (sucesso) entrada5 = dt;
            }
            if (batida != null && !string.IsNullOrWhiteSpace(batida.Saida5))
            {
                bool sucesso = DateTime.TryParse(batida.Saida5, out DateTime dt);
                if (sucesso) saida5 = dt;
            }
            if (batida != null && !string.IsNullOrWhiteSpace(batida.Ajuste))
            {
                bool sucesso = DateTime.TryParse(batida.Ajuste, out DateTime dt);
                if (sucesso) ajuste = dt.TimeOfDay;
            }

            if (saida1.HasValue)
            {
                tempoTotal = saida1.Value.Subtract(entrada1.Value);
            }
            if (saida2.HasValue)
            {
                if (tempoTotal == TimeSpan.MinValue)
                {
                    tempoTotal = saida2.Value.Subtract(entrada2.Value);
                }
                else
                {
                    tempoTotal += saida2.Value.Subtract(entrada2.Value);
                }
            }
            if (saida3.HasValue)
            {
                if (tempoTotal == TimeSpan.MinValue)
                {
                    tempoTotal = saida3.Value.Subtract(entrada3.Value);
                }
                else
                {
                    tempoTotal += saida3.Value.Subtract(entrada3.Value);
                }
            }
            if (saida4.HasValue)
            {
                if (tempoTotal == TimeSpan.MinValue)
                {
                    tempoTotal = saida4.Value.Subtract(entrada4.Value);
                }
                else
                {
                    tempoTotal += saida4.Value.Subtract(entrada4.Value);
                }
            }
            if (saida5.HasValue)
            {
                if (tempoTotal == TimeSpan.MinValue)
                {
                    tempoTotal = saida5.Value.Subtract(entrada5.Value);
                }
                else
                {
                    tempoTotal += saida5.Value.Subtract(entrada5.Value);
                }
            }

            if (tempoTotal != TimeSpan.MinValue)
            {
                resposta += (int)tempoTotal.TotalMinutes;
            }

            if (ajuste.HasValue)
            {
                resposta += (int)ajuste.Value.TotalMinutes;
            }

            if (abonos != null && abonos.Any())
            {
                foreach (var abono in abonos)
                {
                    TimeSpan horaInicio = DateTime.Parse(abono.HoraInicio).TimeOfDay;
                    TimeSpan horaFim = DateTime.Parse(abono.HoraFim).TimeOfDay;

                    resposta += (int)(horaFim.TotalMinutes - horaInicio.TotalMinutes);
                }
            }

            if (!jornada && Dia.DayOfWeek != DayOfWeek.Saturday && Dia.DayOfWeek != DayOfWeek.Sunday && !feriados.Any(c => c.Data.Date == Dia.Date) && !justificativasLancada.Any(c => Dia.Date >= c.DataInicio.Date && Dia.Date <= c.DataFim.Date) && !justificativas.Any(c => batida != null && !string.IsNullOrWhiteSpace(batida.Entrada1) && c.Nome == batida.Entrada1))
            {
                resposta -= 480;
            }

            if ((resposta >= -9 && resposta <= 9) || Dia.DayOfWeek == DayOfWeek.Sunday || feriados.Any(c => c.Data.Date == Dia.Date))
            {
                resposta = 0;
            }

            return resposta;
        }

        private PeriodoPonto ObterPeriodoPonto()
        {
            PeriodoPonto pReturn = null;

            CalculoPonto calculo = _pontoContext.Calculos.Where(c => c.Observacao != null && c.Observacao.ToUpper() == "Encerramento do Banco de Horas".ToUpper()).OrderByDescending(c => c.Data).FirstOrDefault();

            if (calculo != null)
            {
                pReturn = new PeriodoPonto();
                pReturn.DataInicio = calculo.Data.AddDays(1);
                pReturn.DataFim = pReturn.DataInicio.AddMonths(4).AddDays(-1);
            }

            return pReturn;
        }

        private List<FeriadoPonto> ObterFeriados()
        {
            List<FeriadoPonto> fReturn = _pontoContext.Feriados.OrderByDescending(c => c.Data).ToList();

            return fReturn;
        }
    }
}