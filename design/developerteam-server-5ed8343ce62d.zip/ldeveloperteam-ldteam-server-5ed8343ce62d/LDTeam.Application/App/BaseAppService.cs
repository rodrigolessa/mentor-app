using System;
using System.Collections.Generic;
using System.Diagnostics;
using LDTeam.Infrastructure.Ldteam.Entities;
using LDTeam.Application.Models;
using LDTeam.Application.Models.Response;

namespace LDTeam.Application.App
{
    public class BaseAppService : IDisposable
    {
        public string IpUsuario;
        public string NomeSistemaOperacional;
        public string NomeNavegador;
        public BaseResponse<bool> Resposta;
        public Funcionario FuncionarioLogado;
        public Colaborador ColaboradorLogado;
        public string CodigoEmpresa;
        public Stopwatch swTempoRequisicao = new Stopwatch();

        public BaseAppService()
        {
            Resposta = new BaseResponse<bool>();
            Resposta.Mensagens = new List<string>();
            Resposta.Sucesso = true;
            Resposta.Autorizado = true;
        }

        public void Dispose(bool disposing)
        {
        }


        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}