using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;
using LDTeam.Application.Models;

namespace LDTeam.Application.App
{
    public class MicrosoftService
    {
        public static string Token;
        public static int TentativasLogin = 0;

        public static string ObterTokenAcesso()
        {
            string tReturn = string.Empty;

            var client = new RestClient("https://login.microsoftonline.com/be4df986-3e31-4738-bb50-56e9e46d1192/oauth2/v2.0/token");
            var request = new RestRequest(Method.POST);
            request.AddHeader("Content-Type", "application/x-www-form-urlencoded");
            request.AddParameter("undefined", "client_id=c771df96-06d1-4a27-a16f-34a4fcbadfde&grant_type=client_credentials&scope=https%3A%2F%2Fgraph.microsoft.com%2F.default&client_secret=YxXdAQDh%2F%2BqdUw8jdA%2F4uiPfcfCAB64xpaS1XcXvD78%3D", ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);

            if (response.StatusCode == HttpStatusCode.OK)
            {
                Token = JsonConvert.DeserializeObject<MicrosoftLoginReturn>(response.Content).access_token;
            }

            return Token;
        }

        public static Calendario ObterCalendario(string email, string dataInicial, string dataFinal)
        {
            Calendario cReturn = null;

            if (string.IsNullOrWhiteSpace(Token))
            {
                ObterTokenAcesso();
            }

            var client = new RestClient("https://graph.microsoft.com/v1.0/users/" + email + "/calendarview?startdatetime=" + dataInicial + "&enddatetime=" + dataFinal + "&$top=10000");
            var request = new RestRequest(Method.GET);
            request.AddHeader("Authorization", "Bearer " + Token);
            request.AddHeader("Prefer", "outlook.timezone=\"E. South America Standard Time\"");
            IRestResponse response = client.Execute(request);

            if (response.StatusCode == HttpStatusCode.OK)
            {
                cReturn = new Calendario();
                dynamic jObject = JObject.Parse(response.Content);
                cReturn.Nome = "";
                cReturn.Cor = "";
                cReturn.Itens = new List<ItemCalendario>();

                foreach (var element in jObject.value)
                {
                    var itemCalendario = new ItemCalendario
                    {
                        Id = element["id"],
                        DataInicio = element["start"]["dateTime"],
                        DataFim = element["end"]["dateTime"],
                        Nome = element["subject"],
                        FoiCancelado = element["isCancelled"],
                        Organizador = element["organizer"]["emailAddress"]["name"],
                        Local = element["location"]["displayName"],
                        Link = element["webLink"],
                        StatusResposta = element["responseStatus"]["response"],
                        DiaTodo = element["isAllDay"],
                        Descricao = element["bodyPreview"]
                    };
                    if (!itemCalendario.DiaTodo)
                    {
                        itemCalendario.DataInicio = itemCalendario.DataInicio;
                        itemCalendario.DataFim = itemCalendario.DataFim;
                    }
                    else
                    {
                        itemCalendario.DataFim = itemCalendario.DataFim.AddDays(-1);
                    }

                    itemCalendario.Data = itemCalendario.DataInicio.ToShortDateString();
                    itemCalendario.Hora = itemCalendario.DataInicio.ToString("HH:mm");

                    if (element.attendees != null)
                    {
                        itemCalendario.Participantes = new List<string>();

                        foreach (var item in element.attendees)
                        {
                            itemCalendario.Participantes.Add(item["emailAddress"]["name"].ToString());
                        }
                    }

                    cReturn.Itens.Add(itemCalendario);
                }

                TentativasLogin = 0;
            }
            else
            {
                Token = null;
                TentativasLogin++;

                if (TentativasLogin < 5)
                {
                    return ObterCalendario(email, dataInicial, dataFinal);
                }
            }

            if (cReturn != null && cReturn.Itens != null && cReturn.Itens.Any())
            {
                foreach (var item in cReturn.Itens.ToList())
                {
                    if (item.DataInicio.Date != item.DataFim.Date)
                    {
                        for (var dt = item.DataInicio; dt <= item.DataFim; dt = dt.AddDays(1))
                        {
                            if (dt.Date == item.DataInicio.Date)
                            {
                                continue;
                            }

                            var novoItem = new ItemCalendario(item);
                            novoItem.Id = CriptografarSHA512(novoItem.Id + dt.ToShortDateString());
                            novoItem.Data = dt.ToShortDateString();
                            novoItem.Hora = dt.ToString("HH:mm");
                            novoItem.DiaTodo = true;

                            cReturn.Itens.Add(novoItem);
                        }
                    }
                }
            }

            return cReturn;
        }

        private static string CriptografarSHA512(string text)
        {
            //string length 128
            var data = Encoding.ASCII.GetBytes(text);
            var hashData = new SHA512Managed().ComputeHash(data);
            var hash = string.Empty;
            foreach (var b in hashData)
                hash += b.ToString("X2");

            return hash;
        }
    }
}