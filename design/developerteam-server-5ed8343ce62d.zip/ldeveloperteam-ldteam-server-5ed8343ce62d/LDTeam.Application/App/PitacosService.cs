using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;
using LDTeam.Application.Models;
using HtmlAgilityPack;

namespace LDTeam.Application.App
{
    public class PitacosService
    {
        public static string Token;
        public static int TentativasLogin = 0;

        public static RestClient EfetuarLogin(string email = "", string senha = "")
        {
            string tReturn = string.Empty;

            if (string.IsNullOrWhiteSpace(email))
            {
                email = "compras%40ldsoft.com.br";
                senha = "10Ld18";
            }

            var client = new RestClient("https://pitacosonline.riosoft.com.br/bolao/login");
            client.CookieContainer = new CookieContainer();
            var request = new RestRequest(Method.POST);
            request.AddHeader("Content-Type", "application/x-www-form-urlencoded");
            request.AddParameter("undefined", "usuario.dsLogin=" + email + "&usuario.dsSenha=" + senha, ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);

            if (response.StatusCode == HttpStatusCode.Found || response.StatusCode == HttpStatusCode.OK)
            {
                return client;
            }

            return null;
        }

        public static List<PitacosRanking> ObterRanking()
        {
            List<PitacosRanking> rReturn = null;

            var client = EfetuarLogin();

            if (client == null)
            {
                return rReturn;
            }

            client.BaseUrl = new Uri("https://pitacosonline.riosoft.com.br/bolao/classificacao");
            client.Encoding = System.Text.Encoding.GetEncoding("iso-8859-1");
            var request = new RestRequest(Method.GET);
            IRestResponse response = client.Execute(request);

            if (response.StatusCode == HttpStatusCode.OK)
            {
                rReturn = new List<PitacosRanking>();

                HtmlDocument map = new HtmlDocument();
                map.LoadHtml(Encoding.GetEncoding("iso-8859-1").GetString(response.RawBytes));

                var participantesNode = map.DocumentNode.SelectNodes("//div[@id='tableClassificacao']//table//tbody/tr").ToList();

                for (int i = 0; i < participantesNode.Count; i++)
                {
                    HtmlNode nodeColocacao = map.DocumentNode.SelectNodes(participantesNode[i].XPath + "/td")[1];
                    string colocacao = nodeColocacao.InnerHtml.Replace("&ordm;", "").Trim();

                    HtmlNode nodeNome = map.DocumentNode.SelectNodes(participantesNode[i].XPath + "/td")[2];
                    string nome = nodeNome.InnerHtml.Replace("<strong>", "").Replace("</strong>", "").Trim();

                    string email = string.Empty;

                    if (nodeNome.GetAttributeValue("title", "") != "")
                    {
                        email = nodeNome.GetAttributeValue("title", "").Split("E-mail: ")[1].Trim();
                    }

                    HtmlNode nodePontuacao = map.DocumentNode.SelectNodes(participantesNode[i].XPath + "/td")[4];
                    string pontuacao = nodePontuacao.InnerHtml.Trim();

                    rReturn.Add(new PitacosRanking()
                    {
                        Id = Guid.NewGuid().ToString(),
                        Colocacao = colocacao,
                        Nome = nome,
                        Pontuacao = pontuacao,
                        Email = email
                    });
                }
            }
            else
            {
                Token = null;
                TentativasLogin++;

                if (TentativasLogin < 5)
                {
                    return ObterRanking();
                }
            }

            return rReturn;
        }

        public static List<PitacosMeusPitacos> ObterMeusPitacos(string email, string senha)
        {
            List<PitacosMeusPitacos> rReturn = null;

            var client = EfetuarLogin(email, senha);

            if (client == null)
            {
                return rReturn;
            }

            client.BaseUrl = new Uri("https://pitacosonline.riosoft.com.br/bolao/meus-palpites-data");
            client.Encoding = System.Text.Encoding.GetEncoding("iso-8859-1");
            var request = new RestRequest(Method.GET);
            IRestResponse response = client.Execute(request);

            if (response.StatusCode == HttpStatusCode.OK)
            {
                rReturn = new List<PitacosMeusPitacos>();

                HtmlDocument map = new HtmlDocument();
                map.LoadHtml(Encoding.GetEncoding("iso-8859-1").GetString(response.RawBytes));

                var participantesNode = map.DocumentNode.SelectNodes("//table[@id='tabela-resultados']//tbody/tr").ToList();

                for (int i = 0; i < participantesNode.Count; i++)
                {
                    HtmlNode nodeData = map.DocumentNode.SelectNodes(participantesNode[i].XPath + "/td")[1];
                    string data = nodeData.InnerHtml.Replace("&ordm;", "").Split("(")[0].Trim();

                    HtmlNode nodeHora = map.DocumentNode.SelectNodes(participantesNode[i].XPath + "/td")[2];
                    string hora = nodeHora.InnerHtml.Replace("&ordm;", "").Trim();

                    HtmlNode nodeTimeA = map.DocumentNode.SelectNodes(participantesNode[i].XPath + "/td")[3];
                    string timeA = nodeTimeA.InnerHtml.Replace("&ordm;", "").Trim();

                    HtmlNode nodeImgA = map.DocumentNode.SelectNodes(participantesNode[i].XPath + "/td/img")[0];
                    string imgA = "https://pitacosonline.riosoft.com.br" + nodeImgA.GetAttributeValue("src", "").Replace("_mini", "");

                    HtmlNode nodePlacarA = map.DocumentNode.SelectNodes(participantesNode[i].XPath + "/td/span")[0];
                    string placarA = nodePlacarA.InnerHtml.Replace("&ordm;", "").Trim();

                    HtmlNode nodePlacarB = map.DocumentNode.SelectNodes(participantesNode[i].XPath + "/td/span")[1];
                    string placarB = nodePlacarB.InnerHtml.Replace("&ordm;", "").Trim();

                    HtmlNode nodeImgB = map.DocumentNode.SelectNodes(participantesNode[i].XPath + "/td/img")[1];
                    string imgB = "https://pitacosonline.riosoft.com.br" + nodeImgB.GetAttributeValue("src", "").Replace("_mini", "");

                    HtmlNode nodeTimeB = map.DocumentNode.SelectNodes(participantesNode[i].XPath + "/td")[9];
                    string timeB = nodeTimeB.InnerHtml.Replace("&ordm;", "").Trim();

                    HtmlNode nodePontos = map.DocumentNode.SelectNodes(participantesNode[i].XPath + "/td/span")[2];
                    string pontos = nodePontos.InnerHtml.Replace("&ordm;", "").Trim();
                    string placarFinalA = string.Empty;
                    string placarFinalB = string.Empty;

                    if (nodePontos.GetAttributeValue("title", "") != "")
                    {
                        string placar = nodePontos.GetAttributeValue("title", "");
                        placarFinalA = placar.Split(" x ")[0].Trim().Split(" ")[placar.Split(" x ")[0].Trim().Split(" ").Length - 1].Trim();
                        placarFinalB = placar.Split(" x ")[1].Trim().Split(" ")[0].Trim();
                    }

                    string id = string.Empty;

                    if (map.DocumentNode.SelectNodes(participantesNode[i].XPath + "/td/a") != null)
                    {
                        HtmlNode nodeId = map.DocumentNode.SelectNodes(participantesNode[i].XPath + "/td/a")[1];
                        id = nodeId.GetAttributeValue("href", "").Split("?")[0].Split("/")[3].Trim();
                    }

                    rReturn.Add(new PitacosMeusPitacos()
                    {
                        Id = id,
                        Data = data,
                        TimeA = timeA,
                        TimeB = timeB,
                        PlacarA = placarA,
                        PlacarB = placarB,
                        Hora = hora,
                        ImgA = imgA,
                        ImgB = imgB,
                        Pontos = pontos,
                        PlacarFinalA = placarFinalA,
                        PlacarFinalB = placarFinalB
                    });
                }
            }
            else
            {
                Token = null;
                TentativasLogin++;

                if (TentativasLogin < 5)
                {
                    return ObterMeusPitacos(email, senha);
                }
            }

            return rReturn;
        }

        public static bool SalvarPlacar(string email, string senha, string id, string placarA, string placarB)
        {
            bool rReturn = false;

            var client = EfetuarLogin(email, senha);

            if (client == null)
            {
                return rReturn;
            }

            client.BaseUrl = new Uri("https://pitacosonline.riosoft.com.br/bolao/palpitar-modal");
            client.Encoding = System.Text.Encoding.GetEncoding("iso-8859-1");
            var request = new RestRequest(Method.POST);
            request.AddHeader("Content-Type", "application/x-www-form-urlencoded");
            request.AddParameter("undefined", "idJogo=" + id + "&nrGolsClube1=" + placarA + "&nrGolsClube2=" + placarB, ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);

            if (response.StatusCode == HttpStatusCode.OK && response.Content.Contains("SUCCESS"))
            {
                rReturn = true;
            }
            else
            {
                Token = null;
                TentativasLogin++;

                if (TentativasLogin < 5)
                {
                    return SalvarPlacar(email, senha, id, placarA, placarB);
                }
            }

            return rReturn;
        }
    }
}