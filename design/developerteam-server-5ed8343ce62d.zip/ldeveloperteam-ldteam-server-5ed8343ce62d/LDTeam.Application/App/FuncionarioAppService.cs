using System;
using System.Collections.Generic;
using System.Linq;
using LDTeam.Application.Models.Response;
using Microsoft.Extensions.Configuration;
using LDTeam.Application.Models;
using LDTeam.Infrastructure.Ldteam;
using LDTeam.Webapi.Request;
using LDTeam.Infrastructure.Ldteam.Entities;
using Microsoft.EntityFrameworkCore;
using LDTeam.Infrastructure.Ponto;

namespace LDTeam.Application.App
{
    public class FuncionarioAppService : BaseAppService
    {
        private readonly IConfiguration _configuration;
        private readonly LdteamContext _ldteamContext;
        private readonly PontoContext _pontoContext;

        public FuncionarioAppService()
        {
            swTempoRequisicao.Start();
        }

        public FuncionarioAppService(IConfiguration configuration, LdteamContext ldteamContext, PontoContext pontoContext)
        {
            swTempoRequisicao.Start();
            _configuration = configuration;
            _ldteamContext = ldteamContext;
            _pontoContext = pontoContext;
        }

        public BaseResponse<List<Colaborador>> Listar()
        {
            BaseResponse<List<Colaborador>> cReturn = new BaseResponse<List<Colaborador>>
            {
                Objeto = _ldteamContext.Colaboradores.Where(c => c.Ativo && c.IdEmpresa == ColaboradorLogado.IdEmpresa).ToList()
            };
            var departamentos = _pontoContext.Departamentos.ToList();
            var funcionarios = _pontoContext.Funcionarios.ToList();

            foreach (var item in cReturn.Objeto)
            {
                var funcionario = funcionarios.FirstOrDefault(f => f.NumeroFolha == item.IdentificadorPonto);

                if (funcionario != null)
                {
                    var departamento = departamentos.FirstOrDefault(d => d.Id == funcionario.IdDepartamento);

                    item.Departamento = departamento != null ? departamento.Descricao : (item.Departamento ?? "");
                }

                item.Notificacoes = null;
                item.ContasAcessos = null;
                item.Senha = null;
                item.Empresa = null;
            }

            return cReturn;
        }

        public BaseResponse<List<Colaborador>> ListarAniversariantes()
        {
            BaseResponse<List<Colaborador>> cReturn = new BaseResponse<List<Colaborador>>
            {
                Objeto = _ldteamContext.Colaboradores.Where(c => c.Ativo && c.IdEmpresa == ColaboradorLogado.IdEmpresa && c.DataAniversario.Value.Month == DateTime.Now.Month).ToList()
            };

            string meuArgumento = ColaboradorLogado.Email.Split("@")[0] + ".jpg;";
            var notificacoes = _ldteamContext.ColaboradoresNotificacoes.Include("TipoNotificacao").Where(c => c.Argumentos != null && c.Argumentos.Contains(meuArgumento) && c.TipoNotificacao.Codigo == "felicitacoes").ToList();
            notificacoes = notificacoes.Where(c => c.DataCadastro.Month == DateTime.Now.Month && (c.DataCadastro.Year + 1) > DateTime.Now.Year).ToList();

            foreach (var item in cReturn.Objeto)
            {
                item.Notificacoes = null;
                item.ContasAcessos = null;
                item.Senha = null;
                item.Empresa = null;

                if (notificacoes.Any(n => n.IdColaborador == item.Id))
                {
                    item.FelicitacaoEnviada = true;
                }
                else
                {
                    item.FelicitacaoEnviada = false;
                }
            }

            return cReturn;
        }

        public BaseResponse<List<Felicitacao>> ListarFelicitacoes()
        {
            BaseResponse<List<Felicitacao>> fReturn = new BaseResponse<List<Felicitacao>>();
            List<Felicitacao> felicitacoes = new List<Felicitacao>();

            if (ColaboradorLogado.DataAniversario.Value.Day == DateTime.Now.Day && ColaboradorLogado.DataAniversario.Value.Month == DateTime.Now.Month)
            {
                var notificacoes = _ldteamContext.ColaboradoresNotificacoes.Include("TipoNotificacao").Where(c => c.IdColaborador == ColaboradorLogado.Id && c.TipoNotificacao.Codigo == "felicitacoes").ToList();
                notificacoes = notificacoes.Where(c => c.DataCadastro.Month == DateTime.Now.Month && (c.DataCadastro.Year + 1) > DateTime.Now.Year).ToList();

                foreach (var item in notificacoes)
                {
                    Felicitacao fel = new Felicitacao
                    {
                        Data = item.DataCadastro,
                        Mensagem = item.Valor,
                        Nome = item.Argumentos.Split(";")[1],
                        FotoUrl = item.Argumentos.Split(";")[0]
                    };

                    felicitacoes.Add(fel);
                }
            }

            fReturn.Objeto = felicitacoes;

            return fReturn;
        }

        public BaseResponse<bool> AdicionarFelicitacao(Felicitacao felicitacao)
        {
            BaseResponse<bool> fReturn = new BaseResponse<bool>();

            #region validacao

            if (felicitacao == null)
            {
                Resposta.Mensagens.Add("Nenhuma felicitação encontrada!");
            }
            else
            {
                if (felicitacao.IdColaboradorFelicitacao == 0)
                {
                    Resposta.Mensagens.Add("Colaborador não encontrado!");
                }

                if (string.IsNullOrWhiteSpace(felicitacao.Mensagem))
                {
                    Resposta.Mensagens.Add("Mensagem não encontrada!");
                }
            }

            #endregion

            var notificacoes = _ldteamContext.ColaboradoresNotificacoes.Include("TipoNotificacao").Where(c => c.IdColaborador == ColaboradorLogado.Id && c.TipoNotificacao.Codigo == "felicitacao").ToList();
            notificacoes = notificacoes.Where(c => c.DataCadastro.Month == DateTime.Now.Month && (c.DataCadastro.Year + 1) > DateTime.Now.Year).ToList();

            TipoNotificacao tn = _ldteamContext.TiposNotificacoes.FirstOrDefault(t => t.Codigo == "felicitacoes");
            Colaborador colaborador = _ldteamContext.Colaboradores.FirstOrDefault(t => t.Id == felicitacao.IdColaboradorFelicitacao);

            if (colaborador != null)
            {
                if (tn != null)
                {
                    ColaboradorNotificacao cn = new ColaboradorNotificacao
                    {
                        IdColaborador = felicitacao.IdColaboradorFelicitacao,
                        Argumentos = ColaboradorLogado.Email.Split("@")[0] + ".jpg;" + ColaboradorLogado.Nome,
                        Valor = felicitacao.Mensagem,
                        DataCadastro = DateTime.Now,
                        StatusNotificacao = 1,
                        IdTipoNotificacao = tn.Id
                    };

                    _ldteamContext.ColaboradoresNotificacoes.Add(cn);
                    _ldteamContext.SaveChanges();
                }
                else
                {
                    Resposta.Mensagens.Add("Tipo de notificação não encontrado!");
                }
            }
            else
            {
                Resposta.Mensagens.Add("Colaborador não encontrado!");
            }

            fReturn.Mensagens = Resposta.Mensagens;
            fReturn.Objeto = fReturn.Sucesso;

            return fReturn;
        }

        public BaseResponse<bool> SalvarTokenPushNotification(string token)
        {
            BaseResponse<bool> tReturn = new BaseResponse<bool>();

            #region validacao

            if (string.IsNullOrWhiteSpace(token))
            {
                Resposta.Mensagens.Add("O token é obrigatório!");
            }

            #endregion

            if (Resposta.Sucesso)
            {
                Colaborador colaborador = _ldteamContext.Colaboradores.FirstOrDefault(c => c.Id == ColaboradorLogado.Id);

                if (colaborador != null)
                {
                    colaborador.TokenPushNotification = token;
                    _ldteamContext.SaveChanges();
                }
            }

            tReturn.Mensagens = Resposta.Mensagens;
            tReturn.Objeto = tReturn.Sucesso;

            return tReturn;
        }

        public BaseResponse<List<CartaoTicket>> ObterCartoesTicket()
        {
            BaseResponse<List<CartaoTicket>> cReturn = new BaseResponse<List<CartaoTicket>>();
            List<CartaoTicket> cartoes = new List<CartaoTicket>();
            var contas = ObterContasAcesso();

            foreach (var conta in contas.Objeto)
            {
                var email = conta.ContasAcessosDados.FirstOrDefault(c => c.TipoContaAcessoCampo.Codigo == "usuario");

                if (email != null && (conta.TipoContaAcesso.Codigo == "tkt"))
                {
                    var senha = conta.ContasAcessosDados.FirstOrDefault(c => c.TipoContaAcessoCampo.Codigo == "senha");

                    if (senha != null)
                    {
                        cartoes.AddRange(TicketService.ObterInformacaoCartoes(email.Valor, senha.Valor, conta.Id));
                    }
                }
            }

            cReturn.Objeto = cartoes;

            return cReturn;
        }

        public BaseResponse<List<ColaboradorContaAcesso>> ObterContasAcesso()
        {
            BaseResponse<List<ColaboradorContaAcesso>> cReturn = new BaseResponse<List<ColaboradorContaAcesso>>();

            var contasAcessos = _ldteamContext.ColaboradoresContasAcessos.Where(c => c.Ativo && c.IdColaborador == ColaboradorLogado.Id).Include("ContasAcessosDados").Include("ContasAcessosDados.TipoContaAcessoCampo").Include("TipoContaAcesso").ToList();

            cReturn.Objeto = contasAcessos;

            return cReturn;
        }

        public BaseResponse<bool> RemoverCartaoTicket(string numero)
        {
            BaseResponse<bool> rReturn = new BaseResponse<bool>();

            #region validation

            if (string.IsNullOrWhiteSpace(numero))
            {
                Resposta.Mensagens.Add("O número do cartão é obrigatório!");
            }

            #endregion

            if (Resposta.Sucesso)
            {
                rReturn.Objeto = TicketService.RemoverCartao(numero);
            }

            rReturn.Mensagens = Resposta.Mensagens;

            return rReturn;
        }

        public BaseResponse<bool> CadastrarCartaoTicket(string numero, string tipo)
        {
            BaseResponse<bool> cReturn = new BaseResponse<bool>();

            #region validation

            if (string.IsNullOrWhiteSpace(numero))
            {
                Resposta.Mensagens.Add("O número do cartão é obrigatório!");
            }
            if (string.IsNullOrWhiteSpace(tipo))
            {
                Resposta.Mensagens.Add("O tipo do cartão é obrigatório!");
            }

            #endregion

            if (Resposta.Sucesso)
            {
                cReturn.Objeto = TicketService.CadastrarCartao(ColaboradorLogado.Email.Split("@")[0], tipo, numero);
            }

            cReturn.Mensagens = Resposta.Mensagens;

            return cReturn;
        }

        public BaseResponse<List<TipoContaAcesso>> ObterTiposContasAcessos()
        {
            BaseResponse<List<TipoContaAcesso>> tReturn = new BaseResponse<List<TipoContaAcesso>>
            {
                Objeto = _ldteamContext.TiposContasAcessos.Where(t => t.Ativo).ToList()
            };

            return tReturn;
        }

        public BaseResponse<bool> AdicionarContaAcesso(AdicionarContaAcessoRequest request)
        {
            BaseResponse<bool> aReturn = new BaseResponse<bool>();

            #region validacao

            if (request == null)
            {
                Resposta.Mensagens.Add("Sem informações necessárias!");
            }

            if (string.IsNullOrWhiteSpace(request.CodigoTipoContaAcesso))
            {
                Resposta.Mensagens.Add("Tipo de acesso é obrigatório!");
            }

            if (request.Campos == null || !request.Campos.Any())
            {
                Resposta.Mensagens.Add("É necessário preencher os campos obrigatórios!");
            }

            #endregion

            if (Resposta.Sucesso)
            {
                TipoContaAcesso tca = _ldteamContext.TiposContasAcessos.Include("Campos").FirstOrDefault(t => t.Codigo == request.CodigoTipoContaAcesso);

                if (tca != null && tca.Campos != null)
                {
                    if (request.CodigoTipoContaAcesso == "tkt")
                    {
                        var email = request.Campos.FirstOrDefault(c => c.Codigo == "usuario");
                        var senha = request.Campos.FirstOrDefault(c => c.Codigo == "senha");

                        if (email != null && senha != null && !string.IsNullOrWhiteSpace(email.Valor) && !string.IsNullOrWhiteSpace(senha.Valor))
                        {
                            if (string.IsNullOrEmpty(TicketService.ObterTokenAcesso(email.Valor, senha.Valor)))
                            {
                                Resposta.Mensagens.Add("Algo deu errado, verifique as informações de e-mail/senha e tente novamente!");
                            }
                        }
                    }

                    if (Resposta.Sucesso)
                    {
                        ColaboradorContaAcesso cca = new ColaboradorContaAcesso();
                        cca.IdColaborador = ColaboradorLogado.Id;
                        cca.DataCadastro = DateTime.Now;
                        cca.IdTipoContaAcesso = tca.Id;
                        cca.Ativo = true;

                        _ldteamContext.ColaboradoresContasAcessos.Add(cca);
                        _ldteamContext.SaveChanges();

                        List<ColaboradorContaAcessoDado> dados = new List<ColaboradorContaAcessoDado>();

                        try
                        {
                            foreach (var item in tca.Campos)
                            {
                                var campo = request.Campos.FirstOrDefault(c => c.Codigo == item.Codigo);

                                if (campo != null)
                                {
                                    ColaboradorContaAcessoDado ccad = new ColaboradorContaAcessoDado();
                                    ccad.IdColaboradorContaAcesso = cca.Id;
                                    ccad.IdTipoContaAcessoCampo = item.Id;
                                    ccad.Valor = campo.Valor;

                                    dados.Add(ccad);
                                }
                            }

                            _ldteamContext.ColaboradoresContasAcessosDados.AddRange(dados);
                            _ldteamContext.SaveChanges();
                        }
                        catch (Exception)
                        {
                            Resposta.Mensagens.Add("Algo deu errado ao tentar salvar as informações da conta de acesso!");

                            _ldteamContext.ColaboradoresContasAcessos.Remove(cca);
                            _ldteamContext.SaveChanges();
                        }
                    }
                }
                else
                {
                    Resposta.Mensagens.Add("Nenhum campo cadastrado para esse tipo de conta de acesso!");
                }
            }

            aReturn.Mensagens = Resposta.Mensagens;
            aReturn.Objeto = aReturn.Sucesso;

            return aReturn;
        }

        public BaseResponse<Riocard> ObterCartaoRiocard(string email, string senha, string cartao)
        {
            BaseResponse<Riocard> rReturn = new BaseResponse<Riocard>();

            #region validacao

            if (string.IsNullOrWhiteSpace(email))
            {
                Resposta.Mensagens.Add("Email é obrigatório!");
            }
            if (string.IsNullOrWhiteSpace(senha))
            {
                Resposta.Mensagens.Add("Senha é obrigatória!");
            }

            #endregion

            if (Resposta.Sucesso)
            {
                var riocard = RiocardService.ObterCartao(email, senha, cartao);

                if (riocard != null)
                {
                    rReturn.Objeto = riocard;
                }
                else
                {
                    Resposta.Mensagens.Add("Não foi possível obter informações desse riocard!");
                }
            }

            rReturn.Mensagens = Resposta.Mensagens;

            return rReturn;
        }

        public BaseResponse<bool> RemoverContaAcesso(int idContaAcesso)
        {
            BaseResponse<bool> aReturn = new BaseResponse<bool>();

            #region validacao

            if (idContaAcesso == 0)
            {
                Resposta.Mensagens.Add("Sem informações necessárias!");
            }

            #endregion

            if (Resposta.Sucesso)
            {
                ColaboradorContaAcesso cca = _ldteamContext.ColaboradoresContasAcessos.FirstOrDefault(c => c.Id == idContaAcesso && c.IdColaborador == ColaboradorLogado.Id);

                if (cca != null)
                {
                    cca.Ativo = false;
                    cca.DataDesativacao = DateTime.Now;

                    _ldteamContext.SaveChanges();
                }
                else
                {
                    Resposta.Mensagens.Add("Nenhum campo cadastrado para esse tipo de conta de acesso!");
                }
            }

            aReturn.Mensagens = Resposta.Mensagens;
            aReturn.Objeto = aReturn.Sucesso;

            return aReturn;
        }
    }
}