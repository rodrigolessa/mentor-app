using System;
using System.Linq;
using LDTeam.Application.Models.Response;
using Microsoft.Extensions.Configuration;
using LDTeam.Application.Models;

namespace LDTeam.Application.App
{
    public class CalendarioAppService : BaseAppService
    {
        private readonly IConfiguration _configuration;

        public CalendarioAppService()
        {
            swTempoRequisicao.Start();
        }

        public CalendarioAppService(IConfiguration configuration)
        {
            swTempoRequisicao.Start();
            _configuration = configuration;
        }

        public BaseResponse<Calendario> Obter(string dataInicial, string dataFinal)
        {
            BaseResponse<Calendario> cReturn = new BaseResponse<Calendario>();

            #region validation

            if (string.IsNullOrWhiteSpace(dataInicial))
            {
                Resposta.Mensagens.Add("A data inicial � obrigat�ria!");
            }
            if (string.IsNullOrWhiteSpace(dataFinal))
            {
                Resposta.Mensagens.Add("A data final � obrigat�ria!");
            }

            #endregion

            if (Resposta.Sucesso)
            {
                cReturn.Objeto = MicrosoftService.ObterCalendario(ColaboradorLogado.Email, dataInicial, dataFinal);

                if (cReturn.Objeto != null && cReturn.Objeto.Itens != null)
                {
                    cReturn.Objeto.Itens = cReturn.Objeto.Itens.Where(i => DateTime.Parse(i.Data).Date >= DateTime.Parse(dataInicial).Date).ToList();
                }
            }

            cReturn.Mensagens = Resposta.Mensagens;

            return cReturn;
        }
    }
}