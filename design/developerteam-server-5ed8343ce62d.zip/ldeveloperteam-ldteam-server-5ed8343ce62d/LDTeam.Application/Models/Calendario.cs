using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace LDTeam.Application.Models
{
    public class Calendario
    {
        public Calendario()
        {
        }

        public Calendario(Calendario entidade)
        {
            Nome = entidade.Nome;
            Cor = entidade.Cor;
            Itens = entidade.Itens;
        }

        public string Nome { get; set; }
        public string Cor { get; set; }
        public List<ItemCalendario> Itens { get; set; }
    }
}