﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LDTeam.Application.Models
{
    public enum SistemaEnum
    {
        Aplicativo = 1,
        Intranet = 2
    }
}
