using System.Collections.Generic;
using LDTeam.Application.Models;

namespace LDTeam.Webapi.Request
{
    public class AdicionarContaAcessoRequest
    {
        public string CodigoTipoContaAcesso { get; set; }
        public List<AdicionarContaAcessoCampo> Campos { get; set; }
    }
}