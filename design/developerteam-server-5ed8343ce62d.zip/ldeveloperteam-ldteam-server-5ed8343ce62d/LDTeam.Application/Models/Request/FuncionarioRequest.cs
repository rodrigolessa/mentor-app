namespace LDTeam.Webapi.Request
{
    public class FuncionarioRequest
    {
        public string Usuario { get; set; }
        public string Senha { get; set; }
        public int Sistema { get; set; }
    }
}