using System;
using Newtonsoft.Json;

namespace LDTeam.Application.Models
{
    public class PeriodoPonto
    {
        public PeriodoPonto()
        {
        }

        public PeriodoPonto(PeriodoPonto entidade)
        {
            DataInicio = entidade.DataInicio;
            DataFim = entidade.DataFim;
        }

        public DateTime DataInicio { get; set; }
        public DateTime DataFim { get; set; }
    }
}