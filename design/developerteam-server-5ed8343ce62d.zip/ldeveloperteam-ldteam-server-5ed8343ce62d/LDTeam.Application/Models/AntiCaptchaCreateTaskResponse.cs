﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LDTeam.Application.Models
{
    public class AntiCaptchaCreateTaskResponse
    {
        public long errorId { get; set; }
        public long taskId { get; set; }
        public string errorCode { get; set; }
        public string errorDescription { get; set; }
    }
}
