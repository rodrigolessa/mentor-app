﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LDTeam.Application.Models
{
    public class AntiCaptchaSolutionResponse
    {
        public string gRecaptchaResponse { get; set; }
    }
}
