using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace LDTeam.Application.Models
{
    public class ItemCalendario
    {
        public ItemCalendario()
        {
        }

        public ItemCalendario(ItemCalendario entidade)
        {
            Id = entidade.Id;
            Nome = entidade.Nome;
            DataInicio = entidade.DataInicio;
            DataFim = entidade.DataFim;
            FoiCancelado = entidade.FoiCancelado;
            Local = entidade.Local;
            Organizador = entidade.Organizador;
            Link = entidade.Link;
            StatusResposta = entidade.StatusResposta;
            DiaTodo = entidade.DiaTodo;
            Participantes = entidade.Participantes;
            Descricao = entidade.Descricao;
        }

        public string Id { get; set; }
        public string Nome { get; set; }
        public string Data { get; set; }
        public string Hora { get; set; }
        public DateTime DataInicio { get; set; }
        public DateTime DataFim { get; set; }
        public bool DiaTodo { get; set; }
        public string FoiCancelado { get; set; }
        public string Local { get; set; }
        public string Organizador { get; set; }
        public string Link { get; set; }
        public List<string> Participantes { get; set; }
        public string StatusResposta { get; set; }
        public string Descricao { get; set; }
    }
}