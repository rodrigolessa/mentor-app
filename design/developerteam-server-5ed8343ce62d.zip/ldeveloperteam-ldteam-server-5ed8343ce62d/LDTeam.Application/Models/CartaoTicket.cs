using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace LDTeam.Application.Models
{
    public class CartaoTicket
    {
        public CartaoTicket()
        {
        }

        public string Apelido { get; set; }
        public string Tipo { get; set; }
        public string Email { get; set; }
        public int IdContaAcesso { get; set; }
        public string Numero { get; set; }
        public string ValorTexto { get; set; }
        public double Valor { get; set; }
        public double MediaDiaria { get; set; }
        public string DataProximoDeposito { get; set; }
        public List<AgendamentoCartaoTicket> Agendamentos { get; set; }
        public List<GastoCartaoTicket> Gastos { get; set; }
    }
}