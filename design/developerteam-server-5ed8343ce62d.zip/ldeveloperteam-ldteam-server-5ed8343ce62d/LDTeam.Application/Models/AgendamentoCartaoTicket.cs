using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace LDTeam.Application.Models
{
    public class AgendamentoCartaoTicket
    {
        public AgendamentoCartaoTicket()
        {
        }

        public string Data { get; set; }
        public string ValorTexto { get; set; }
        public double Valor { get; set; }
        public string Descricao { get; set; }
    }
}