﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LDTeam.Application.Models
{
    public class Riocard
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Number { get; set; }
        public string Balance { get; set; }
        public string ImgUrl
        {
            get
            {
                return "https://www.cartaoriocard.com.br/meuextrato/cartoes/exibeImagemCartao/?numeroCartao=" + Id;
            }
        }
        public List<RiocardRecharge> Recharges { get; set; }
        public List<RiocardExtract> Extracts { get; set; }
    }
}