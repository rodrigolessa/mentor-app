using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace LDTeam.Application.Models
{
    public class AdicionarContaAcessoCampo
    {
        public AdicionarContaAcessoCampo()
        {
        }

        public string Codigo { get; set; }
        public string Valor { get; set; }
    }
}