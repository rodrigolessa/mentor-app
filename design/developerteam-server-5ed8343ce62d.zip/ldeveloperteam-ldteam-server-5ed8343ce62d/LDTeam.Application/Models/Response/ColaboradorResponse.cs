using LDTeam.Infrastructure.Ldteam.Entities;

namespace LDTeam.Application.Models.Response
{
    public class ColaboradorResponse 
    {
        public Colaborador Colaborador { get; set; }
        public string Token { get; set; }
    }
}