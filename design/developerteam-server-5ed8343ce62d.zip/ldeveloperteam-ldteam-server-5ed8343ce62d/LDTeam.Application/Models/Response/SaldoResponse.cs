namespace LDTeam.Application.Models.Response
{
    public class SaldoResponse 
    {
        public string Saldo { get; set; }
        public PeriodoPonto Periodo { get; set; }
    }
}