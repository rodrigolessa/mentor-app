using System;
using Newtonsoft.Json;

namespace LDTeam.Application.Models
{
    public class Funcionario
    {
        public Funcionario()
        {
        }

        public Funcionario(Funcionario entidade)
        {
            Nome = entidade.Nome;
            Email = entidade.Email;
            Ramal = entidade.Ramal;
            FotoUrl = entidade.FotoUrl;
            Celular = entidade.Celular;
            DataNascimento = entidade.DataNascimento;
            Token = entidade.Token;
            DN = entidade.DN;
            SAM = entidade.SAM;
            CriacaoToken = entidade.CriacaoToken;
        }

        public string Nome { get; set; }
        public string Email { get; set; }
        public string Ramal { get; set; }
        public string FotoUrl { get; set; }
        public string Celular { get; set; }
        public DateTime DataNascimento { get; set; }

        //PROPRIEDADES DE CONFIGURACAO
        public string Token { get; set; }
        [JsonIgnore]
        public string DN { get; set; }
        [JsonIgnore]
        public string SAM { get; set; }
        [JsonIgnore]
        public DateTime CriacaoToken { get; set; }
    }
}