using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace LDTeam.Application.Models
{
    public class ConsumoPonto
    {
        public ConsumoPonto()
        {
        }

        public int SaldoMinutos { get; set; }
        public string Obs { get; set; }
        public string Data { get; set; }
        public bool Justificativa { get; set; }
        public bool ErroPonto { get; set; }
        public string MensagemErroPonto { get; set; }

        public List<string> Marcacoes
        {
            get; set;
        }
    }
}