﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LDTeam.Application.Models
{
    public class RiocardRecharge
    {
        public string Number { get; set; }
        public string Value { get; set; }
        public string Date { get; set; }
    }
}