using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace LDTeam.Application.Models
{
    public class PitacosRanking
    {
        public PitacosRanking()
        {
        }

        public PitacosRanking(PitacosRanking entidade)
        {
            Colocacao = entidade.Colocacao;
            Nome = entidade.Nome;
            Email = entidade.Email;
            Pontuacao = entidade.Pontuacao;
        }

        public string Id { get; set; }
        public string Colocacao { get; set; }
        public string Nome { get; set; }
        public string Pontuacao { get; set; }
        public string Email { get; set; }
    }
}