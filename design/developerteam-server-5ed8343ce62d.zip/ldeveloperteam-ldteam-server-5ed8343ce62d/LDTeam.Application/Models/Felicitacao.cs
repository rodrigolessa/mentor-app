using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace LDTeam.Application.Models
{
    public class Felicitacao
    {
        public Felicitacao()
        {
        }

        public int IdColaboradorFelicitacao { get; set; }
        public string FotoUrl { get; set; }
        public string Nome { get; set; }
        public string Mensagem { get; set; }
        public DateTime Data { get; set; }
    }
}