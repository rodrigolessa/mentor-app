using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace LDTeam.Application.Models
{
    public class ErroPonto
    {
        public ErroPonto()
        {
        }

        public ErroPonto(ErroPonto entidade)
        {
            Nome = entidade.Nome;
            Id = entidade.Id;
            Data = entidade.Data;
            Marcacoes = entidade.Marcacoes;
        }

        public string Id { get; set; }
        public string Nome { get; set; }
        public string Data { get; set; }
        public List<string> Marcacoes { get; set; }
    }
}