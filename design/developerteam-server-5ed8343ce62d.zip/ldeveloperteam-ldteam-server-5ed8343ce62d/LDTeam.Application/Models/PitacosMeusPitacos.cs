using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace LDTeam.Application.Models
{
    public class PitacosMeusPitacos
    {
        public PitacosMeusPitacos()
        {
        }

        public PitacosMeusPitacos(PitacosMeusPitacos entidade)
        {
            Id = entidade.Id;
            Data = entidade.Data;
            Hora = entidade.Hora;
            TimeA = entidade.TimeA;
            TimeB = entidade.TimeB;
            PlacarA = entidade.PlacarA;
            PlacarB = entidade.PlacarB;
            ImgA = entidade.ImgA;
            ImgB = entidade.ImgB;
            Pontos = entidade.Pontos;
            PlacarFinalA = entidade.PlacarFinalA;
            PlacarFinalB = entidade.PlacarFinalB;
        }

        public string Id { get; set; }
        public string Data { get; set; }
        public string Hora { get; set; }
        public string TimeA { get; set; }
        public string TimeB { get; set; }
        public string PlacarA { get; set; }
        public string PlacarB { get; set; }
        public string PlacarFinalA { get; set; }
        public string PlacarFinalB { get; set; }
        public string Pontos { get; set; }
        public string ImgA { get; set; }
        public string ImgB { get; set; }
    }
}