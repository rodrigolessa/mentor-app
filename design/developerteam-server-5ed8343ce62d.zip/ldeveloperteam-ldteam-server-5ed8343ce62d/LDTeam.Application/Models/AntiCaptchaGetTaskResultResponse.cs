﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LDTeam.Application.Models
{
    public class AntiCaptchaGetTaskResultResponse
    {
        public long errorId { get; set; }
        public string status { get; set; }
        public AntiCaptchaSolutionResponse solution { get; set; }
        public string cost { get; set; }
        public string ip { get; set; }
        public long createTime { get; set; }
        public long endTime { get; set; }
        public string solveCount { get; set; }
    }
}
