﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LDTeam.Application.Models
{
    public class RiocardExtract
    {
        public string Number { get; set; }
        public string Value { get; set; }
        public string Date { get; set; }
        public string Company { get; set; }
        public string Line { get; set; }
        public string Balance { get; set; }
    }
}