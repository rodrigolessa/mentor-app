﻿using LDTeam.Infrastructure.Ldteam;
using LDTeam.Infrastructure.Ldteam.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using RestSharp;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;

namespace LDTeam.Terminal
{
    class Program
    {
        const string APP_ID = "f0a14105-c429-41c2-909f-b66be35b7bd4";
        const string CHAVE_PRIVADA = "MDY3ZTc1YzUtY2MwOS00ZDNjLWFmNmUtODA3Nzg0OWE4MzU4";
        const string URL_API_NOTIFICACAO = "https://onesignal.com/api/v1/notifications";

        static void Main(string[] args)
        {
            Console.WriteLine(DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss") + " - Iniciando...");
            Console.WriteLine(DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss") + " - Diretorio: " + Directory.GetCurrentDirectory());

            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json");

            var configuration = builder.Build();

            var optionsBuilder = new DbContextOptionsBuilder<LdteamContext>();
            optionsBuilder.UseSqlServer(configuration.GetConnectionString("LdteamContext"));

            try
            {
                while (true)
                {
                    Console.WriteLine("");
                    Console.WriteLine(DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss") + " - Conectando no banco e obtendo notificações pendentes...");

                    using (LdteamContext _ldteamContext = new LdteamContext(optionsBuilder.Options))
                    {
                        var dataHoje = DateTime.Now;
                        Empresa empresa = _ldteamContext.Empresas.FirstOrDefault(c => c.Codigo == "ldsoft");

                        if (empresa != null)
                        {
                            List<PushNotificacao> notificacoes = _ldteamContext.PushNotificacoes.Where(p => p.DataEnvio <= dataHoje && !p.Finalizado).ToList();

                            foreach (var item in notificacoes)
                            {
                                bool enviado = false;

                                if (item.ValorDestino == "aniversario")
                                {
                                    List<Colaborador> colaboradores = _ldteamContext.Colaboradores.Where(c => c.Ativo && c.IdEmpresa == empresa.Id && c.DataAniversario.Value.Month == DateTime.Now.Month && c.DataAniversario.Value.Day == DateTime.Now.Day).ToList();

                                    item.Titulo = colaboradores.Count > 1 ? "Aniversariantes do dia" : (colaboradores.Count == 0 ? "" : "Aniversariante do dia");
                                    item.Corpo = colaboradores.Count > 1 ? string.Join(", ", colaboradores.Select(c => c.Nome)) : (colaboradores.Count == 0 ? "" : colaboradores[0].Nome);
                                }

                                if (!string.IsNullOrWhiteSpace(item.Corpo))
                                {
                                    if (item.EhTodos)
                                    {
                                        enviado = EnviarNotificacaoDiariaTodos(item.Titulo, item.Subtitulo, item.Corpo);
                                    }
                                    else if (item.EhDepartamento)
                                    {
                                        enviado = EnviarNotificacaoDepartamento(item.ValorDestino, item.Titulo, item.Subtitulo, item.Corpo);
                                    }
                                    else if (item.EhUsuario)
                                    {
                                        enviado = EnviarNotificacaoUsuario(item.ValorDestino, item.Titulo, item.Subtitulo, item.Corpo);
                                    }
                                }
                                else
                                {
                                    enviado = true;
                                }

                                if (enviado)
                                {
                                    if (item.EhRecorrente)
                                    {
                                        item.DataEnvio = item.DataEnvio.AddMinutes(item.MinutosRecorrente);
                                    }
                                    else
                                    {
                                        item.Finalizado = true;
                                    }

                                    _ldteamContext.SaveChanges();
                                }
                            }
                        }
                    }

                    Console.WriteLine("");
                    Console.WriteLine(DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss") + " - Verificação finalizada, próxima verificação daqui a 30 segundos...");

                    Thread.Sleep(30000);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("");
                Console.WriteLine(DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss") + " - " + ex.ToString());
            }

            Console.ReadKey();
        }

        static bool EnviarNotificacaoDiariaTodos(string titulo, string subtitulo, string corpo)
        {
            var client = new RestClient(URL_API_NOTIFICACAO);
            var request = new RestRequest(Method.POST);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Authorization", $"Basic {CHAVE_PRIVADA}");
            request.AddParameter("undefined", "{\n\t\"app_id\": \"" + APP_ID + "\",\n\t\"included_segments\": [\"All\"],\n\t\"data\": {\"foo\": \"bar\"},\n\t\"contents\": {\"en\": \"" + corpo + "\"},\n\t\"headings\": {\"en\": \"" + titulo + "\"},\n  \"subtitle\": {\"en\": \"" + (string.IsNullOrWhiteSpace(subtitulo) ? "" : subtitulo) + "\"},\n\t\"ios_badgeType\": \"Increase\",\n\t\"ios_badgeCount\": 1\n}", ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);

            return response.StatusCode == System.Net.HttpStatusCode.OK;
        }

        static bool EnviarNotificacaoUsuario(string usuario, string titulo, string subtitulo, string corpo)
        {
            var client = new RestClient(URL_API_NOTIFICACAO);
            var request = new RestRequest(Method.POST);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Authorization", $"Basic {CHAVE_PRIVADA}");
            request.AddParameter("undefined", " {\n   \"app_id\": \"" + APP_ID + "\",\n  \"filters\": [\n      {\"field\": \"tag\", \"key\": \"usuario\", \"relation\": \"=\", \"value\": \"" + usuario + "\"}\n  ],\n  \"data\": {\"foo\": \"bar\"},\n  \"contents\": {\"en\": \"" + corpo + "\"},\n  \"headings\": {\"en\": \"" + titulo + "\"},\n  \"subtitle\": {\"en\": \"" + (string.IsNullOrWhiteSpace(subtitulo) ? "" : subtitulo) + "\"},\n  \"ios_badgeType\": \"Increase\",\n  \"ios_badgeCount\": 1\n  }", ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);

            return response.StatusCode == System.Net.HttpStatusCode.OK;
        }

        static bool EnviarNotificacaoDepartamento(string departamento, string titulo, string subtitulo, string corpo)
        {
            var client = new RestClient(URL_API_NOTIFICACAO);
            var request = new RestRequest(Method.POST);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Authorization", $"Basic {CHAVE_PRIVADA}");
            request.AddParameter("undefined", " {\n   \"app_id\": \"" + APP_ID + "\",\n  \"filters\": [\n      {\"field\": \"tag\", \"key\": \"departamento\", \"relation\": \"=\", \"value\": \"" + departamento + "\"}\n  ],\n  \"data\": {\"foo\": \"bar\"},\n  \"contents\": {\"en\": \"" + corpo + "\"},\n  \"headings\": {\"en\": \"" + titulo + "\"},\n  \"subtitle\": {\"en\": \"" + (string.IsNullOrWhiteSpace(subtitulo) ? "" : subtitulo) + "\"},\n  \"ios_badgeType\": \"Increase\",\n  \"ios_badgeCount\": 1\n  }", ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);

            return response.StatusCode == System.Net.HttpStatusCode.OK;
        }
    }
}
