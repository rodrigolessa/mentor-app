using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using LDTeam.Infrastructure.Ldteam.Entities;

namespace LDTeam.Infrastructure.Ldteam.Maps
{
    public class ColaboradorTokenConfig : IEntityTypeConfiguration<ColaboradorToken>
    {
        public void Configure(EntityTypeBuilder<ColaboradorToken> builder)
        {
            builder.ToTable("COLABORADORES_TOKENS");

            builder.HasKey(u => u.Id);
            builder.Property(u => u.Id).HasColumnName("Id");
            builder.Property(u => u.IdColaborador).HasColumnName("IdColaborador");
            builder.Property(u => u.Token).HasColumnName("Token");
            builder.Property(u => u.Sistema).HasColumnName("Sistema");
            builder.Property(u => u.DataCadastro).HasColumnName("DataCadastro");
            builder.Property(u => u.Ativo).HasColumnName("Ativo");
            builder.Property(u => u.DataDesativacao).HasColumnName("DataDesativacao");

            // builder.HasOne(c => c.Colaborador).WithOne()
                //    .HasForeignKey<ColaboradorToken>(c => c.IdColaborador);
        }
    }
}