using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using LDTeam.Infrastructure.Ldteam.Entities;

namespace LDTeam.Infrastructure.Ldteam.Maps
{
    public class ColaboradorNotificacaoConfig : IEntityTypeConfiguration<ColaboradorNotificacao>
    {
        public void Configure(EntityTypeBuilder<ColaboradorNotificacao> builder)
        {
            builder.ToTable("COLABORADORES_NOTIFICACOES");

            builder.HasKey(u => u.Id);
            builder.Property(u => u.Id).HasColumnName("Id");
            builder.Property(u => u.Argumentos).HasColumnName("Argumentos");
            builder.Property(u => u.DataAlteracaoStatus).HasColumnName("DataAlteracaoStatus");
            builder.Property(u => u.DataCadastro).HasColumnName("DataCadastro");
            builder.Property(u => u.IdColaborador).HasColumnName("IdColaborador");

            builder.Property(u => u.IdTipoNotificacao).HasColumnName("IdTipoNotificacao");
            builder.Property(u => u.StatusNotificacao).HasColumnName("StatusNotificacao");
            builder.Property(u => u.Valor).HasColumnName("Valor");
            
            builder.HasOne(c => c.TipoNotificacao).WithMany().HasForeignKey(c => c.IdTipoNotificacao);
        }
    }
}