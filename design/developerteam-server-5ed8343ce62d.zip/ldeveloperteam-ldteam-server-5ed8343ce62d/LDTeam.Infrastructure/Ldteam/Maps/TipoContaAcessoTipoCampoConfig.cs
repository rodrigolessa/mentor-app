using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using LDTeam.Infrastructure.Ldteam.Entities;

namespace LDTeam.Infrastructure.Ldteam.Maps
{
    public class TipoContaAcessoTipoCampoConfig : IEntityTypeConfiguration<TipoContaAcessoTipoCampo>
    {
        public void Configure(EntityTypeBuilder<TipoContaAcessoTipoCampo> builder)
        {
            builder.ToTable("TIPOS_CONTAS_ACESSOS_TIPOS_CAMPOS");

            builder.HasKey(u => u.Id);
            builder.Property(u => u.Id).HasColumnName("Id");
            builder.Property(u => u.Codigo).HasColumnName("Codigo");
            builder.Property(u => u.Nome).HasColumnName("Nome");
        }
    }
}