using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using LDTeam.Infrastructure.Ldteam.Entities;

namespace LDTeam.Infrastructure.Ldteam.Maps
{
    public class ColaboradorContaAcessoConfig : IEntityTypeConfiguration<ColaboradorContaAcesso>
    {
        public void Configure(EntityTypeBuilder<ColaboradorContaAcesso> builder)
        {
            builder.ToTable("COLABORADORES_CONTAS_ACESSOS");

            builder.HasKey(u => u.Id);
            builder.Property(u => u.Id).HasColumnName("Id");
            builder.Property(u => u.IdColaborador).HasColumnName("IdColaborador");
            builder.Property(u => u.IdTipoContaAcesso).HasColumnName("IdTipoContaAcesso");
            builder.Property(u => u.DataCadastro).HasColumnName("DataCadastro");
            builder.Property(u => u.Ativo).HasColumnName("Ativo");
            builder.Property(u => u.DataDesativacao).HasColumnName("DataDesativacao");
            
            builder.HasOne(c => c.TipoContaAcesso).WithMany().HasForeignKey(c => c.IdTipoContaAcesso);
            builder.HasMany(u => u.ContasAcessosDados).WithOne().HasForeignKey(c => c.IdColaboradorContaAcesso);
        }
    }
}