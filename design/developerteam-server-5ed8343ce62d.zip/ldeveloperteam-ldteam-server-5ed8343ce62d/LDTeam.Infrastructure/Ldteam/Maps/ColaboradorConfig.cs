using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using LDTeam.Infrastructure.Ldteam.Entities;

namespace LDTeam.Infrastructure.Ldteam.Maps
{
    public class ColaboradorConfig : IEntityTypeConfiguration<Colaborador>
    {
        public void Configure(EntityTypeBuilder<Colaborador> builder)
        {
            builder.ToTable("COLABORADORES");

            builder.HasKey(u => u.Id);
            builder.Property(u => u.Id).HasColumnName("Id");
            builder.Property(u => u.IdEmpresa).HasColumnName("IdEmpresa");
            builder.Property(u => u.FotoUrl).HasColumnName("FotoUrl");
            builder.Property(u => u.Nome).HasColumnName("Nome");
            builder.Property(u => u.DataAniversario).HasColumnName("DataAniversario");
            builder.Property(u => u.Celular).HasColumnName("Celular");
            builder.Property(u => u.Ramal).HasColumnName("Ramal");
            builder.Property(u => u.Departamento).HasColumnName("Departamento");
            builder.Property(u => u.IdentificadorPonto).HasColumnName("IdentificadorPonto");
            builder.Property(u => u.Email).HasColumnName("Email");
            builder.Property(u => u.Senha).HasColumnName("Senha");
            builder.Property(u => u.TokenPushNotification).HasColumnName("TokenPushNotification");
            builder.Property(u => u.EhBeta).HasColumnName("EhBeta");
            builder.Property(u => u.DataCadastro).HasColumnName("DataCadastro");
            builder.Property(u => u.Ativo).HasColumnName("Ativo");
            builder.Property(u => u.DataDesativacao).HasColumnName("DataDesativacao");

            builder.HasMany(u => u.ContasAcessos).WithOne().HasForeignKey(c => c.IdColaborador);
            builder.HasMany(u => u.Notificacoes).WithOne().HasForeignKey(c => c.IdColaborador);
            builder.HasOne(c => c.Empresa).WithMany().HasForeignKey(c => c.IdEmpresa);
        }
    }
}