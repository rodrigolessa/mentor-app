using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using LDTeam.Infrastructure.Ldteam.Entities;

namespace LDTeam.Infrastructure.Ldteam.Maps
{
    public class ColaboradorContaAcessoDadoConfig : IEntityTypeConfiguration<ColaboradorContaAcessoDado>
    {
        public void Configure(EntityTypeBuilder<ColaboradorContaAcessoDado> builder)
        {
            builder.ToTable("COLABORADORES_CONTAS_ACESSOS_DADOS");

            builder.HasKey(u => u.Id);
            builder.Property(u => u.Id).HasColumnName("Id");
            builder.Property(u => u.IdColaboradorContaAcesso).HasColumnName("IdColaboradorContaAcesso");
            builder.Property(u => u.IdTipoContaAcessoCampo).HasColumnName("IdTipoContaAcessoCampo");
            builder.Property(u => u.Valor).HasColumnName("Valor");

            builder.HasOne(c => c.TipoContaAcessoCampo).WithMany().HasForeignKey(c => c.IdTipoContaAcessoCampo);
        }
    }
}