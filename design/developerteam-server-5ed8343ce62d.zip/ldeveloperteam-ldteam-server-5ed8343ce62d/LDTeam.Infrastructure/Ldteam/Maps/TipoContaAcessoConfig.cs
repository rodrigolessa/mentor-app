using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using LDTeam.Infrastructure.Ldteam.Entities;

namespace LDTeam.Infrastructure.Ldteam.Maps
{
    public class TipoContaAcessoConfig : IEntityTypeConfiguration<TipoContaAcesso>
    {
        public void Configure(EntityTypeBuilder<TipoContaAcesso> builder)
        {
            builder.ToTable("TIPOS_CONTAS_ACESSOS");

            builder.HasKey(u => u.Id);
            builder.Property(u => u.Id).HasColumnName("Id");
            builder.Property(u => u.LogoUrl).HasColumnName("LogoUrl");
            builder.Property(u => u.Nome).HasColumnName("Nome");
            builder.Property(u => u.Codigo).HasColumnName("Codigo");
            builder.Property(u => u.Ativo).HasColumnName("Ativo");
            builder.Property(u => u.DataDesativacao).HasColumnName("DataDesativacao");

            builder.HasMany(u => u.Campos).WithOne().HasForeignKey(c => c.IdTipoContaAcesso);
        }
    }
}