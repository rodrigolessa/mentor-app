using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using LDTeam.Infrastructure.Ldteam.Entities;

namespace LDTeam.Infrastructure.Ldteam.Maps
{
    public class TipoNotificacaoConfig : IEntityTypeConfiguration<TipoNotificacao>
    {
        public void Configure(EntityTypeBuilder<TipoNotificacao> builder)
        {
            builder.ToTable("TIPOS_NOTIFICACOES");

            builder.HasKey(u => u.Id);
            builder.Property(u => u.Id).HasColumnName("Id");
            builder.Property(u => u.Codigo).HasColumnName("Codigo");
            builder.Property(u => u.Nome).HasColumnName("Nome");
        }
    }
}