using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using LDTeam.Infrastructure.Ldteam.Entities;

namespace LDTeam.Infrastructure.Ldteam.Maps
{
    public class EmpresaConfiguracaoConfig : IEntityTypeConfiguration<EmpresaConfiguracao>
    {
        public void Configure(EntityTypeBuilder<EmpresaConfiguracao> builder)
        {
            builder.ToTable("EMPRESAS_CONFIGURACOES");

            builder.HasKey(u => u.Id);
            builder.Property(u => u.Id).HasColumnName("Id");
            builder.Property(u => u.IdEmpresa).HasColumnName("IdEmpresa");
            builder.Property(u => u.UsaLoginAD).HasColumnName("UsaLoginAD");
            builder.Property(u => u.UsaLoginEmail).HasColumnName("UsaLoginEmail");
            builder.Property(u => u.HostAD).HasColumnName("HostAD");
            builder.Property(u => u.DominioAD).HasColumnName("DominioAD");
            builder.Property(u => u.PortaAD).HasColumnName("PortaAD");
            builder.Property(u => u.UsuarioAD).HasColumnName("UsuarioAD");
            builder.Property(u => u.SenhaAD).HasColumnName("SenhaAD");
            builder.Property(u => u.DominioEmail).HasColumnName("DominioEmail");
            builder.Property(u => u.HostEmail).HasColumnName("HostEmail");
            builder.Property(u => u.PortaEmail).HasColumnName("PortaEmail");
            builder.Property(u => u.UsaSSLEmail).HasColumnName("UsaSSLEmail");
            builder.Property(u => u.UsuarioEmail).HasColumnName("UsuarioEmail");
            builder.Property(u => u.SenhaEmail).HasColumnName("SenhaEmail");
        }
    }
}