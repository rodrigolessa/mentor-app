using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using LDTeam.Infrastructure.Ldteam.Entities;

namespace LDTeam.Infrastructure.Ldteam.Maps
{
    public class TipoContaAcessoCampoConfig : IEntityTypeConfiguration<TipoContaAcessoCampo>
    {
        public void Configure(EntityTypeBuilder<TipoContaAcessoCampo> builder)
        {
            builder.ToTable("TIPOS_CONTAS_ACESSOS_CAMPOS");

            builder.HasKey(u => u.Id);
            builder.Property(u => u.Id).HasColumnName("Id");
            builder.Property(u => u.IdTipoContaAcesso).HasColumnName("IdTipoContaAcesso");
            builder.Property(u => u.IdTipoContaAcessoTipoCampo).HasColumnName("IdTipoContaAcessoTipoCampo");
            builder.Property(u => u.Nome).HasColumnName("Nome");
            builder.Property(u => u.Codigo).HasColumnName("Codigo");
            
            builder.HasOne(c => c.TipoContaAcessoTipoCampo).WithMany().HasForeignKey(c => c.IdTipoContaAcessoTipoCampo);
        }
    }
}