using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using LDTeam.Infrastructure.Ldteam.Entities;

namespace LDTeam.Infrastructure.Ldteam.Maps
{
    public class PushNotificacaoConfig : IEntityTypeConfiguration<PushNotificacao>
    {
        public void Configure(EntityTypeBuilder<PushNotificacao> builder)
        {
            builder.ToTable("PUSH_NOTIFICACOES");

            builder.HasKey(u => u.Id);
            builder.Property(u => u.Id).HasColumnName("Id");
            builder.Property(u => u.Titulo).HasColumnName("Titulo");
            builder.Property(u => u.Subtitulo).HasColumnName("Subtitulo");
            builder.Property(u => u.Corpo).HasColumnName("Corpo");
            builder.Property(u => u.ValorDestino).HasColumnName("ValorDestino");
            builder.Property(u => u.DataEnvio).HasColumnName("DataEnvio");
            builder.Property(u => u.EhTodos).HasColumnName("EhTodos");
            builder.Property(u => u.EhDepartamento).HasColumnName("EhDepartamento");
            builder.Property(u => u.EhUsuario).HasColumnName("EhUsuario");
            builder.Property(u => u.EhRecorrente).HasColumnName("EhRecorrente");
            builder.Property(u => u.MinutosRecorrente).HasColumnName("MinutosRecorrente");
            builder.Property(u => u.Finalizado).HasColumnName("Finalizado");
        }
    }
}