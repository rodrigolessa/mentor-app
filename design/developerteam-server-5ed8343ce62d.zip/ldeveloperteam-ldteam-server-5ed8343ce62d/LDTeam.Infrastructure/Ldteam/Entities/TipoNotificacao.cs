namespace LDTeam.Infrastructure.Ldteam.Entities
{
    public class TipoNotificacao
    {
        public TipoNotificacao()
        {
        }

        public int Id { get; set; }
        public string Codigo { get; set; }
        public string Nome { get; set; }
    }
}