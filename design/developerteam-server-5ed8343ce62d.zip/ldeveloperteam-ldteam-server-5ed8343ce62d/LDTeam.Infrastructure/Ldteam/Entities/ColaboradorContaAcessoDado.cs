namespace LDTeam.Infrastructure.Ldteam.Entities
{
    public class ColaboradorContaAcessoDado
    {
        public ColaboradorContaAcessoDado()
        {
        }

        public int Id { get; set; }
        public int IdColaboradorContaAcesso { get; set; }
        public int IdTipoContaAcessoCampo { get; set; }
        public string Valor { get; set; }

        public virtual TipoContaAcessoCampo TipoContaAcessoCampo { get; set; }
    }
}