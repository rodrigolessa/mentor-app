using System;

namespace LDTeam.Infrastructure.Ldteam.Entities
{
    public class ColaboradorNotificacao
    {
        public ColaboradorNotificacao()
        {
        }

        public int Id { get; set; }
        public int IdColaborador { get; set; }
        public int IdTipoNotificacao { get; set; }
        public int StatusNotificacao { get; set; }
        public string Valor { get; set; }
        public DateTime DataCadastro { get; set; }
        public DateTime? DataAlteracaoStatus { get; set; }
        public string Argumentos { get; set; }

        public virtual TipoNotificacao TipoNotificacao { get; set; }
    }
}