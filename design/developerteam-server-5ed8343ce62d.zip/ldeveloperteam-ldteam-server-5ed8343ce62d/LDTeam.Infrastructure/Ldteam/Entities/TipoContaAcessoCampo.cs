namespace LDTeam.Infrastructure.Ldteam.Entities
{
    public class TipoContaAcessoCampo
    {
        public TipoContaAcessoCampo()
        {
        }

        public int Id { get; set; }
        public int IdTipoContaAcesso { get; set; }
        public int IdTipoContaAcessoTipoCampo { get; set; }
        public string Nome { get; set; }
        public string Codigo { get; set; }

        public virtual TipoContaAcessoTipoCampo TipoContaAcessoTipoCampo { get; set; }
    }
}