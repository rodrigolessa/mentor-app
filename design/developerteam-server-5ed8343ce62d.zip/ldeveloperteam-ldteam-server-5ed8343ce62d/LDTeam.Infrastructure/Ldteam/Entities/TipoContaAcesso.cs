using System;
using System.Collections.Generic;

namespace LDTeam.Infrastructure.Ldteam.Entities
{
    public class TipoContaAcesso
    {
        public TipoContaAcesso()
        {
        }

        public int Id { get; set; }
        public string Nome { get; set; }
        public string Codigo { get; set; }
        public string LogoUrl { get; set; }
        public bool Ativo { get; set; }
        public DateTime? DataDesativacao { get; set; }

        public virtual List<TipoContaAcessoCampo> Campos { get; set; }
    }
}