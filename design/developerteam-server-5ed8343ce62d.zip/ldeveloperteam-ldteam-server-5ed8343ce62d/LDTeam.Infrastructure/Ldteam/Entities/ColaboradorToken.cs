using System;

namespace LDTeam.Infrastructure.Ldteam.Entities
{
    public class ColaboradorToken
    {
        public ColaboradorToken()
        {
        }

        public int Id { get; set; }
        public int IdColaborador { get; set; }
        public string Token { get; set; }
        public int? Sistema { get; set; }
        public DateTime DataCadastro { get; set; }
        public bool Ativo { get; set; }
        public DateTime? DataDesativacao { get; set; }
    }
}