using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace LDTeam.Infrastructure.Ldteam.Entities
{
    public class PushNotificacao
    {
        public PushNotificacao()
        {
        }

        public int Id { get; set; }
        public string Titulo { get; set; }
        public string Subtitulo { get; set; }
        public string Corpo { get; set; }
        public string ValorDestino { get; set; }
        public string Identificador { get; set; }
        public bool EhTodos { get; set; }
        public bool EhUsuario { get; set; }
        public bool EhDepartamento { get; set; }
        public bool EhRecorrente { get; set; }
        public bool Finalizado { get; set; }
        public int MinutosRecorrente { get; set; }
        public DateTime DataEnvio { get; set; }
    }
}