namespace LDTeam.Infrastructure.Ldteam.Entities
{
    public class TipoContaAcessoTipoCampo
    {
        public TipoContaAcessoTipoCampo()
        {
        }

        public int Id { get; set; }
        public string Codigo { get; set; }
        public string Nome { get; set; }
    }
}