namespace LDTeam.Infrastructure.Ldteam.Entities
{
    public class EmpresaConfiguracao
    {
        public EmpresaConfiguracao()
        {
        }

        public int Id { get; set; }
        public int IdEmpresa { get; set; }
        public bool UsaLoginAD { get; set; }
        public bool UsaLoginEmail { get; set; }
        public string HostAD { get; set; }
        public string DominioAD { get; set; }
        public int? PortaAD { get; set; }
        public string UsuarioAD { get; set; }
        public string SenhaAD { get; set; }
        public string DominioEmail { get; set; }
        public string HostEmail { get; set; }
        public int? PortaEmail { get; set; }
        public bool? UsaSSLEmail { get; set; }
        public string UsuarioEmail { get; set; }
        public string SenhaEmail { get; set; }
    }
}