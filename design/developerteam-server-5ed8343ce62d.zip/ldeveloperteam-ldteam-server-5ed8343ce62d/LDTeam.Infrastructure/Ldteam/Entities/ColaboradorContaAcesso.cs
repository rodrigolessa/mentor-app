using System;
using System.Collections.Generic;

namespace LDTeam.Infrastructure.Ldteam.Entities
{
    public class ColaboradorContaAcesso
    {
        public ColaboradorContaAcesso()
        {
        }

        public int Id { get; set; }
        public int IdColaborador { get; set; }
        public int IdTipoContaAcesso { get; set; }
        public DateTime DataCadastro { get; set; }
        public bool Ativo { get; set; }
        public DateTime? DataDesativacao { get; set; }

        public virtual TipoContaAcesso TipoContaAcesso { get; set; }
        public virtual List<ColaboradorContaAcessoDado> ContasAcessosDados { get; set; }
    }
}