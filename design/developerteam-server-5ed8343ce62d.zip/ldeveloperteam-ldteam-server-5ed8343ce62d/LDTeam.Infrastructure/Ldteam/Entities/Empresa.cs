using System;

namespace LDTeam.Infrastructure.Ldteam.Entities
{
    public class Empresa
    {
        public Empresa()
        {
        }

        public int Id { get; set; }
        public string Codigo { get; set; }
        public string Nome { get; set; }
        public string Cnpj { get; set; }
        public string Telefone { get; set; }
        public string LogoUrl { get; set; }
        public DateTime DataCadastro { get; set; }
        public bool Ativo { get; set; }
        public DateTime? DataDesativacao { get; set; }

        public virtual EmpresaConfiguracao EmpresaConfiguracao { get; set; }
    }
}