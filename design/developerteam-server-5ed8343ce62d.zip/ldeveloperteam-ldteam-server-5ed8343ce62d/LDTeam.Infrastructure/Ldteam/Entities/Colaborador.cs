using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace LDTeam.Infrastructure.Ldteam.Entities
{
    public class Colaborador
    {
        public Colaborador()
        {
        }

        public int Id { get; set; }
        public int IdEmpresa { get; set; }
        public string FotoUrl { get; set; }
        public string Nome { get; set; }
        public DateTime? DataAniversario { get; set; }
        public string Celular { get; set; }
        public string Ramal { get; set; }
        public string Departamento { get; set; }
        public string IdentificadorPonto { get; set; }
        public string Email { get; set; }
        public string Senha { get; set; }
        public string TokenPushNotification { get; set; }
        public bool EhBeta { get; set; }
        public DateTime DataCadastro { get; set; }
        public bool Ativo { get; set; }
        public DateTime? DataDesativacao { get; set; }

        public virtual Empresa Empresa { get; set; }
        public virtual List<ColaboradorContaAcesso> ContasAcessos { get; set; }
        public virtual List<ColaboradorNotificacao> Notificacoes { get; set; }

        [NotMapped]
        public bool FelicitacaoEnviada { get; set; }
    }
}