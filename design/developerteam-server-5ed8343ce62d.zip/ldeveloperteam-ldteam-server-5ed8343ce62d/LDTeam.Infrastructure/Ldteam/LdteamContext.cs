using Microsoft.EntityFrameworkCore;
using LDTeam.Infrastructure.Ldteam.Entities;
using LDTeam.Infrastructure.Ldteam.Maps;

namespace LDTeam.Infrastructure.Ldteam
{
    public class LdteamContext : DbContext
    {
        public DbSet<Colaborador> Colaboradores { get; set; }
        public DbSet<ColaboradorContaAcesso> ColaboradoresContasAcessos { get; set; }
        public DbSet<ColaboradorContaAcessoDado> ColaboradoresContasAcessosDados { get; set; }
        public DbSet<ColaboradorNotificacao> ColaboradoresNotificacoes { get; set; }
        public DbSet<ColaboradorToken> ColaboradoresTokens { get; set; }
        public DbSet<Empresa> Empresas { get; set; }
        public DbSet<EmpresaConfiguracao> EmpresasConfiguracoes { get; set; }
        public DbSet<TipoContaAcesso> TiposContasAcessos { get; set; }
        public DbSet<TipoContaAcessoCampo> TiposContasAcessosCampos { get; set; }
        public DbSet<TipoContaAcessoTipoCampo> TiposContasAcessosTiposCampos { get; set; }
        public DbSet<TipoNotificacao> TiposNotificacoes { get; set; }
        public DbSet<PushNotificacao> PushNotificacoes { get; set; }

        public LdteamContext()
        {
        }

        public LdteamContext(DbContextOptions<LdteamContext> options)
            : base(options)
        {
            // this.ChangeTracker.AutoDetectChangesEnabled = false;
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.ApplyConfiguration(new ColaboradorConfig());
            builder.ApplyConfiguration(new ColaboradorContaAcessoConfig());
            builder.ApplyConfiguration(new ColaboradorContaAcessoDadoConfig());
            builder.ApplyConfiguration(new ColaboradorNotificacaoConfig());
            builder.ApplyConfiguration(new ColaboradorTokenConfig());
            builder.ApplyConfiguration(new EmpresaConfig());
            builder.ApplyConfiguration(new EmpresaConfiguracaoConfig());
            builder.ApplyConfiguration(new TipoContaAcessoCampoConfig());
            builder.ApplyConfiguration(new TipoContaAcessoConfig());
            builder.ApplyConfiguration(new TipoContaAcessoTipoCampoConfig());
            builder.ApplyConfiguration(new TipoNotificacaoConfig());
            builder.ApplyConfiguration(new PushNotificacaoConfig());
        }
    }
}