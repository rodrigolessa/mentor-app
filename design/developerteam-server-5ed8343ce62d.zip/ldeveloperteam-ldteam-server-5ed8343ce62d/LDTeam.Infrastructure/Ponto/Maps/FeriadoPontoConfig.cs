using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using LDTeam.Infrastructure.Ponto.Entities;

namespace LDTeam.Infrastructure.Ponto.Maps
{
    public class FeriadoPontoConfig : IEntityTypeConfiguration<FeriadoPonto>
    {
        public void Configure(EntityTypeBuilder<FeriadoPonto> builder)
        {
            builder.ToTable("feriados");
            builder.HasKey(u => u.Id);

            builder.Property(u => u.Id).HasColumnName("id");
            builder.Property(u => u.Data).HasColumnName("data");
            builder.Property(u => u.Descricao).HasColumnName("descricao");
        }
    }
}