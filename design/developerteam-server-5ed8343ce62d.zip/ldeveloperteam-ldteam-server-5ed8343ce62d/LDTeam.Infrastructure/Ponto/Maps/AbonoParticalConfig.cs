using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using LDTeam.Infrastructure.Ponto.Entities;

namespace LDTeam.Infrastructure.Ponto.Maps
{
    public class AbonoParcialConfig : IEntityTypeConfiguration<AbonoParcial>
    {
        public void Configure(EntityTypeBuilder<AbonoParcial> builder)
        {
            builder.ToTable("abonos_parciais");
            builder.HasKey(u => u.Id);

            builder.Property(u => u.Id).HasColumnName("id");
            builder.Property(u => u.Data).HasColumnName("data");
            builder.Property(u => u.HoraInicio).HasColumnName("hora_inicio");
            builder.Property(u => u.HoraFim).HasColumnName("hora_fim");
            builder.Property(u => u.Tipo).HasColumnName("tipo");
            builder.Property(u => u.FuncionarioId).HasColumnName("funcionario_id");
            builder.Property(u => u.JustificativaId).HasColumnName("justificativa_id");
        }
    }
}