using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using LDTeam.Infrastructure.Ponto.Entities;

namespace LDTeam.Infrastructure.Ponto.Maps
{
    public class CalculoPontoConfig : IEntityTypeConfiguration<CalculoPonto>
    {
        public void Configure(EntityTypeBuilder<CalculoPonto> builder)
        {
            builder.ToTable("calculos");

            builder.Property(u => u.Id).HasColumnName("id");
            builder.Property(u => u.FuncionarioId).HasColumnName("funcionario_id");
            builder.Property(u => u.Data).HasColumnName("data");
            builder.Property(u => u.SaldoMinutos).HasColumnName("btotal");
            builder.Property(u => u.SaldoMinutosAjuste).HasColumnName("bajuste");
            builder.Property(u => u.Observacao).HasColumnName("bajuste_obs").HasMaxLength(255);
        }
    }
}