using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using LDTeam.Infrastructure.Ponto.Entities;

namespace LDTeam.Infrastructure.Ponto.Maps
{
    public class JustificativaConfig : IEntityTypeConfiguration<Justificativa>
    {
        public void Configure(EntityTypeBuilder<Justificativa> builder)
        {
            builder.ToTable("justificativas");
            builder.HasKey(u => u.Id);

            builder.Property(u => u.Id).HasColumnName("id");
            builder.Property(u => u.Descricao).HasColumnName("descricao");
            builder.Property(u => u.Nome).HasColumnName("nome");
            builder.Property(u => u.DescontarBancoHoras).HasColumnName("descontar_banco_horas");
            builder.Property(u => u.ValorDia).HasColumnName("valor_dia");
        }
    }
}