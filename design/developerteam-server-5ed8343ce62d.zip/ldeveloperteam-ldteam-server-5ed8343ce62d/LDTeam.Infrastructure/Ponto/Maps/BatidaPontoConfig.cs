using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using LDTeam.Infrastructure.Ponto.Entities;

namespace LDTeam.Infrastructure.Ponto.Maps
{
    public class BatidaPontoConfig : IEntityTypeConfiguration<BatidaPonto>
    {
        public void Configure(EntityTypeBuilder<BatidaPonto> builder)
        {
            builder.ToTable("batidas");

            builder.Property(u => u.Id).HasColumnName("id");

            builder.Property(u => u.Entrada1).HasColumnName("entrada1").HasMaxLength(10);
            builder.Property(u => u.Entrada2).HasColumnName("entrada2").HasMaxLength(10);
            builder.Property(u => u.Entrada3).HasColumnName("entrada3").HasMaxLength(10);
            builder.Property(u => u.Entrada4).HasColumnName("entrada4").HasMaxLength(10);
            builder.Property(u => u.Entrada5).HasColumnName("entrada5").HasMaxLength(10);

            builder.Property(u => u.Saida1).HasColumnName("saida1").HasMaxLength(10);
            builder.Property(u => u.Saida2).HasColumnName("saida2").HasMaxLength(10);
            builder.Property(u => u.Saida3).HasColumnName("saida3").HasMaxLength(10);
            builder.Property(u => u.Saida4).HasColumnName("saida4").HasMaxLength(10);
            builder.Property(u => u.Saida5).HasColumnName("saida5").HasMaxLength(10);

            builder.Property(u => u.FuncionarioId).HasColumnName("funcionario_id").HasMaxLength(10);
            builder.Property(u => u.Data).HasColumnName("data").HasMaxLength(10);

            builder.Property(u => u.Ajuste).HasColumnName("ajuste").HasMaxLength(6);
        }
    }
}