using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using LDTeam.Infrastructure.Ponto.Entities;

namespace LDTeam.Infrastructure.Ponto.Maps
{
    public class DepartamentoPontoConfig : IEntityTypeConfiguration<DepartamentoPonto>
    {
        public void Configure(EntityTypeBuilder<DepartamentoPonto> builder)
        {
            builder.ToTable("departamentos");
            builder.HasKey(u => u.Id);

            builder.Property(u => u.Id).HasColumnName("id");
            builder.Property(u => u.NumeroFolha).HasColumnName("dep_n_folha");
            builder.Property(u => u.Descricao).HasColumnName("descricao");
        }
    }
}