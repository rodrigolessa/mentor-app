using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using LDTeam.Infrastructure.Ponto.Entities;

namespace LDTeam.Infrastructure.Ponto.Maps
{
    public class FuncionarioPontoConfig : IEntityTypeConfiguration<FuncionarioPonto>
    {
        public void Configure(EntityTypeBuilder<FuncionarioPonto> builder)
        {
            builder.ToTable("funcionarios");
            builder.HasKey(u => u.Id);

            builder.Property(u => u.Id).HasColumnName("id");
            builder.Property(u => u.IdDepartamento).HasColumnName("departamento_id");
            builder.Property(u => u.DataAdmissao).HasColumnName("admissao");
            builder.Property(u => u.Nome).HasColumnName("nome").HasMaxLength(100);
            builder.Property(u => u.NumeroFolha).HasColumnName("n_folha").HasMaxLength(22);
        }
    }
}