using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using LDTeam.Infrastructure.Ponto.Entities;

namespace LDTeam.Infrastructure.Ponto.Maps
{
    public class FonteDadoConfig : IEntityTypeConfiguration<FonteDadoPonto>
    {
        public void Configure(EntityTypeBuilder<FonteDadoPonto> builder)
        {
            builder.ToTable("fonte_dados");

            builder.HasKey(u => u.Id);
            builder.Property(u => u.Id).HasColumnName("id");
            builder.Property(u => u.Data).HasColumnName("data");
            builder.Property(u => u.DataInclusao).HasColumnName("data_inclusao");
            builder.Property(u => u.Hora).HasColumnName("hora");
            builder.Property(u => u.EquipamentoId).HasColumnName("equipamento_id");
            builder.Property(u => u.FuncionarioId).HasColumnName("funcionario_id");
            builder.Property(u => u.FuncionarioPis).HasColumnName("funcionario_pis");
            builder.Property(u => u.TipoRegistro).HasColumnName("tipo_registro");
            builder.Property(u => u.Motivo).HasColumnName("motivo");
            builder.Property(u => u.DataInclusao).HasColumnName("data_inclusao");
        }
    }
}