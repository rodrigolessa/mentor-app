using Microsoft.EntityFrameworkCore;
using LDTeam.Infrastructure.Ponto.Entities;
using LDTeam.Infrastructure.Ponto.Maps;

namespace LDTeam.Infrastructure.Ponto
{
    public class PontoContext : DbContext
    {
        public DbSet<BatidaPonto> Batidas { get; set; }
        public DbSet<FonteDadoPonto> FontesDados { get; set; }
        public DbSet<FuncionarioPonto> Funcionarios { get; set; }
        public DbSet<CalculoPonto> Calculos { get; set; }
        public DbSet<FeriadoPonto> Feriados { get; set; }
        public DbSet<DepartamentoPonto> Departamentos { get; set; }
        public DbSet<AbonoParcial> AbonosParciais { get; set; }
        public DbSet<JustificativaLancada> JustificativasLancadas { get; set; }
        public DbSet<Justificativa> Justificativas { get; set; }

        public PontoContext()
        {
        }

        public PontoContext(DbContextOptions<PontoContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.ApplyConfiguration(new BatidaPontoConfig());
            builder.ApplyConfiguration(new FuncionarioPontoConfig());
            builder.ApplyConfiguration(new FonteDadoConfig());
            builder.ApplyConfiguration(new CalculoPontoConfig());
            builder.ApplyConfiguration(new FeriadoPontoConfig());
            builder.ApplyConfiguration(new DepartamentoPontoConfig());
            builder.ApplyConfiguration(new AbonoParcialConfig());
            builder.ApplyConfiguration(new JustificativaLancadaConfig());
            builder.ApplyConfiguration(new JustificativaConfig());
        }
    }
}