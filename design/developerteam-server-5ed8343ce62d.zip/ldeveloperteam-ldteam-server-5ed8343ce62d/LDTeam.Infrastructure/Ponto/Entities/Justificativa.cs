using System;

namespace LDTeam.Infrastructure.Ponto.Entities
{
    public class Justificativa
    {
        public Justificativa()
        {
        }

        public int Id { get; set; }
        public string Descricao { get; set; }
        public string Nome { get; set; }
        public string ValorDia { get; set; }
        public bool DescontarBancoHoras { get; set; }
    }
}