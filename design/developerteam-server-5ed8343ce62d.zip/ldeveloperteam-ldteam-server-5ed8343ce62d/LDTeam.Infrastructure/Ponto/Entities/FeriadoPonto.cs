using System;

namespace LDTeam.Infrastructure.Ponto.Entities
{
    public class FeriadoPonto
    {
        public FeriadoPonto()
        {
        }

        public int Id { get; set; }
        public DateTime Data { get; set; }
        public string Descricao { get; set; }

    }
}