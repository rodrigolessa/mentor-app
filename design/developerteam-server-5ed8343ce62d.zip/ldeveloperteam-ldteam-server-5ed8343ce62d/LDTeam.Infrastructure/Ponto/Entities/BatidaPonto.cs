using System;

namespace LDTeam.Infrastructure.Ponto.Entities
{
    public class BatidaPonto
    {
        public BatidaPonto()
        {
        }

        public int Id { get; set; }
        public int FuncionarioId { get; set; }
        public DateTime Data { get; set; }
        public string Entrada1 { get; set; }
        public string Saida1 { get; set; }
        public string Entrada2 { get; set; }
        public string Saida2 { get; set; }
        public string Entrada3 { get; set; }
        public string Saida3 { get; set; }
        public string Entrada4 { get; set; }
        public string Saida4 { get; set; }
        public string Entrada5 { get; set; }
        public string Saida5 { get; set; }
        public string Ajuste { get; set; }

    }
}