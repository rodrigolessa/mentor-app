using System;

namespace LDTeam.Infrastructure.Ponto.Entities
{
    public class CalculoPonto
    {
        public CalculoPonto()
        {
        }

        public int Id { get; set; }
        public int SaldoMinutos { get; set; }
        public int? SaldoMinutosAjuste { get; set; }
        public int FuncionarioId { get; set; }
        public DateTime Data { get; set; }
        public string Observacao { get; set; }
    }
}