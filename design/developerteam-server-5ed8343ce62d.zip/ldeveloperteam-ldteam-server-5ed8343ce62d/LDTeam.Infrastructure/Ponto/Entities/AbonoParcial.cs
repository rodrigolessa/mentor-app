using System;

namespace LDTeam.Infrastructure.Ponto.Entities
{
    public class AbonoParcial
    {
        public AbonoParcial()
        {
        }

        public int Id { get; set; }
        public int FuncionarioId { get; set; }
        public DateTime Data { get; set; }
        public string HoraInicio { get; set; }
        public string HoraFim { get; set; }
        public int JustificativaId { get; set; }
        public bool Tipo { get; set; }
    }
}