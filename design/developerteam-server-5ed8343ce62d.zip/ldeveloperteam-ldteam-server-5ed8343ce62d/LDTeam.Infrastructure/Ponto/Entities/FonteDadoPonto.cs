using System;

namespace LDTeam.Infrastructure.Ponto.Entities
{
    public class FonteDadoPonto
    {
        public FonteDadoPonto()
        {
        }

        public int Id { get; set; }
        public int EquipamentoId { get; set; }
        public int FuncionarioId { get; set; }
        public int TipoRegistro { get; set; }
        public DateTime Data { get; set; }
        public DateTime DataInclusao { get; set; }
        public string FuncionarioPis { get; set; }
        public string Hora { get; set; }
        public string Motivo { get; set; }

    }
}