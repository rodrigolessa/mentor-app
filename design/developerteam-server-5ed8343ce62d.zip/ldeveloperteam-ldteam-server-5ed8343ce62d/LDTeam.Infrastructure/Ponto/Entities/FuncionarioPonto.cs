using System;

namespace LDTeam.Infrastructure.Ponto.Entities
{
    public class FuncionarioPonto
    {
        public FuncionarioPonto()
        {
        }

        public int Id { get; set; }
        public int? IdDepartamento { get; set; }
        public string NumeroFolha { get; set; }
        public string Nome { get; set; }
        public DateTime DataAdmissao { get; set; }
    }
}