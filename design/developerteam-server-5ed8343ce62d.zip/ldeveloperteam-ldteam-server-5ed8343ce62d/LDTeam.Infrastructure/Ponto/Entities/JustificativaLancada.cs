using System;

namespace LDTeam.Infrastructure.Ponto.Entities
{
    public class JustificativaLancada
    {
        public JustificativaLancada()
        {
        }

        public int Id { get; set; }
        public int FuncionarioId { get; set; }
        public DateTime DataInicio { get; set; }
        public DateTime DataFim { get; set; }
        public DateTime DataAlteracao { get; set; }
        public string Observacao { get; set; }
        public int JustificativaId { get; set; }
    }
}