namespace LDTeam.Infrastructure.Ponto.Entities
{
    public class DepartamentoPonto
    {
        public DepartamentoPonto()
        {
        }

        public int Id { get; set; }
        public string NumeroFolha { get; set; }
        public string Descricao { get; set; }
    }
}