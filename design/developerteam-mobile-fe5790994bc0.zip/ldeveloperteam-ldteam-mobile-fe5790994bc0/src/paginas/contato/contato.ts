import { Component } from "@angular/core";
import {
  NavController,
  NavParams,
  AlertController,
  LoadingController,
  Keyboard
} from "ionic-angular";
import { Usuario } from "../../provedores/provedores";
declare var Appsee: any;

@Component({
  selector: "page-contato",
  templateUrl: "contato.html"
})
export class ContatoPage {
  loading = this.loadingCtrl.create({
    content: "Aguarde...",
    dismissOnPageChange: true
  });

  textoBusca: any = "";
  erroObter: boolean = false;
  colaboradores: any[] = [];
  colaboradoresAgrupados: any[] = [];
  colaboradoresOriginal: any[] = [];
  items: any = [];
  itemExpandHeight: number = 100;
  itemExpand = true;

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public alertCtrl: AlertController,
    private usuarioSerice: Usuario,
    public loadingCtrl: LoadingController,
    private keyboard: Keyboard
  ) {
    if (typeof Appsee !== "undefined") {
      Appsee.startScreen("Tela Contato");
    }
  }

  ionViewWillEnter() {}

  ionViewDidLoad() {
    this.obterColaboradores();
  }

  doRefresh(refresher) {
    refresher.complete();
    this.obterColaboradores();
  }

  obterColaboradores() {
    this.loading = this.loadingCtrl.create({
      content: "Aguarde...",
      dismissOnPageChange: false
    });
    this.loading.present();
    this.erroObter = false;

    this.usuarioSerice.obterColaboradores().then(
      (colaboradores: any) => {
        if (colaboradores != null) {
          colaboradores.objeto.forEach(element => {
            if (element.fotoUrl == null || element.fotoUrl === "") {
              element.fotoUrl = "assets/img/LD-PRETO-240X240.png";
            } else {
              if (element.fotoUrl.indexOf("http") === -1) {
                element.fotoUrl = "assets/img/colaborador/" + element.fotoUrl;
              }
            }

            let auxDataNiver = [];
            let auxDataHoje = [];
            auxDataHoje = new Date()
              .toISOString()
              .split("T")[0]
              .split("-");
            auxDataNiver = element.dataAniversario.split("T")[0].split("-");
            auxDataNiver[0] = auxDataHoje[0];

            if (
              new Date(auxDataNiver.join("-")) >=
              new Date(auxDataHoje.join("-"))
            ) {
              element.dataAniversario = auxDataNiver.reverse().join("/");
            } else {
              auxDataNiver[0] = (parseInt(auxDataNiver[0]) + 1).toString();
              element.dataAniversario = auxDataNiver.reverse().join("/");
            }

            element.celular = this.maskTelString(element.celular);
          });

          this.colaboradoresOriginal = colaboradores.objeto;
          this.colaboradoresAgrupados = [];
          this.gerarListaAgrupada(this.colaboradoresOriginal);

          if (this.textoBusca != null && this.textoBusca != "") {
            this.getItems();
          }

          this.loading.dismiss();
        }
      },
      err => {
        this.erroObter = true;
        this.loading.dismiss();
      }
    );
  }

  closeKeyboard(ev: any) {
    this.getItems(ev);
    this.keyboard.close();
  }

  gerarListaAgrupada(itens) {
    itens.forEach(element => {
      let colaboradorAgrupado = {
        Grupo: "",
        Itens: []
      };

      if (
        this.colaboradoresAgrupados.filter(a => a.Grupo == element.departamento)
          .length === 0
      ) {
        if (element.departamento == null || element.departamento == "") {
          element.departamento = "Não definido";
        }

        colaboradorAgrupado.Grupo = element.departamento;
        this.colaboradoresAgrupados.push(colaboradorAgrupado);
      }

      colaboradorAgrupado = this.colaboradoresAgrupados.filter(
        a => a.Grupo == element.departamento
      )[0];

      colaboradorAgrupado.Itens.push(element);

      this.colaboradoresAgrupados[
        this.colaboradoresAgrupados.findIndex(
          a => a.Grupo == colaboradorAgrupado.Grupo
        )
      ] = colaboradorAgrupado;
    });

    this.colaboradoresAgrupados.forEach(element => {
      element.Itens = element.Itens.sort(function(a, b) {
        if (a.nome < b.nome) return -1;
        if (a.nome > b.nome) return 1;
        return 0;
      });
    });

    this.colaboradoresAgrupados = this.colaboradoresAgrupados.sort(function(
      a,
      b
    ) {
      if (a.Grupo < b.Grupo) return -1;
      if (a.Grupo > b.Grupo) return 1;
      return 0;
    });
  }

  getItems(ev?: any) {
    this.colaboradoresAgrupados = [];
    let colaboradores = this.colaboradoresOriginal;
    let val = ev != null ? ev.target.value : this.textoBusca;

    if (val && val.trim() != "") {
      colaboradores = this.colaboradoresOriginal.filter(
        item =>
          item.nome.toLowerCase().indexOf(val.toLowerCase()) > -1 ||
          item.email.toLowerCase().indexOf(val.toLowerCase()) > -1 ||
          (item.departamento != null &&
            item.departamento.toLowerCase().indexOf(val.toLowerCase()) > -1)
      );
    }

    this.gerarListaAgrupada(colaboradores);
  }

  maskTelString(inputTxt) {
    let length = inputTxt.length;

    inputTxt = inputTxt.replace(/\D/g, "");
    inputTxt = inputTxt.replace(/(\d{2})(\d)/, "$1 $2");
    if (length == 11) {
      inputTxt = inputTxt.replace(/(\d{5})(\d)/, "$1-$2");
    } else {
      inputTxt = inputTxt.replace(/(\d{4})(\d)/, "$1-$2");
    }

    return inputTxt;
  }

  expandItem(item) {
    this.colaboradoresAgrupados.forEach(listGrupo => {
      listGrupo.Itens.forEach(listItem => {
        if (listItem.id == item.id) {
          listItem.expanded = !listItem.expanded;
        } else {
          listItem.expanded = false;
          // setTimeout(() => {
          //   listItem.expanded = false;
          // }, 500);
        }
      });
    });
  }
}
