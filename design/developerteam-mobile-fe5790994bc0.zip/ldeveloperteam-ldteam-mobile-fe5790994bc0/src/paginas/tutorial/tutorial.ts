import { Component } from "@angular/core";
import {
  MenuController,
  NavController,
  Platform,
  ViewController
} from "ionic-angular";
import { BemVindoPage } from "../bem-vindo/bem-vindo";
declare var Appsee: any;

export interface Slide {
  title: string;
  description: string;
  image: string;
}

@Component({
  selector: "page-tutorial",
  templateUrl: "tutorial.html"
})
export class TutorialPage {
  slides: Slide[];
  showSkip = true;
  dir: string = "ltr";

  constructor(
    public menu: MenuController,
    public platform: Platform,
    private viewCtrl: ViewController,
    private navCtrl: NavController
  ) {
    if (typeof Appsee !== "undefined") Appsee.startScreen("Tela Tutorial");
    this.dir = platform.dir();
    this.slides = [
      {
        title: "Bem-vindo ao LDTeam",
        description:
          "O <b>LDTeam</b> é um aplicativo corporativo, que tem como objetivo facilitar/ajudar todos os colaboradores da empresa <b>LDSoft</b>.",
        image: "assets/img/LOGO-PRETO.png"
      },
      {
        title: "O que vou encontrar?",
        description:
          "No aplicativo você vai ser capaz de realizar algumas tarefas do seu dia-a-dia, tais como:<br />" +
          "<b>Consultar seu saldo do ponto;</b><br />" +
          "<b>Consultar a listagem dos colaboradores;</b><br />" +
          "<b>Consultar a listagem dos próximos aniversáriantes;</b><br />" +
          "<b>Consultar o saldo dos Tickets Restaurante e Alimentação;</b><br />" +
          "<b>Consultar as atividades agendadas no calendário;</b><br />" +
          "<b>E muito mais...</b>",
        image: "assets/img/LOGO-PRETO.png"
      },
      {
        title: "O que vem por ai?",
        description:
          "Além do que já está disponível atualmente no aplicativo, a gente não vai parar por ai. Vamos continuar buscando facilidades/agilidade nas tarefas comuns do seu dia-a-dia. <p>Tem alguma sugestão? Envie um email para <a href='mailto:pastaazul@ldsoft.com.br'>pastaazul@ldsoft.com.br</a> e ajude a melhorar o nosso ambiente corporativo.</p>",
        image: "assets/img/LOGO-PRETO.png"
      }
    ];
  }

  startApp() {
    this.navCtrl.setRoot(BemVindoPage);
  }

  onSlideChangeStart(slider) {
    this.showSkip = !slider.isEnd();
  }

  ionViewWillEnter() {
    this.viewCtrl.showBackButton(false);
  }

  ionViewDidEnter() {
    this.menu.enable(false);
  }
}
