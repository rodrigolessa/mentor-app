import { Component } from "@angular/core";
import {
  NavController,
  NavParams,
  AlertController,
  LoadingController,
  ModalController
} from "ionic-angular";
import { CalendarioAdicionarModal } from "../modais/calendarioAdicionar/calendarioAdicionar";
import { Calendar } from "@ionic-native/calendar";
import { CalendarioService, Usuario } from "../../provedores/provedores";
import { AtividadeDetalheModal } from "../modais/atividadeDetalhe/atividadeDetalhe";

@Component({
  selector: "page-calendario",
  templateUrl: "calendario.html"
})
export class CalendarioPage {
  loading = this.loadingCtrl.create({
    content: "Aguarde...",
    dismissOnPageChange: true
  });

  date: any;
  dateInitial: Date;
  dateStop: Date;
  daysInThisMonth: any;
  daysInLastMonth: any;
  daysInNextMonth: any;
  monthNames: string[];
  currentMonth: any;
  currentYear: any;
  currentDate: any;
  selectedEvent: any;
  selectedDay: any;
  calendario: any[] = [];
  jornada: any[] = [];
  errosPonto: any[] = [];

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public alertCtrl: AlertController,
    public loadingCtrl: LoadingController,
    private calendar: Calendar,
    private calendarioService: CalendarioService,
    private usuarioService: Usuario,
    private modalCtrl: ModalController
  ) {}

  ionViewWillEnter() {}

  ionViewDidLoad() {
    this.date = new Date();
    this.dateInitial = new Date();
    this.dateStop = new Date();
    this.dateInitial = new Date(
      this.dateInitial.setMonth(this.dateInitial.getMonth() - 6)
    );
    this.dateStop = new Date(
      this.dateStop.setMonth(this.dateStop.getMonth() + 6)
    );
    this.dateInitial = new Date(
      this.dateInitial.getFullYear(),
      this.dateInitial.getMonth(),
      1
    );
    this.dateStop = new Date(
      this.dateStop.getFullYear(),
      this.dateStop.getMonth() + 1,
      0
    );

    console.log(this.dateInitial);
    console.log(this.dateStop);

    this.monthNames = [
      "Janeiro",
      "Fevereiro",
      "Março",
      "Abril",
      "Maio",
      "Junho",
      "Julho",
      "Agosto",
      "Setembro",
      "Outubro",
      "Novembro",
      "Dezembro"
    ];
    this.getDaysOfMonth();
    this.loadEventThisMonth(true);
  }

  getDaysOfMonth() {
    this.daysInThisMonth = new Array();
    this.daysInLastMonth = new Array();
    this.daysInNextMonth = new Array();
    this.currentMonth = this.monthNames[this.date.getMonth()];
    this.currentYear = this.date.getFullYear();
    if (this.date.getMonth() === new Date().getMonth()) {
      this.currentDate = new Date().getDate();
      this.selectedDay = this.currentDate;
    } else {
      this.currentDate = 999;
      this.selectedDay = 1;
    }

    var firstDayThisMonth = new Date(
      this.date.getFullYear(),
      this.date.getMonth(),
      1
    ).getDay();
    var prevNumOfDays = new Date(
      this.date.getFullYear(),
      this.date.getMonth(),
      0
    ).getDate();
    for (
      var i = prevNumOfDays - (firstDayThisMonth - 1);
      i <= prevNumOfDays;
      i++
    ) {
      this.daysInLastMonth.push(i);
    }

    var thisNumOfDays = new Date(
      this.date.getFullYear(),
      this.date.getMonth() + 1,
      0
    ).getDate();
    for (var j = 0; j < thisNumOfDays; j++) {
      this.daysInThisMonth.push(j + 1);
    }

    var lastDayThisMonth = new Date(
      this.date.getFullYear(),
      this.date.getMonth() + 1,
      0
    ).getDay();
    // var nextNumOfDays = new Date(this.date.getFullYear(), this.date.getMonth()+2, 0).getDate();
    for (var k = 0; k < 6 - lastDayThisMonth; k++) {
      this.daysInNextMonth.push(k + 1);
    }
    var totalDays =
      this.daysInLastMonth.length +
      this.daysInThisMonth.length +
      this.daysInNextMonth.length;
    if (totalDays < 36) {
      for (var l = 7 - lastDayThisMonth; l < 7 - lastDayThisMonth + 7; l++) {
        this.daysInNextMonth.push(l);
      }
    }

    if (this.daysInLastMonth.length === 7) {
      this.daysInLastMonth = [];
    }
    if (this.daysInNextMonth.length === 7) {
      this.daysInNextMonth = [];
    }
  }

  goToLastMonth() {
    this.date = new Date(this.date.getFullYear(), this.date.getMonth(), 0);
    this.getDaysOfMonth();
    this.loadEventThisMonth();
  }

  goToNextMonth() {
    this.date = new Date(this.date.getFullYear(), this.date.getMonth() + 2, 0);
    this.getDaysOfMonth();
    this.loadEventThisMonth();
  }

  addEvent() {
    this.navCtrl.push(CalendarioAdicionarModal);
  }

  loadEventThisMonth(force?: boolean) {
    this.loading = this.loadingCtrl.create({
      content: "Aguarde...",
      dismissOnPageChange: false
    });

    var startDate = new Date(this.date.getFullYear(), this.date.getMonth(), 1);
    var endDate = new Date(
      this.date.getFullYear(),
      this.date.getMonth() + 1,
      0
    );

    if (startDate < this.dateInitial || endDate > this.dateStop || force) {
      this.loading.present();

      if (!force) {
        this.dateInitial = new Date(
          startDate.setMonth(startDate.getMonth() - 6)
        );
        this.dateStop = new Date(endDate.setMonth(endDate.getMonth() + 6));
        this.dateInitial = new Date(
          this.dateInitial.getFullYear(),
          this.dateInitial.getMonth(),
          1
        );
        this.dateStop = new Date(
          this.dateStop.getFullYear(),
          this.dateStop.getMonth() + 1,
          0
        );
      }

      this.usuarioService
        .obterConsumoPonto(this.dateInitial, this.dateStop)
        .then(
          (consumo: any) => {
            if (consumo != null && consumo.objeto) {
              this.jornada = consumo.objeto;
              this.errosPonto = [];
              this.jornada.forEach(item => {
                let h = Math.floor(item.saldoMinutos / 60);
                let m = item.saldoMinutos % 60;
                let sH = h < 10 ? "0" + h : h;
                let sM = m < 10 ? "0" + m : m;
                item.jornadaHora = sH + ":" + sM;

                if (item.erroPonto) {
                  item.jornada = false;
                  this.errosPonto.push({
                    jornadaHora: item.jornadaHora,
                    saldoMinutos: item.saldoMinutos,
                    obs: item.obs,
                    data: item.data,
                    justificativa: item.justificativa,
                    erroPonto: item.erroPonto,
                    marcacoes: item.marcacoes,
                    mensagemErroPonto: item.mensagemErroPonto,
                    nome: item.mensagemErroPonto
                  });
                } else {
                  item.mensagemErroPonto = "";
                }

                item.erroPonto = false;
              });
            }

            this.calendarioService
              .obterCalendario(this.dateInitial, this.dateStop)
              .subscribe((calendario: any) => {
                if (calendario != null) {
                  this.calendario = calendario.itens;
                  this.selectDate(this.selectedDay);
                }

                this.loading.dismiss();
              });
          },
          err => {
            this.loading.dismiss();
          }
        );
    } else {
      this.selectDate(this.selectedDay);
    }
  }

  checkEvent(day) {
    let bullets = [];
    var hasEvent = false;
    var hasEventJornada = false;
    var hasEventJornadaPonto = false;

    let dataFormatada =
      this.date.getFullYear() +
      "-" +
      (this.date.getMonth() + 1 < 10
        ? "0" + (this.date.getMonth() + 1)
        : this.date.getMonth() + 1) +
      "-" +
      (day < 10 ? "0" + day : day);

    this.calendario.forEach(event => {
      let dataFormatadaItem = event.data
        .split("/")
        .reverse()
        .join("-");

      if (dataFormatada == dataFormatadaItem) {
        hasEvent = true;
      }
    });

    this.jornada.forEach(event => {
      let dataFormatadaItem = event.data
        .split("/")
        .reverse()
        .join("-");

      if (dataFormatada == dataFormatadaItem) {
        hasEventJornada = true;

        if (event.erroPonto) {
          hasEventJornadaPonto = true;
        }
      }
    });

    this.errosPonto.forEach(event => {
      let dataFormatadaItem = event.data
        .split("/")
        .reverse()
        .join("-");
      event.terminarHoje = false;
      event.jornada = true;
      event.dataInicio = dataFormatadaItem + "T23:59:59";
      event.dataFim = dataFormatadaItem + "T23:59:59";

      if (dataFormatada == dataFormatadaItem) {
        hasEventJornadaPonto = true;
      }
    });

    if (hasEvent) {
      bullets.push("cinza");
    }
    if (hasEventJornadaPonto) {
      bullets.push("vermelho");
    }
    if (hasEventJornada) {
      bullets.push("azul");
    }

    return bullets;
  }

  selectDate(day) {
    this.selectedEvent = new Array();
    this.selectedDay = day;

    let dataFormatada =
      this.date.getFullYear() +
      "-" +
      (this.date.getMonth() + 1 < 10
        ? "0" + (this.date.getMonth() + 1)
        : this.date.getMonth() + 1) +
      "-" +
      (day < 10 ? "0" + day : day);

    this.calendario.forEach(event => {
      let dataFormatadaItem = event.data
        .split("/")
        .reverse()
        .join("-");
      event.terminarHoje = false;

      if (dataFormatada == dataFormatadaItem) {
        let dataFimFormatadaItem = event.dataFim
          .split("T")[0]
          .split("-")
          .join("-");

        event.terminarHoje = dataFormatada == dataFimFormatadaItem;
        event.horaFim =
          event.dataFim.split("T")[1].split(":")[0] +
          ":" +
          event.dataFim.split("T")[1].split(":")[1];

        this.selectedEvent.push(event);
      }
    });

    this.jornada.forEach(event => {
      let dataFormatadaItem = event.data
        .split("/")
        .reverse()
        .join("-");
      event.terminarHoje = false;
      event.jornada = true;
      event.nome = "Jornada diária";
      event.dataInicio = dataFormatadaItem + "T23:59:59";
      event.dataFim = dataFormatadaItem + "T23:59:59";

      if (dataFormatada == dataFormatadaItem) {
        event.terminarHoje = true;
        console.log("jornada", event);
        this.selectedEvent.push(event);
      }
    });

    this.errosPonto.forEach(event => {
      let dataFormatadaItem = event.data
        .split("/")
        .reverse()
        .join("-");
      event.terminarHoje = false;
      event.jornada = false;
      event.erroPonto = true;
      event.dataInicio = dataFormatadaItem + "T23:59:59";
      event.dataFim = dataFormatadaItem + "T23:59:59";

      if (dataFormatada == dataFormatadaItem) {
        event.terminarHoje = true;
        console.log("erro ponto", event);
        this.selectedEvent.push(event);
      }
    });

    console.log("jornada", this.jornada);

    this.selectedEvent = this.selectedEvent.sort((a, b) => {
      return b.diaTodo ||
        new Date(a.dataInicio).getTime() - new Date(b.dataInicio).getTime() <= 0
        ? -1
        : new Date(a.dataInicio).getTime() -
            new Date(b.dataInicio).getTime() ===
          0
          ? 0
          : 1;
    });

    console.log(this.selectedEvent);
  }

  deleteEvent(evt) {
    let alert = this.alertCtrl.create({
      title: "Confirm Delete",
      message: "Are you sure want to delete this event?",
      buttons: [
        {
          text: "Cancel",
          role: "cancel",
          handler: () => {
            console.log("Cancel clicked");
          }
        },
        {
          text: "Ok",
          handler: () => {
            this.calendar
              .deleteEvent(
                evt.title,
                evt.location,
                evt.notes,
                new Date(evt.startDate.replace(/\s/, "T")),
                new Date(evt.endDate.replace(/\s/, "T"))
              )
              .then(
                msg => {
                  console.log(msg);
                  this.loadEventThisMonth();
                  this.selectDate(
                    new Date(evt.startDate.replace(/\s/, "T")).getDate()
                  );
                },
                err => {
                  console.log(err);
                }
              );
          }
        }
      ]
    });
    alert.present();
  }

  doRefresh(refresher) {
    this.loadEventThisMonth(true);
    refresher.complete();
  }

  visualizarDetalheEvento(evento) {
    let modal = this.modalCtrl.create(AtividadeDetalheModal, {
      evento: evento
    });
    modal.present();
  }
}
