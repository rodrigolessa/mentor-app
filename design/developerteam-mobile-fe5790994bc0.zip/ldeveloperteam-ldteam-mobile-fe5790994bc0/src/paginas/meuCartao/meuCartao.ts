import { Component, ViewChild } from "@angular/core";
import {
  NavController,
  NavParams,
  AlertController,
  LoadingController,
  ModalController,
  Navbar
} from "ionic-angular";
import { Util } from "../../shared/util";
import { Usuario } from "../../provedores/provedores";
import { MeuCartaoAdicionarPage } from "../meuCartaoAdicionar/meuCartaoAdicionar";
declare var Appsee: any;

@Component({
  selector: "page-meuCartao",
  templateUrl: "meuCartao.html"
})
export class MeuCartaoPage {
  @ViewChild(Navbar) navBar: Navbar;
  loading = this.loadingCtrl.create({
    content: "Aguarde...",
    dismissOnPageChange: true
  });

  contasAcessos: any[] = [];
  cartoesTicket: any[] = [];
  refresh: any;
  erroObter: boolean = false;

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public alertCtrl: AlertController,
    public loadingCtrl: LoadingController,
    private usuarioSerice: Usuario,
    public util: Util,
    private modalCtrl: ModalController
  ) {
    if (typeof Appsee !== "undefined") Appsee.startScreen("Tela Meu Cartao");
  }

  ionViewDidEnter() {}

  ionViewDidLoad() {
    this.iniciar();
  }

  doRefresh(refresher) {
    refresher.complete();
    this.obterCartoesTicket(true);
  }

  iniciar() {
    this.obterCartoesTicket();
  }

  obterCartoesTicket(reload?: boolean) {
    this.loading = this.loadingCtrl.create({
      content: "Aguarde...",
      dismissOnPageChange: false
    });
    this.loading.present();

    let meusCartoes = window.localStorage.getItem("meuscartoes");

    if (meusCartoes != null && meusCartoes != "") {
      this.cartoesTicket = JSON.parse(meusCartoes);
    }
    let cartoesOcultos: any[] = [];
    let auxCartoesOcultos = window.localStorage.getItem("cartoesOcultos");
    if (auxCartoesOcultos != null && auxCartoesOcultos != "") {
      cartoesOcultos = JSON.parse(auxCartoesOcultos);
    }

    if (reload || this.cartoesTicket.length == 0) {
      this.usuarioSerice.obterCartoesTicket().then(
        (res: any) => {
          if (res != null && res.objeto) {
            this.cartoesTicket = [];

            res.objeto.forEach(element => {
              element.dataUltimaAtualizacao = new Date();
              element.numeroCartao = this.formatarNumeroCartao(element.numero);

              if (cartoesOcultos.filter(c => c == element.numero).length == 0) {
                this.cartoesTicket.push(element);
              }
            });

            window.localStorage.setItem(
              "meuscartoes",
              JSON.stringify(this.cartoesTicket)
            );
          }

          this.erroObter = false;
          this.loading.dismiss();
        },
        err => {
          this.erroObter = true;
          this.loading.dismiss();
        }
      );
    } else {
      this.loading.dismiss();
    }
  }

  formatarNumeroCartao(texto) {
    let array = texto.replace(/\s+/g, "").split("");
    let novoValor = "";
    let contador = 0;

    for (let index = 0; index < array.length; index++) {
      contador++;
      const char = array[index];

      if (array.length - 4 > index) {
        novoValor += "*";
      } else {
        novoValor += char;
      }

      if (contador === 4) {
        novoValor += " ";
        contador = 0;
      }
    }

    return novoValor;
  }

  add() {
    let modal = this.modalCtrl.create(MeuCartaoAdicionarPage);
    modal.onDidDismiss(data => {
      if (data) {
        this.obterCartoesTicket(true);
      }
    });
    modal.present();
  }

  remover(item, index) {
    let alert = this.alertCtrl.create({
      title: "Atenção",
      message:
        "Deseja realmente excluir todos os cartões vinculados à conta <b>" +
        item.email +
        "</b> deste aplicativo?",
      buttons: [
        {
          text: "Não",
          handler: () => {}
        },
        {
          text: "Sim",
          handler: () => {
            this.loading = this.loadingCtrl.create({
              content: "Aguarde...",
              dismissOnPageChange: false
            });
            this.loading.present();

            this.usuarioSerice.removerContaAcesso(item.idContaAcesso).then(
              (res: any) => {
                this.loading.dismiss();
                this.cartoesTicket = [];
                this.obterCartoesTicket(true);
              },
              err => {
                this.loading.dismiss();
              }
            );
          }
        }
      ]
    });
    alert.present();
  }
}
