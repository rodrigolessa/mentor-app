import { Component, ViewChild } from "@angular/core";
import {
  AlertController,
  LoadingController,
  FabContainer,
  ModalController,
  NavController
} from "ionic-angular";

import { Chart } from "chart.js";
import { CalendarioService, Usuario } from "../../provedores/provedores";
import { Subscription } from "rxjs/Subscription";
import { Util } from "../../shared/util";
import { AtividadeDetalheModal } from "../modais/atividadeDetalhe/atividadeDetalhe";
import { PitacosPage } from "../extras/pitacos/pitacos";
import { MeusPitacosPage } from "../extras/pitacos/meusPitacos/meusPitacos";

declare var Appsee: any;

@Component({
  selector: "page-resumo",
  templateUrl: "resumo.html"
})
export class ResumoPage {
  @ViewChild("consumoChart") consumoCanvas;
  @ViewChild("preditivoChart") preditivoCanvas;

  exibirPitaco = false;
  colocacoesPitacos: any[] = [];
  meuId: any;
  meuAniversario: boolean = false;
  habilitarRefresher: boolean = true;
  dataHojeTexto: string = "";
  saldo: string = "00:00";
  exibirLoading: any = {};
  erroLoading: any = {};
  cartoesTicket: any[];
  consumoPonto: any[];
  errosPontos: any[];
  atividades: any[] = [];
  atividadesOcultadas: any[] = [];
  aniversariantesPassados: any[];
  aniversariantes: any[] = [];
  felicitacoes: any[];
  preditivoChart: any;
  consumoChart: any;
  calendarioSub: Subscription;
  calendario = {
    nome: "Calendario 1",
    itens: [],
    cor: "Preta"
  };

  loading = this.loadingCtrl.create({
    content: "Aguarde...",
    dismissOnPageChange: true
  });

  timerTap: any;

  constructor(
    private alertCtrl: AlertController,
    private navCtrl: NavController,
    private loadingCtrl: LoadingController,
    private calendarioSerice: CalendarioService,
    private usuarioSerice: Usuario,
    private modalCtrl: ModalController,
    private util: Util
  ) {
    if (typeof Appsee !== "undefined") Appsee.startScreen("Tela Inicial");
  }

  ionViewDidEnter() {
    this.dataHojeTexto = this.util.dataAtualFormatadaTexto();
    // this.obterPitacosRanking();
  }

  ionViewDidLoad() {
    this.iniciar();
    this.preditivoChart = new Chart(this.preditivoCanvas.nativeElement, {
      type: "line",
      data: {
        labels: ["Abril", "Junho"],
        datasets: [
          {
            label: "Tempo necessário para o período",
            fill: true,
            lineTension: 0.1,
            backgroundColor: "rgba(75,192,192,0.4)",
            color: "white",
            borderColor: "rgba(75,192,192,1)",
            borderCapStyle: "butt",
            borderDash: [],
            borderJoinStyle: "miter",
            pointBorderColor: "rgba(75,192,192,1)",
            pointBackgroundColor: "#fff",
            pointHoverBackgroundColor: "rgba(75,192,192,1)",
            pointHoverBorderColor: "rgba(220,220,220,1)",
            pointRadius: 6,
            pointHitRadius: 10,
            data: [8.3, 0]
          }
        ]
      },
      options: {
        maintainAspectRatio: false,
        legend: {
          display: false,
          labels: {
            fontColor: "white"
          }
        },
        scales: {
          yAxes: [
            {
              ticks: {
                fontColor: "white"
              }
            }
          ],
          xAxes: [
            {
              ticks: {
                fontColor: "white"
              }
            }
          ]
        }
      }
    });
  }

  ionViewWillLeave() {
    this.calendarioSub.unsubscribe();
  }

  desabilitarRefresher(desativa) {
    this.habilitarRefresher = !desativa;
  }

  irParaDetalhe(item) {
    let modal = this.modalCtrl.create(AtividadeDetalheModal, {
      evento: item.Objeto
    });
    modal.present();
  }

  ocultarPitacos() {
    window.localStorage.setItem(
      "dataExibirPitacos",
      JSON.stringify(new Date())
    );

    this.exibirPitaco = false;
  }

  obterPitacosRanking() {
    let dataExibirPitacosAux = JSON.parse(
      window.localStorage.getItem("dataExibirPitacos")
    );

    if (dataExibirPitacosAux != null && dataExibirPitacosAux != "") {
      let dataAgora = new Date();
      dataAgora = new Date(dataAgora.setMinutes(dataAgora.getMinutes() - 3));
      dataExibirPitacosAux = new Date(dataExibirPitacosAux);

      setTimeout(() => {
        this.exibirPitaco =
          dataExibirPitacosAux.getTime() - dataAgora.getTime() <= 0;
      }, 1500);
    } else {
      setTimeout(() => {
        this.exibirPitaco = true;
      }, 1500);
    }

    // this.colocacoesPitacos = [];
    // this.exibirLoading.pitacos = true;
    // this.erroLoading.pitacos = false;

    // this.pitacosService.obterRanking().then(
    //   (colocacoes: any) => {
    //     if (colocacoes != null && colocacoes.objeto != null) {
    //       this.colocacoesPitacos = colocacoes.objeto;
    //       this.colocacoesPitacos = this.colocacoesPitacos.slice(0, 3);
    //     } else {
    //       this.erroLoading.pitacos = true;
    //     }

    //     this.exibirLoading.pitacos = false;
    //   },
    //   err => {
    //     this.erroLoading.pitacos = true;
    //     this.exibirLoading.pitacos = false;
    //   }
    // );
  }

  obterCalendario() {
    this.atividades = [];
    this.exibirLoading.calendario = true;
    this.erroLoading.calendario = false;

    this.calendarioSub = this.calendarioSerice
      .obterCalendario()
      .subscribe((calendario: any) => {
        if (calendario != null) {
          this.calendario = calendario;
          let formatoAtividadeCalendario = [];

          calendario.itens.forEach(itemCalendario => {
            let atividade = {
              Id: "",
              Data: "",
              Itens: []
            };

            if (
              formatoAtividadeCalendario.filter(
                a => a.Data == itemCalendario.data
              ).length === 0
            ) {
              atividade.Data = itemCalendario.data;
              formatoAtividadeCalendario.push(atividade);
            }

            atividade = formatoAtividadeCalendario.filter(
              a => a.Data == itemCalendario.data
            )[0];

            if (itemCalendario.diaTodo) {
              atividade.Itens.push({
                Id: itemCalendario.id,
                Mensagem: `${itemCalendario.nome}`,
                Icone:
                  itemCalendario != null && itemCalendario.local != ""
                    ? "people"
                    : "calendar",
                Objeto: itemCalendario
              });
            } else {
              atividade.Itens.push({
                Id: itemCalendario.id,
                Mensagem: `${itemCalendario.nome} às ${itemCalendario.hora}`,
                Icone:
                  itemCalendario != null && itemCalendario.local != ""
                    ? "people"
                    : "calendar",
                Objeto: itemCalendario
              });
            }

            formatoAtividadeCalendario[
              formatoAtividadeCalendario.findIndex(
                a => a.Data == atividade.Data
              )
            ] = atividade;
          });

          this.adicionarAtividades(formatoAtividadeCalendario);
        } else {
          this.erroLoading.calendario = true;
        }

        this.exibirLoading.calendario = false;
      });
  }

  obterErrosPonto() {
    this.exibirLoading.erroPonto = true;
    this.erroLoading.erroPonto = false;

    this.usuarioSerice.obterErrosPonto().then(
      (errosPontos: any) => {
        if (errosPontos != null) {
          if (errosPontos.objeto == null) {
            this.exibirLoading.erroPonto = false;
            return;
          }

          this.errosPontos = errosPontos.objeto;
          let formatoAtividadeErrosPontos = [];

          errosPontos.objeto.forEach(itemErroPonto => {
            let atividade = {
              Id: "",
              Data: "",
              Itens: []
            };

            if (
              formatoAtividadeErrosPontos.filter(
                a => a.Data == itemErroPonto.data
              ).length === 0
            ) {
              atividade.Data = itemErroPonto.data;
              formatoAtividadeErrosPontos.push(atividade);
            }

            atividade = formatoAtividadeErrosPontos.filter(
              a => a.Data == itemErroPonto.data
            )[0];

            atividade.Itens.push({
              Id: itemErroPonto.id,
              Mensagem: `${itemErroPonto.nome}`,
              Icone: "clock",
              Objeto: itemErroPonto
            });

            formatoAtividadeErrosPontos[
              formatoAtividadeErrosPontos.findIndex(
                a => a.Data == atividade.Data
              )
            ] = atividade;
          });

          this.adicionarAtividades(formatoAtividadeErrosPontos);
        } else {
          this.erroLoading.erroPonto = true;
        }

        this.exibirLoading.erroPonto = false;
      },
      err => {
        this.exibirLoading.erroPonto = false;
        this.erroLoading.erroPonto = true;
      }
    );
  }

  obterSaldoPonto() {
    this.exibirLoading.saldo = true;
    this.erroLoading.saldo = false;

    this.usuarioSerice.obterSaldoPonto().then(
      (saldoRes: any) => {
        if (saldoRes != null && saldoRes.objeto) {
          let ehNegativo = false;

          if (saldoRes.objeto.saldo == "--:--") {
            this.saldo = "--:--";
            this.exibirLoading.saldo = false;
            return;
          }

          if (saldoRes.objeto.saldo.toString()[0] === "-") {
            ehNegativo = true;
            saldoRes.objeto.saldo = saldoRes.objeto.saldo * -1;
          }

          let h = Math.floor(saldoRes.objeto.saldo / 60);
          let m = saldoRes.objeto.saldo % 60;
          let sH = h < 10 ? "0" + h : h;
          let sM = m < 10 ? "0" + m : m;
          let time = sH + ":" + sM;
          this.saldo = (ehNegativo ? "-" : "") + time;
        } else {
          this.erroLoading.saldo = true;
        }

        this.exibirLoading.saldo = false;
      },
      err => {
        this.exibirLoading.saldo = false;
        this.erroLoading.saldo = true;
      }
    );
  }

  obterConsumoPonto() {
    this.exibirLoading.consumo = true;
    this.erroLoading.consumo = false;

    this.usuarioSerice.obterConsumoPonto().then(
      (consumo: any) => {
        if (consumo != null && consumo.objeto) {
          this.consumoPonto = consumo.objeto;
          let dataPonto: any[] = [];
          let labelPonto: any[] = [];

          this.consumoPonto.forEach(element => {
            let saldoDia = element.saldoMinutos;
            saldoDia = saldoDia;
            //formatar data para remover o ano
            element.data =
              element.data.split("/")[0] + "/" + element.data.split("/")[1];

            if (!element.justificativa) {
              labelPonto.push(element.data);
              dataPonto.push(saldoDia);
            }
          });

          labelPonto = labelPonto.reverse();
          dataPonto = dataPonto.reverse();

          this.consumoChart = new Chart(this.consumoCanvas.nativeElement, {
            type: "line",
            data: {
              labels: labelPonto,
              datasets: [
                {
                  label: "Saldo do dia",
                  fill: true,
                  lineTension: 0.1,
                  backgroundColor: "rgba(75,192,192,0.4)",
                  color: "white",
                  borderColor: "rgba(75,192,192,1)",
                  borderCapStyle: "butt",
                  borderDash: [],
                  borderJoinStyle: "miter",
                  pointBorderColor: "rgba(75,192,192,1)",
                  pointBackgroundColor: "#fff",
                  pointHoverBackgroundColor: "rgba(75,192,192,1)",
                  pointHoverBorderColor: "rgba(220,220,220,1)",
                  pointRadius: 6,
                  pointHitRadius: 10,
                  data: dataPonto
                }
              ]
            },
            options: {
              maintainAspectRatio: false,
              legend: {
                display: false,
                labels: {
                  fontColor: "white"
                }
              },
              tooltips: {
                callbacks: {
                  label: function(tooltipItem, data) {
                    let h = Math.floor(tooltipItem.yLabel / 60);
                    let m = tooltipItem.yLabel % 60;
                    let sH = h < 10 ? "0" + h : h;
                    let sM = m < 10 ? "0" + m : m;
                    let time = sH + ":" + sM;

                    var label =
                      data.datasets[tooltipItem.datasetIndex].label || "";

                    if (label) {
                      label += ": ";
                    }
                    label += time;
                    return label;
                  }
                }
              },
              scales: {
                yAxes: [
                  {
                    ticks: {
                      fontColor: "white",
                      callback: function(value) {
                        let h = Math.floor(value / 60);
                        let m = value % 60;
                        let sH = h < 10 ? "0" + h : h;
                        let sM = m < 10 ? "0" + m : m;
                        let time = sH + ":" + sM;
                        return time;
                      }
                    }
                  }
                ],
                xAxes: [
                  {
                    ticks: {
                      fontColor: "white"
                    }
                  }
                ]
              }
            }
          });
        } else {
          if (!consumo.sucesso) {
            this.erroLoading.consumo = true;
          }
        }

        this.exibirLoading.consumo = false;
      },
      err => {
        this.exibirLoading.consumo = false;
        this.erroLoading.consumo = true;
      }
    );
  }

  obterFelicitacoes() {
    this.exibirLoading.felicitacao = true;
    this.erroLoading.felicitacao = false;
    this.felicitacoes = [];

    this.usuarioSerice.obterFelicitacoes().then(
      (res: any) => {
        if (res != null && res.objeto != null) {
          res.objeto.forEach(element => {
            if (element.fotoUrl == null || element.fotoUrl === "") {
              element.fotoUrl = "assets/img/LD-PRETO-240X240.png";
            } else {
              if (element.fotoUrl.indexOf("http") === -1) {
                element.fotoUrl = "assets/img/colaborador/" + element.fotoUrl;
              }
            }

            this.felicitacoes.push({
              Nome: element.nome,
              Imagem: element.fotoUrl,
              Mensagem: element.mensagem,
              Data: element.data
                .split("T")[0]
                .split("-")
                .reverse()
                .join("/")
            });
          });
        }

        this.exibirLoading.felicitacao = false;
      },
      err => {
        this.exibirLoading.felicitacao = false;
        this.erroLoading.felicitacao = true;
      }
    );

    this.felicitacoes = this.felicitacoes.sort((a, b) => {
      let resultaAB =
        this.util.formataData(a.Data).getTime() -
        this.util.formataData(b.Data).getTime();

      return resultaAB > 0 ? 1 : resultaAB === 0 ? 0 : -1;
    });

    this.exibirLoading.felicitacao = false;
  }

  obterAniversariantes() {
    this.exibirLoading.aniversariante = true;
    this.erroLoading.aniversariante = false;
    this.aniversariantes = [];
    this.aniversariantesPassados = [];

    this.usuarioSerice.obterAniversariantes().then(
      (res: any) => {
        if (res != null && res.objeto != null) {
          this.aniversariantes = [];
          this.aniversariantesPassados = [];

          let dataHoje = this.util.dataAtualFormatada();
          let proximoAniversario: any = null;

          res.objeto.forEach(element => {
            if (element.fotoUrl == null || element.fotoUrl === "") {
              element.fotoUrl = "assets/img/LD-PRETO-240X240.png";
            } else {
              if (element.fotoUrl.indexOf("http") === -1) {
                element.fotoUrl = "assets/img/colaborador/" + element.fotoUrl;
              }
            }
            let niver = element.dataAniversario.split("T")[0].split("-");
            let auxAnoAtual = new Date().getFullYear();

            niver[0] = auxAnoAtual;
            element.dataAniversario = niver.reverse().join("/");

            this.aniversariantes.push({
              Id: element.id,
              Nome: element.nome,
              Imagem: element.fotoUrl,
              Data: element.dataAniversario,
              FelicitacaoEnviada: element.felicitacaoEnviada
            });
          });

          this.aniversariantes = this.aniversariantes.sort((a, b) => {
            let resultaAB =
              this.util.formataData(a.Data).getTime() -
              this.util.formataData(b.Data).getTime();

            return resultaAB > 0 ? 1 : resultaAB === 0 ? 0 : -1;
          });

          this.aniversariantes.forEach(element => {
            if (
              proximoAniversario == null ||
              (this.util.formataData(element.Data).getTime() >=
                dataHoje.getTime() &&
                this.util.formataData(proximoAniversario.Data).getTime() <
                  dataHoje.getTime())
            ) {
              proximoAniversario = element;
            }
          });

          // setTimeout(() => {
          //   document.getElementById("niver_" + proximoAniversario.Id).scrollIntoView(false);
          // }, 1000);

          // nessa parte é feita a separação dos aniversários que já passaram, para uma outra lista

          this.aniversariantesPassados = this.aniversariantes.filter(
            a => this.util.formataData(a.Data).getTime() < dataHoje.getTime()
          );

          this.aniversariantes = this.aniversariantes.filter(
            a => this.util.formataData(a.Data).getTime() >= dataHoje.getTime()
          );
        }

        this.exibirLoading.aniversariante = false;
      },
      err => {
        this.exibirLoading.aniversariante = false;
        this.erroLoading.aniversariante = true;
      }
    );
  }

  iniciar(update?: boolean) {
    if (update) {
      this.usuarioSerice.obter().then(
        (resp: any) => {
          window.localStorage.setItem(
            "colaborador",
            JSON.stringify(resp.objeto)
          );
          if (typeof Appsee !== "undefined") {
            Appsee.setUserId(resp.objeto.nome);
          }

          this.iniciar();
        },
        err => {
          this.iniciar();
        }
      );

      return;
    }

    let atvOculta = window.localStorage.getItem("atividadesOcultadas");
    let auxColaborador = window.localStorage.getItem("colaborador");

    if (atvOculta != null && atvOculta != "") {
      this.atividadesOcultadas = JSON.parse(atvOculta);
    }

    if (auxColaborador != null && auxColaborador != "") {
      let colaborador = JSON.parse(auxColaborador);
      this.meuId = colaborador.id;
      let auxDataNiver: any[] = colaborador.dataAniversario
        .split("T")[0]
        .split("-");
      auxDataNiver.shift();

      let dataHoje = this.util.dataAtualFormatadaSemAnoTexto();
      let dataNiver = auxDataNiver.reverse().join("/");

      if (dataHoje == dataNiver) {
        this.meuAniversario = true;
      }

      if (
        colaborador.tokenPushNotification == "" ||
        colaborador.tokenPushNotification == null
      ) {
        this.salvarTokenPushNotification();
      }
    }

    this.obterSaldoPonto();
    this.obterConsumoPonto();
    this.obterFelicitacoes();
    this.obterAniversariantes();
    this.obterCalendario();
    this.obterErrosPonto();
    //extras
    this.obterPitacosRanking();
  }

  verMaisPitacos() {
    this.navCtrl.push(PitacosPage);
  }

  verMeusPitacos() {
    this.navCtrl.push(MeusPitacosPage);
  }

  salvarTokenPushNotification() {
    let tokenPush: any = null;
    let auxTokenPush = window.localStorage.getItem("tokenPushAtualizado");

    if (auxTokenPush != null && auxTokenPush != "") {
      tokenPush = JSON.parse(auxTokenPush);
    } else {
      // TODO: aqui deve se obter o token de push, solicitando autorização ou
      // somente pegando o token ja autorizado
    }

    if (tokenPush != null && !tokenPush.status) {
      this.usuarioSerice.salvarTokenPushNotification(tokenPush.token).then(
        (res: any) => {
          if (res.sucesso) {
            window.localStorage.setItem(
              "tokenPushAtualizado",
              "{status: true, token: '" + tokenPush + "'}"
            );
          } else {
            window.localStorage.setItem(
              "tokenPushAtualizado",
              "{status: false, token: '" + tokenPush + "'}"
            );
          }
        },
        err => {
          window.localStorage.setItem(
            "tokenPushAtualizado",
            "{status: false, token: '" + tokenPush + "'}"
          );
        }
      );
    }
  }

  adicionarAtividades(item: any) {
    item.forEach(element => {
      let atividade = {
        Grupo: "",
        Itens: []
      };

      if (this.atividades.filter(a => a.Grupo == element.Data).length === 0) {
        atividade.Grupo = element.Data;
        this.atividades.push(atividade);
      }

      atividade = this.atividades.filter(a => a.Grupo == element.Data)[0];

      element.Itens.forEach(item => {
        if (atividade.Itens.filter(a => a.Id == item.Id).length === 0) {
          if (this.atividadesOcultadas.filter(a => a == item.Id).length === 0) {
            atividade.Itens.push({
              Id: item.Id,
              Mensagem: item.Mensagem,
              Icone: item.Icone,
              Objeto: item.Objeto
            });
          }
        }
      });

      this.atividades[
        this.atividades.findIndex(a => a.Grupo == atividade.Grupo)
      ] = atividade;
    });

    this.atividades = this.atividades.sort((a, b) => {
      return this.util.formataData(a.Grupo).getTime() -
        this.util.formataData(b.Grupo).getTime() <=
        0
        ? -1
        : this.util.formataData(a.Grupo).getTime() -
            this.util.formataData(b.Grupo).getTime() ===
          0
          ? 0
          : 1;
    });
  }

  removerItem(index, item, msg) {
    this.atividadesOcultadas.push(msg.Id);
    item.Itens.splice(index, 1);
    window.localStorage.setItem(
      "atividadesOcultadas",
      JSON.stringify(this.atividadesOcultadas)
    );
  }

  todosItensOcultados() {
    let existeItem = false;

    this.atividades.forEach(item => {
      if (item.Itens.length > 0) {
        existeItem = true;
      }
    });

    return !existeItem;
  }

  doRefresh(refresher) {
    this.iniciar(true);
    refresher.complete();
  }

  abrirFabAniversario(id: string) {
    var elements = window.document.getElementsByName("nome-aniversario-" + id);
    for (let index = 0; index < elements.length; index++) {
      const element = elements[index];
      element.classList.toggle("esconder");
    }
  }

  exibirAlerta(msg: string) {
    let alert = this.alertCtrl.create({
      title: "Atenção",
      subTitle: msg,
      buttons: ["OK"]
    });
    alert.present();
  }

  enviarFelicitacao(item: any, tipo: string, fab: FabContainer) {
    fab.close();
    item.EnviandoFelicitacao = true;

    this.usuarioSerice
      .adicionarFelicitacao({
        IdColaboradorFelicitacao: item.Id,
        Mensagem: tipo
      })
      .then(
        (res: any) => {
          item.EnviandoFelicitacao = false;
          item.FelicitacaoEnviada = true;
          let felicitacoesEnviadas = window.localStorage.getItem(
            "felicitacoesEnviadas"
          );
          let auxFel = [];

          if (felicitacoesEnviadas != null && felicitacoesEnviadas != "") {
            auxFel = JSON.parse(felicitacoesEnviadas);
          }

          auxFel.push({ Id: item.Id, Data: item.Data });
          window.localStorage.setItem(
            "felicitacoesEnviadas",
            JSON.stringify(auxFel)
          );

          let alert = this.alertCtrl.create({
            title: "Informação",
            subTitle: `Sua felicitação para o colaborador <b>${
              item.Nome
            }</b> foi enviada com sucesso.`,
            buttons: ["OK"]
          });
          alert.present();
        },
        err => {
          item.EnviandoFelicitacao = false;
        }
      );

    this.abrirFabAniversario(item.Id);
  }
}
