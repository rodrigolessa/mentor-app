import { Component, NgZone } from "@angular/core";
import {
  MenuController,
  NavController,
  Platform,
  ViewController
} from "ionic-angular";
import { BemVindoPage } from "../bem-vindo/bem-vindo";
import { TabsPage } from "../tabs/tabs";
import { TutorialPage } from "../tutorial/tutorial";
import { Usuario } from "../../provedores/provedores";
import { Pro } from "@ionic/pro";
import { PushNotification } from "../../shared/pushNotification";
declare var Appsee: any;

@Component({
  selector: "page-splashScreen",
  templateUrl: "splashScreen.html"
})
export class SplashScreenPage {
  public deployChannel = "";
  public downloadProgress? = 0;
  public atualizacaoEmProgresso: Boolean = false;
  public textoAtualizacao: string = "";
  public verificandoAtualizacao: Boolean = false;

  constructor(
    public menu: MenuController,
    public platform: Platform,
    private viewCtrl: ViewController,
    public usuario: Usuario,
    private navCtrl: NavController,
    private ngZone: NgZone,
    private pushNotification: PushNotification
  ) {}

  async ionViewWillEnter(secondShot?: boolean) {
    if (typeof Appsee !== "undefined") {
      Appsee.startScreen("Tela Splash");
    }

    await this.verificarAtualizacao();

    this.viewCtrl.showBackButton(true);

    let tutorialCompleto = false;
    let tutorialItemStorage = window.localStorage.getItem("tutorialCompleto");
    let tokenItemStorage = window.localStorage.getItem("token");

    if (tokenItemStorage == null || tokenItemStorage === "") {
      if (tutorialItemStorage != null && tutorialItemStorage != "") {
        tutorialCompleto = JSON.parse(tutorialItemStorage);

        if (tutorialCompleto) {
          this.navCtrl.setRoot(BemVindoPage);
        } else {
          this.navCtrl.setRoot(TutorialPage);
        }
      } else {
        this.navCtrl.setRoot(TutorialPage);
      }
    } else {
      this.usuario.obter().then(
        (resp: any) => {
          window.localStorage.setItem(
            "colaborador",
            JSON.stringify(resp.objeto)
          );
          if (typeof Appsee !== "undefined") {
            Appsee.setUserId(resp.objeto.nome);
          }
          this.pushNotification.definirTag(
            "usuario",
            resp.objeto.email.split("@")[0]
          );
          this.pushNotification.definirTag(
            "departamento",
            resp.objeto.departamento
          );

          if (!resp.objeto.ehBeta) {
            window.localStorage.setItem("ehBeta", JSON.stringify(false));
          }

          this.navCtrl.setRoot(TabsPage);
        },
        err => {
          if (secondShot) {
            window.localStorage.removeItem("token");
          }

          this.ionViewWillEnter(true);
        }
      );
    }
  }

  ionViewDidEnter() {}

  async verificarAtualizacao() {
    this.verificandoAtualizacao = true;

    // setInterval(res => {
    //   this.textoAtualizacao = "Baixando atualização";
    //   this.downloadProgress++;
    //   this.atualizacaoEmProgresso = this.downloadProgress >= 1000 ? false : true;
    // }, 500);

    try {
      console.log("verificando atualizacao");
      await this.performManualUpdate();
      console.log("verificação concluida com sucesso!");
    } catch (err) {
      console.log("algo deu errado na verificação");

      Pro.monitoring.exception(err);
    }
  }

  async performAutomaticUpdate() {
    try {
      this.atualizacaoEmProgresso = true;

      const resp = await Pro.deploy.checkAndApply(true, function(progress) {
        console.log("atualização em andamento", progress);
        this.downloadProgress = progress;
      });

      if (resp.update) {
        console.log("atualizado com sucesso!");
      } else {
        console.log("sem atualização disponível");
      }

      this.atualizacaoEmProgresso = false;
    } catch (err) {
      this.atualizacaoEmProgresso = false;
      console.log("Erro verificação de atualização", err);
      Pro.monitoring.exception(err);
    }
  }

  async performManualUpdate() {
    try {
      let ehAppBeta = JSON.parse(window.localStorage.getItem("ehBeta"));

      const config = {
        appId: "fb4e1808",
        channel: ehAppBeta ? "Beta" : "Production"
      };

      if (!this.platform.is("cordova")) {
        this.verificandoAtualizacao = false;
      } else {
        await Pro.deploy.init(config);
        this.atualizacaoEmProgresso = await Pro.deploy.check();
        this.verificandoAtualizacao = false;

        if (this.atualizacaoEmProgresso) {
          this.downloadProgress = 0;
          this.textoAtualizacao = "Baixando atualização";

          await Pro.deploy.download(progress => {
            if (progress != null) {
              this.ngZone.run(() => {
                this.downloadProgress = progress;
              });
            }
            console.log("Baixando atualização...", progress);
          });

          this.ngZone.run(() => {
            this.downloadProgress = -1;
          });

          this.textoAtualizacao = "Instalando atualização";
          await Pro.deploy.extract();
          this.textoAtualizacao = "Aplicando atualização";
          await Pro.deploy.redirect();
        } else {
          console.log("não existe update");
        }
      }
    } catch (err) {
      this.verificandoAtualizacao = false;
      console.log("erro update", err);
      Pro.monitoring.exception(err);
    }
  }
}
