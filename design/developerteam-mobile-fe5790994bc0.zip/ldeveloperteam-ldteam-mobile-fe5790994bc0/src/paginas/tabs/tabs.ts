import { Component, ViewChild } from "@angular/core";
import {
  NavController,
  NavParams,
  ViewController,
  Navbar
} from "ionic-angular";
import { ResumoPage } from "../resumo/resumo";
import { ContatoPage } from "../contato/contato";
import { MaisPage } from "../mais/mais";
import {
  NativePageTransitions,
  NativeTransitionOptions
} from "@ionic-native/native-page-transitions";
import { CalendarioPage } from "../calendario/calendario";

@Component({
  selector: "page-tabs",
  templateUrl: "tabs.html"
})
export class TabsPage {
  @ViewChild(Navbar) navBar: Navbar;
  loaded: boolean = false;
  tabIndex: number = 0;

  tabInicio: any = ResumoPage;
  tabContato: any = ContatoPage;
  tabCalendario: any = CalendarioPage;
  tabMais: any = MaisPage;

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private viewCtrl: ViewController,
    private nativePageTransitions: NativePageTransitions
  ) {}

  ionViewWillEnter() {
    this.viewCtrl.showBackButton(true);

    // this.navBar.backButtonClick = (e: UIEvent) => {
    //   this.navCtrl.setRoot(TabsPage);
    // };
    // colocar imagem na tab
    /*
    let colaborador = JSON.parse(window.localStorage.getItem("colaborador"));

    let array = document.getElementsByClassName("tabbar");
    let tabbar = array[0];
    let element = tabbar.childNodes[tabbar.childElementCount - 1];
    if (element) {
      element.removeChild(element.childNodes[1]);
      let div = document.createElement("div");
      div.setAttribute("class", "tab-button-icon");

      if (colaborador.fotoUrl.indexOf("http") === -1) {
        colaborador.fotoUrl =
          "assets/img/colaborador/" + colaborador.fotoUrl;
      }

      if (colaborador.fotoUrl == null || colaborador.fotoUrl === "") {
        colaborador.fotoUrl = "assets/img/LD-PRETO-240X240.png";
      }

      div.setAttribute(
        "style",
        `background: url('${
          colaborador.fotoUrl
        }') center center; -webkit-background-size: cover; background-size: cover; border-radius: 50%; min-width: 30px !important; width: 30px; height: 30px;`
      );
      element.insertBefore(div, element.childNodes[1]);
    }*/
  }

  ionViewDidLoad() {}

  private getAnimationDirection(index): string {
    var currentIndex = this.tabIndex;

    this.tabIndex = index;

    switch (true) {
      case currentIndex < index:
        return "left";
      case currentIndex > index:
        return "right";
    }
  }

  public transition(e): void {
    let options: NativeTransitionOptions = {
      direction: this.getAnimationDirection(e.index),
      duration: 200,
      slowdownfactor: -1,
      slidePixels: 0,
      iosdelay: 20,
      androiddelay: 0,
      fixedPixelsTop: 0,
      fixedPixelsBottom: 40
    };

    if (!this.loaded) {
      this.loaded = true;
      return;
    }

    this.nativePageTransitions.slide(options);
  }

  goBack() {
    this.navCtrl.pop();
  }
}
