import { Component } from "@angular/core";
import {
  NavController,
  NavParams,
  AlertController,
  LoadingController,
  Keyboard
} from "ionic-angular";
import { PitacosService } from "../../../provedores/extra/pitacos";
import { MeusPitacosPage } from "./meusPitacos/meusPitacos";
declare var Appsee: any;

@Component({
  selector: "page-pitacos",
  templateUrl: "pitacos.html"
})
export class PitacosPage {
  loading = this.loadingCtrl.create({
    content: "Aguarde...",
    dismissOnPageChange: true
  });

  colaborador: any = {};
  colocacoes: any[] = [];
  colocacoesOriginais: any[] = [];
  erroObter = false;
  textoBusca = "";
  MeusPitacos: any = MeusPitacosPage;

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public alertCtrl: AlertController,
    private pitacosService: PitacosService,
    public loadingCtrl: LoadingController,
    private keyboard: Keyboard
  ) {
    if (typeof Appsee !== "undefined") {
      Appsee.startScreen("Tela do pitacos");
    }
  }

  irPara(page) {
    this.navCtrl.push(page);
  }

  ionViewWillEnter() {
    let colaboradorAux = window.localStorage.getItem("colaborador");

    if (colaboradorAux != null && colaboradorAux != "") {
      this.colaborador = JSON.parse(colaboradorAux);
    }
  }

  ionViewDidLoad() {
    this.obterRanking();
  }

  doRefresh(refresher) {
    refresher.complete();
    this.obterRanking();
  }

  closeKeyboard(ev: any) {
    this.getItems(ev);
    this.keyboard.close();
  }

  getItems(ev?: any) {
    this.colocacoes = [];
    this.colocacoes = this.colocacoesOriginais;
    let val = ev != null ? ev.target.value : this.textoBusca;

    if (val && val.trim() != "") {
      this.colocacoes = this.colocacoesOriginais.filter(
        item =>
          this.accentFold(item.nome)
            .toLowerCase()
            .indexOf(this.accentFold(val).toLowerCase()) > -1 ||
          item.colocacao.toLowerCase().indexOf(val.toLowerCase()) > -1 ||
          item.pontuacao.toLowerCase().indexOf(val.toLowerCase()) > -1
      );
    }
  }

  accentFold(inStr) {
    return inStr.replace(
      /([àáâãäå])|([ç])|([èéêë])|([ìíîï])|([ñ])|([òóôõöø])|([ß])|([ùúûü])|([ÿ])|([æ])/g,
      function(str, a, c, e, i, n, o, s, u, y, ae) {
        if (a) return "a";
        if (c) return "c";
        if (e) return "e";
        if (i) return "i";
        if (n) return "n";
        if (o) return "o";
        if (s) return "s";
        if (u) return "u";
        if (y) return "y";
        if (ae) return "ae";
      }
    );
  }

  obterRanking() {
    this.loading = this.loadingCtrl.create({
      content: "Aguarde...",
      dismissOnPageChange: false
    });
    this.loading.present();
    this.erroObter = false;

    this.pitacosService.obterRanking().then(
      (colocacoes: any) => {
        if (colocacoes != null && colocacoes.objeto != null) {
          this.colocacoes = colocacoes.objeto;
          this.colocacoesOriginais = colocacoes.objeto;
        } else {
          this.erroObter = true;
        }

        this.loading.dismiss();
      },
      err => {
        this.erroObter = true;
        this.loading.dismiss();
      }
    );
  }
}
