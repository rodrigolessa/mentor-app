import { Component, ViewChild } from "@angular/core";
import {
  NavController,
  NavParams,
  AlertController,
  LoadingController,
  TextInput
} from "ionic-angular";
import { PitacosService } from "../../../../provedores/extra/pitacos";
import { Util } from "../../../../shared/util";
declare var Appsee: any;

@Component({
  selector: "page-meusPitacos",
  templateUrl: "meusPitacos.html"
})
export class MeusPitacosPage {
  @ViewChild("inputSenha") inputSenha: TextInput;

  loading = this.loadingCtrl.create({
    content: "Aguarde...",
    dismissOnPageChange: true
  });

  diaHoje = "";
  ehExibirForm = true;
  pitacos: any[] = [];
  pitacosAgrupado: any[] = [];
  erroObter = false;
  textoBusca = "";
  contaAcesso: any = {};

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public alertCtrl: AlertController,
    private pitacosService: PitacosService,
    public loadingCtrl: LoadingController,
    private util: Util
  ) {
    if (typeof Appsee !== "undefined") {
      Appsee.startScreen("Tela dos meus pitacos");
    }
  }

  ionViewWillEnter() {
    this.diaHoje = this.util.dataAtualFormatadaCompletaSemAnoTexto();
  }

  ionViewDidLoad() {
    let contaAcessoAux = window.localStorage.getItem("meuPitacos");

    if (contaAcessoAux != null && contaAcessoAux != "") {
      this.ehExibirForm = false;
      this.contaAcesso = JSON.parse(contaAcessoAux);
      this.salvar();
    }
  }

  exibirForm() {
    this.ehExibirForm = !this.ehExibirForm;
  }

  doRefresh(refresher) {
    refresher.complete();
    this.salvar();
  }

  enterSenha(event) {
    if (event.keyCode === 13) {
      if (this.inputSenha != null) {
        this.inputSenha.setFocus();
      }
    }
  }

  enterAdicionar(event) {
    if (event.keyCode === 13) {
      this.salvar();
    }
  }

  salvar() {
    let erros: any[] = [];

    if (this.contaAcesso.email == null || this.contaAcesso.email == "") {
      erros.push("E-mail é obrigatório");
    }
    if (this.contaAcesso.senha == null || this.contaAcesso.senha == "") {
      erros.push("Senha é obrigatório");
    }

    if (erros.length > 0) {
      let msg = "<ul><li><b>" + erros.join("</b></li><li><b>") + "</ul>";
      let alert = this.alertCtrl.create({
        title: "Atenção",
        subTitle: "Erros encontrados:<br />" + msg,
        buttons: ["OK"]
      });
      alert.present();

      return;
    }

    window.localStorage.setItem("meuPitacos", JSON.stringify(this.contaAcesso));
    this.ehExibirForm = false;

    let request: any = {};

    request.email = this.contaAcesso.email;
    request.senha = this.contaAcesso.senha;

    this.loading = this.loadingCtrl.create({
      content: "Aguarde...",
      dismissOnPageChange: false
    });
    this.loading.present();

    this.pitacosService.obterMeusPitacos(request).then(
      (res: any) => {
        if (res != null && res.sucesso) {
          this.pitacosAgrupado = [];
          this.pitacos = res.objeto;

          this.pitacos.forEach(element => {
            if (
              this.pitacosAgrupado.filter(p => p.nome == element.data).length ==
              0
            ) {
              this.pitacosAgrupado.push({
                nome: element.data,
                itens: [],
                pontos: null
              });
            }

            let grupo = this.pitacosAgrupado.filter(
              p => p.nome == element.data
            )[0];

            if (element.pontos.indexOf("Ponto") != -1) {
              if (grupo.pontos == null) {
                grupo.pontos = parseInt(element.pontos.split(" ")[0].trim());
              } else {
                grupo.pontos += parseInt(element.pontos.split(" ")[0].trim());
              }
            }

            grupo.itens.push(element);
            grupo.expanded = grupo.nome == this.diaHoje;

            this.pitacosAgrupado[
              this.pitacosAgrupado.findIndex(a => a.nome == grupo.nome)
            ] = grupo;
          });
        }

        this.loading.dismiss();
      },
      err => {
        this.loading.dismiss();
      }
    );
  }

  exibirAlerta(msg: string) {
    let alert = this.alertCtrl.create({
      title: "Atenção",
      subTitle: msg,
      buttons: ["OK"]
    });
    alert.present();
  }

  editarPitaco(pitaco: any) {
    let alert = this.alertCtrl.create({
      title: pitaco.timeA + " x " + pitaco.timeB,
      cssClass: "alert-input-wrapper-pitacos",
      inputs: [
        {
          name: "placarA",
          placeholder: pitaco.timeA,
          type: "tel",
          value: pitaco.placarA,
          label: pitaco.timeA
        },
        {
          name: "placarB",
          placeholder: pitaco.timeB,
          type: "tel",
          value: pitaco.placarB,
          label: pitaco.timeB
        }
      ],
      buttons: [
        {
          text: "Cancelar",
          role: "cancel",
          handler: data => {
            console.log("Cancel clicked");
          }
        },
        {
          text: "Salvar",
          handler: data => {
            if (data.placarA == "" || data.placarB == "") {
              this.exibirAlerta("Os placares dos times são obrigatórios!");
              return false;
            }

            this.pitacosService
              .salvarPlacar({
                email: this.contaAcesso.email,
                senha: this.contaAcesso.senha,
                id: pitaco.id,
                placarA: data.placarA,
                placarB: data.placarB
              })
              .then(
                (res: any) => {
                  if (res != null && res.objeto) {
                    pitaco.placarA = data.placarA;
                    pitaco.placarB = data.placarB;

                    return true;
                  }
                },
                err => {
                  return false;
                }
              );
          }
        }
      ]
    });
    alert.present();
  }

  expandItem(item: any) {
    this.pitacosAgrupado.forEach(listGrupo => {
      if (listGrupo.nome == item.nome) {
        listGrupo.expanded = !listGrupo.expanded;
      } else {
        listGrupo.expanded = false;
      }
    });
  }

  ajuda() {
    let alert = this.alertCtrl.create({
      title: "Ajuda",
      subTitle:
        "Os campos 'E-mail' e 'Senha' são os mesmo utilizados para acessar o site ou aplicativo do Pitacos Online.",
      buttons: ["OK"]
    });
    alert.present();
  }
}
