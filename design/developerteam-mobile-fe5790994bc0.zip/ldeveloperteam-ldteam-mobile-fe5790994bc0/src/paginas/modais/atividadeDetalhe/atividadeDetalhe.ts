import { Component } from "@angular/core";
import { NavParams, ViewController } from "ionic-angular";
declare var Appsee: any;

@Component({
  selector: "page-atividadeDetalhe",
  templateUrl: "atividadeDetalhe.html"
})
export class AtividadeDetalheModal {
  evento: any = {};

  constructor(params: NavParams, private viewCtrl: ViewController) {
    this.evento = params.get("evento");

    if (this.evento != null && this.evento.saldoMinutos != null) {
      let h = Math.floor(this.evento.saldoMinutos / 60);
      let m = this.evento.saldoMinutos % 60;
      let sH = h < 10 ? "0" + h : h;
      let sM = m < 10 ? "0" + m : m;
      this.evento.jornadaHora = sH + ":" + sM;
    }

    console.log(this.evento);

    if (typeof Appsee !== "undefined")
      Appsee.startScreen("Tela detalhe atividade");
  }

  ionViewWillEnter() {}

  ionViewDidEnter() {}

  fechar() {
    this.viewCtrl.dismiss();
  }
}
