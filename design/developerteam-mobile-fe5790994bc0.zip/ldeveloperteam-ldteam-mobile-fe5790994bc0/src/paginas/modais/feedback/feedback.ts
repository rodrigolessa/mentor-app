import { Component } from "@angular/core";
import {
  ViewController,
  AlertController,
  LoadingController
} from "ionic-angular";
import { Usuario } from "../../../provedores/provedores";
declare var Appsee: any;

@Component({
  selector: "page-feedback",
  templateUrl: "feedback.html"
})
export class FeedbackModal {
  loading = this.loadingCtrl.create({
    content: "Aguarde...",
    dismissOnPageChange: true
  });

  evento: any = {};
  colaborador: any = {};
  mensagem: string = "";

  constructor(
    private viewCtrl: ViewController,
    public alertCtrl: AlertController,
    public loadingCtrl: LoadingController,
    private usuarioService: Usuario
  ) {
    if (typeof Appsee !== "undefined") {
      Appsee.startScreen("Tela feedback");
    }
  }

  ionViewWillEnter() {
    let colaboradorAux = window.localStorage.getItem("colaborador");

    if (colaboradorAux != null && colaboradorAux != "") {
      this.colaborador = JSON.parse(colaboradorAux);
    }
  }

  ionViewDidEnter() {}

  enviar() {
    this.loading = this.loadingCtrl.create({
      content: "Aguarde...",
      dismissOnPageChange: false
    });
    this.loading.present();

    this.usuarioService.enviarFeedback(this.mensagem).then(
      (res: any) => {
        if (res != null && res.sucesso && res.objeto) {
          this.viewCtrl.dismiss();
        }

        this.loading.dismiss();
      },
      err => {
        this.loading.dismiss();
      }
    );
  }

  exibirAlerta(msg: string) {
    let alert = this.alertCtrl.create({
      title: "Atenção",
      subTitle: msg,
      buttons: ["OK"]
    });
    alert.present();
  }

  fechar() {
    this.viewCtrl.dismiss();
  }
}
