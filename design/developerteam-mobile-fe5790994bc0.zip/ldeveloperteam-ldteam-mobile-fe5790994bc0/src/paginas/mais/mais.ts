import { Component } from "@angular/core";
import {
  NavController,
  NavParams,
  AlertController,
  LoadingController,
  ViewController,
  Platform,
  App,
  ModalController
} from "ionic-angular";
import { Util } from "../../shared/util";
import { PerfilPage } from "../perfil/perfil";
import { MeuCartaoPage } from "../meuCartao/meuCartao";
import { PitacosPage } from "../extras/pitacos/pitacos";
import { Pro } from "@ionic/pro";
import { SplashScreenPage } from "../splashScreen/splashScreen";
import { MeusPitacosPage } from "../extras/pitacos/meusPitacos/meusPitacos";
import { FeedbackModal } from "../modais/feedback/feedback";
declare var Appsee: any;

@Component({
  selector: "page-mais",
  templateUrl: "mais.html"
})
export class MaisPage {
  loading = this.loadingCtrl.create({
    content: "Aguarde...",
    dismissOnPageChange: true
  });

  colaborador: any = {};
  Perfil: any = PerfilPage;
  MeuCartao: any = MeuCartaoPage;
  Pitacos: any = PitacosPage;
  MeusPitacos: any = MeusPitacosPage;
  exibirPitacos = false;

  constructor(
    private app: App,
    public navCtrl: NavController,
    public navParams: NavParams,
    public platform: Platform,
    public alertCtrl: AlertController,
    public loadingCtrl: LoadingController,
    public util: Util,
    private viewCtrl: ViewController,
    private modalCtrl: ModalController
  ) {
    if (typeof Appsee !== "undefined") {
      Appsee.startScreen("Tela Mais");
    }
  }

  ionViewWillEnter() {
    this.viewCtrl.showBackButton(true);
  }

  ionViewDidEnter() {
    if (
      window.localStorage.getItem("colaborador") != null &&
      window.localStorage.getItem("colaborador") != ""
    ) {
      this.colaborador = JSON.parse(window.localStorage.getItem("colaborador"));

      if (this.colaborador.fotoUrl == null || this.colaborador.fotoUrl === "") {
        this.colaborador.fotoUrl = "assets/img/LD-PRETO-240X240.png";
      } else {
        if (this.colaborador.fotoUrl.indexOf("http") === -1) {
          this.colaborador.fotoUrl =
            "assets/img/colaborador/" + this.colaborador.fotoUrl;
        }
      }
    }
  }

  ionViewDidLoad() {}

  irPara(page) {
    this.navCtrl.push(page);
  }

  async verficarAtualizacao() {
    this.loading = this.loadingCtrl.create({
      content: "Aguarde...",
      dismissOnPageChange: false
    });
    this.loading.present();

    try {
      let ehAppBeta = JSON.parse(window.localStorage.getItem("ehAppBeta"));

      if (!ehAppBeta) {
        ehAppBeta = JSON.parse(window.localStorage.getItem("ehBeta"));
      }

      const config = {
        appId: "fb4e1808",
        channel: ehAppBeta ? "Beta" : "Production"
      };

      if (!this.platform.is("cordova")) {
      } else {
        await Pro.deploy.init(config);
        let atualizacaoEmProgresso = await Pro.deploy.check();

        if (atualizacaoEmProgresso) {
          let alert = this.alertCtrl.create({
            title: "Atenção",
            message:
              "Existe uma atualização dísponivel, deseja atualizar agora?",
            buttons: [
              {
                text: "Não",
                handler: () => {}
              },
              {
                text: "Sim",
                handler: () => {
                  this.navCtrlUpdate.setRoot(SplashScreenPage);
                }
              }
            ]
          });
          alert.present();
        }
      }
    } catch (err) {
      console.log("erro update", err);
      Pro.monitoring.exception(err);
    }

    this.loading.dismiss();
  }

  get navCtrlUpdate(): NavController {
    return this.app.getRootNav();
  }

  enviarFeedback() {
    let modal = this.modalCtrl.create(FeedbackModal);
    modal.present();
  }

  sair() {
    let alert = this.alertCtrl.create({
      title: "Atenção",
      message: "Deseja realmente retornar para o login?",
      buttons: [
        {
          text: "Não",
          handler: () => {}
        },
        {
          text: "Sim",
          handler: () => {
            if (typeof Appsee !== "undefined") {
              Appsee.addScreenAction("Deslogando do aplicativo");
            }
            this.util.logout();
          }
        }
      ]
    });
    alert.present();
  }
}
