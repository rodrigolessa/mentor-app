import { Component, ViewChild } from "@angular/core";
import {
  NavParams,
  ViewController,
  LoadingController,
  AlertController,
  TextInput
} from "ionic-angular";
import { Usuario } from "../../provedores/provedores";
declare var Appsee: any;

@Component({
  selector: "page-meuCartaoAdicionar",
  templateUrl: "meuCartaoAdicionar.html"
})
export class MeuCartaoAdicionarPage {
  @ViewChild("inputSenha") inputSenha: TextInput;

  loading = this.loadingCtrl.create({
    content: "Aguarde...",
    dismissOnPageChange: true
  });

  evento: any = {};
  contaAcesso: any = {};
  contasAcessos: any[] = [];

  constructor(
    params: NavParams,
    private viewCtrl: ViewController,
    public loadingCtrl: LoadingController,
    public alertCtrl: AlertController,
    private usuarioSerice: Usuario
  ) {
    this.evento = params.get("evento");

    if (typeof Appsee !== "undefined") {
      Appsee.startScreen("Tela novo cartao");
    }
  }

  ionViewWillEnter() {
    this.viewCtrl.showBackButton(false);
  }

  ionViewDidEnter() {
    this.loading = this.loadingCtrl.create({
      content: "Aguarde...",
      dismissOnPageChange: false
    });
    this.loading.present();

    this.obterTiposContasAcessos();
  }

  enterSenha(event) {
    if (event.keyCode === 13) {
      if (this.inputSenha != null) {
        this.inputSenha.setFocus();
      }
    }
  }

  enterAdicionar(event) {
    if (event.keyCode === 13) {
      this.add();
    }
  }

  mask(event) {
    setTimeout(() => {
      var inputTxt = event.value;
      inputTxt = inputTxt ? inputTxt.split(" ").join("") : "";
      inputTxt = inputTxt.length > 16 ? inputTxt.substring(0, 16) : inputTxt;
      this.contaAcesso.numero = this.maskString(inputTxt);
    }, 500);
  }

  maskString(inputTxt) {
    inputTxt = inputTxt.replace(/\D/g, "");
    inputTxt = inputTxt.replace(/(\d{4})(\d)/, "$1 $2");
    inputTxt = inputTxt.replace(/(\d{4})(\d)/, "$1 $2");
    inputTxt = inputTxt.replace(/(\d{4})(\d)/, "$1 $2");
    inputTxt = inputTxt.replace(/(\d{4})(\d)/, "$1 $2");
    return inputTxt;
  }

  obterTiposContasAcessos() {
    this.usuarioSerice.obterTiposContasAcessos().then(
      (tipos: any) => {
        if (tipos != null && tipos.objeto != null) {
          this.contasAcessos = tipos.objeto;
        }

        this.loading.dismiss();
      },
      err => {
        this.loading.dismiss();
      }
    );
  }

  add() {
    let erros: any[] = [];

    if (this.contaAcesso.tipo == null || this.contaAcesso.tipo == "") {
      erros.push("Tipo de acesso é obrigatório");
    } else {
      if (this.contaAcesso.tipo == "tkt") {
        if (this.contaAcesso.email == null || this.contaAcesso.email == "") {
          erros.push("E-mail é obrigatório");
        }
        if (this.contaAcesso.senha == null || this.contaAcesso.senha == "") {
          erros.push("Senha é obrigatório");
        }
      }
    }

    if (erros.length > 0) {
      let msg = "<ul><li><b>" + erros.join("</b></li><li><b>") + "</ul>";
      let alert = this.alertCtrl.create({
        title: "Atenção",
        subTitle: "Erros encontrados:<br />" + msg,
        buttons: ["OK"]
      });
      alert.present();

      return;
    }

    let request: any = {};

    request.CodigoTipoContaAcesso = this.contaAcesso.tipo;
    request.Campos = [];

    if (this.contaAcesso.tipo == "tkt") {
      request.Campos.push({ codigo: "usuario", valor: this.contaAcesso.email });
      request.Campos.push({
        codigo: "senha",
        valor: this.contaAcesso.senha
      });
    }

    this.loading = this.loadingCtrl.create({
      content: "Aguarde...",
      dismissOnPageChange: false
    });
    this.loading.present();

    this.usuarioSerice.adicionarContaAcesso(request).then(
      (res: any) => {
        if (res != null && res.sucesso) {
          this.loading.dismiss();
          this.viewCtrl.dismiss(true);
        }
      },
      err => {
        this.loading.dismiss();
      }
    );
  }

  fechar() {
    this.viewCtrl.dismiss(false);
  }

  ajuda() {
    let alert = this.alertCtrl.create({
      title: "Ajuda",
      subTitle:
        "Os campos 'E-mail' e 'Senha' são os mesmo utilizados para acessar o site ou aplicativo do Ticket. Caso você não tenha feito o cadastro ainda, acesse o site do Ticket e efetue o seu cadastro.",
      buttons: [
        "OK",
        {
          text: "Ir para Site",
          handler: () => {
            window.open(
              "http://www.souticket.com.br",
              "_system",
              "location=yes"
            );
          }
        }
      ]
    });
    alert.present();
  }
}
