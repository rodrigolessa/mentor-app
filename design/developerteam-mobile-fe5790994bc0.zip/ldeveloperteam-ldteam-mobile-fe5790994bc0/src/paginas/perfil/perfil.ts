import { Component } from "@angular/core";
import {
  NavController,
  NavParams,
  AlertController,
  LoadingController,
  ViewController
} from "ionic-angular";
import { Util } from "../../shared/util";
import { Usuario } from "../../provedores/provedores";
declare var Appsee: any;

@Component({
  selector: "page-perfil",
  templateUrl: "perfil.html"
})
export class PerfilPage {
  loading = this.loadingCtrl.create({
    content: "Aguarde...",
    dismissOnPageChange: true
  });

  colaborador: any = {};

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public alertCtrl: AlertController,
    public loadingCtrl: LoadingController,
    public util: Util,
    private viewCtrl: ViewController,
    private usuarioService: Usuario
  ) {
    if (typeof Appsee !== "undefined") {
      Appsee.startScreen("Tela Perfil");
    }
  }

  ionViewWillEnter() {
    this.viewCtrl.showBackButton(true);
  }

  ionViewDidEnter() {}

  maskTelString(inputTxt) {
    let length = inputTxt.length;

    inputTxt = inputTxt.replace(/\D/g, "");
    inputTxt = inputTxt.replace(/(\d{2})(\d)/, "($1) $2");
    if (length == 11) {
      inputTxt = inputTxt.replace(/(\d{5})(\d)/, "$1-$2");
    } else {
      inputTxt = inputTxt.replace(/(\d{4})(\d)/, "$1-$2");
    }

    return inputTxt;
  }

  ionViewDidLoad() {
    this.loading = this.loadingCtrl.create({
      content: "Aguarde...",
      dismissOnPageChange: false
    });
    this.loading.present();

    this.usuarioService.obter().then(
      (resp: any) => {
        window.localStorage.setItem(
          "colaborador",
          JSON.stringify(resp.objeto)
        );
        if (typeof Appsee !== "undefined") {
          Appsee.setUserId(resp.objeto.nome);
        }

        if (
          window.localStorage.getItem("colaborador") != null &&
          window.localStorage.getItem("colaborador") != ""
        ) {
          this.colaborador = JSON.parse(
            window.localStorage.getItem("colaborador")
          );
         
          if (
            this.colaborador.fotoUrl == null ||
            this.colaborador.fotoUrl === ""
          ) {
            this.colaborador.fotoUrl = "assets/img/LD-PRETO-240X240.png";
          }
          else{
            if (this.colaborador.fotoUrl.indexOf("http") === -1) {
              this.colaborador.fotoUrl =
                "assets/img/colaborador/" + this.colaborador.fotoUrl;
            }
          }

          this.colaborador.celular = this.maskTelString(
            this.colaborador.celular
          );

          this.colaborador.ehAppBeta = JSON.parse(
            window.localStorage.getItem("ehBeta")
          );

          this.loading.dismiss();
        }
      },
      err => {
        if (
          window.localStorage.getItem("colaborador") != null &&
          window.localStorage.getItem("colaborador") != ""
        ) {
          this.colaborador = JSON.parse(
            window.localStorage.getItem("colaborador")
          );

          if (
            this.colaborador.fotoUrl == null ||
            this.colaborador.fotoUrl === ""
          ) {
            this.colaborador.fotoUrl = "assets/img/LD-PRETO-240X240.png";
          }
          else{
            if (this.colaborador.fotoUrl.indexOf("http") === -1) {
              this.colaborador.fotoUrl =
                "assets/img/colaborador/" + this.colaborador.fotoUrl;
            }
          }

          this.colaborador.celular = this.maskTelString(
            this.colaborador.celular
          );

          this.colaborador.ehAppBeta = JSON.parse(
            window.localStorage.getItem("ehBeta")
          );

          this.loading.dismiss();
        }
      }
    );
  }

  salvarBeta() {
    window.localStorage.setItem(
      "ehBeta",
      JSON.stringify(this.colaborador.ehAppBeta)
    );

    this.util.verificarAtualizacao();
  }
}
