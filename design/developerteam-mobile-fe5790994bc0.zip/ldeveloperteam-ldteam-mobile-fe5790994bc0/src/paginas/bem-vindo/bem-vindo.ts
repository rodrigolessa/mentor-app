import { Component, ViewChild, ElementRef } from "@angular/core";
import {
  NavController,
  MenuController,
  ToastController,
  AlertController,
  LoadingController,
  TextInput
} from "ionic-angular";
import { Usuario } from "../../provedores/provedores";
import { TabsPage } from "../tabs/tabs";
import { PushNotification } from "../../shared/pushNotification";
declare var Appsee: any;

@Component({
  selector: "page-bem-vindo",
  templateUrl: "bem-vindo.html"
})
export class BemVindoPage {
  @ViewChild("inputSenha") inputSenha: TextInput;
  @ViewChild("divInformacoes") divInformacoes: ElementRef;

  colaborador = { email: "", password: "" };

  constructor(
    public menu: MenuController,
    public usuario: Usuario,
    public toastCtrl: ToastController,
    public alertCtrl: AlertController,
    public loadingCtrl: LoadingController,
    private navCtrl: NavController,
    private pushNotification: PushNotification
  ) {
    if (typeof Appsee !== "undefined") {
      Appsee.startScreen("Tela Login");
    }
  }

  entrar() {
    let loading = this.loadingCtrl.create({
      content: "Aguarde...",
      dismissOnPageChange: true
    });

    if (this.ehValidoEntrar()) {
      loading.present();

      this.usuario.login(this.colaborador).then(
        (resp: any) => {
          window.localStorage.setItem("token", resp.objeto.token);
          window.localStorage.setItem(
            "colaborador",
            JSON.stringify(resp.objeto.colaborador)
          );

          if (typeof Appsee !== "undefined") {
            Appsee.setUserId(resp.objeto.colaborador.nome);
          }

          this.pushNotification.definirTag("usuario", resp.objeto.colaborador.email.split("@")[0]);
          this.pushNotification.definirTag("departamento", resp.objeto.colaborador.departamento);
          this.navCtrl.setRoot(TabsPage);
        },
        err => {
          loading.dismiss();
        }
      );
    }
  }

  enterUsuario(event) {
    if (event.keyCode === 13) {
      if (this.inputSenha != null) {
        this.inputSenha.setFocus();
      }
    }
  }

  enterLogar(event) {
    if (event.keyCode === 13) {
      this.entrar();
    }
  }

  ehValidoEntrar() {
    let msgs = [];
    // let regexp = new RegExp(
    //   /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    // );

    if (this.colaborador.email == null || this.colaborador.email === "") {
      msgs.push("Usuario é obrigatório.");
    } /*else if (!regexp.test(this.funcionario.email)) {
      msgs.push("E-mail é inválido. Digite novamente.");
    }*/
    if (this.colaborador.password == null || this.colaborador.password === "") {
      msgs.push("Senha é obrigatória.");
    }

    if (msgs.length > 0) {
      let msg = "<ul><li><b>" + msgs.join("</b></li><li><b>") + "</ul>";
      let alert = this.alertCtrl.create({
        title: "Atenção",
        subTitle: "Erros encontrados:<br />" + msg,
        buttons: ["OK"]
      });
      alert.present();
    }

    return msgs.length === 0;
  }

  ajuda() {
    let alert = this.alertCtrl.create({
      title: "Ajuda",
      subTitle:
        "Os campos 'Usuário' e 'Senha' são os mesmo utilizados para acessar as máquinas da empresa.",
      buttons: ["OK"]
    });
    alert.present();
  }

  ionViewWillEnter() {}

  ionViewDidEnter() {
    window.localStorage.setItem("tutorialCompleto", "true");
  }

  esconderInformacoes() {
    this.divInformacoes.nativeElement.classList.add("esconder");
  }

  mostrarInformacoes() {
    this.divInformacoes.nativeElement.classList.remove("esconder");
  }
}
