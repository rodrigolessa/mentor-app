import { HttpClientModule } from "@angular/common/http";
import { ErrorHandler, NgModule, Injectable, Injector } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { SplashScreen } from "@ionic-native/splash-screen";
import { StatusBar } from "@ionic-native/status-bar";
import { IonicApp, IonicErrorHandler, IonicModule } from "ionic-angular";

import { BrowserAnimationsModule } from "@angular/platform-browser/animations";

import { LDApp } from "./app.component";
import { Api, Usuario, CalendarioService } from "../provedores/provedores";
import { FormsModule } from "@angular/forms";
import { MaterialModule } from "../shared/material.module";
import { MatPaginatorIntl } from "@angular/material";
import { MatPaginatorIntlCro } from "./app.utilities";
import { TabsPage } from "../paginas/tabs/tabs";
import { BemVindoPage } from "../paginas/bem-vindo/bem-vindo";
import { ResumoPage } from "../paginas/resumo/resumo";
import { TutorialPage } from "../paginas/tutorial/tutorial";
import { ContatoPage } from "../paginas/contato/contato";
import { PerfilPage } from "../paginas/perfil/perfil";
import { HttpModule } from "@angular/http";
import { SplashScreenPage } from "../paginas/splashScreen/splashScreen";
import { Util } from "../shared/util";
import { MaisPage } from "../paginas/mais/mais";
import { MeuCartaoPage } from "../paginas/meuCartao/meuCartao";
import { Network } from "@ionic-native/network";
import { ExpandableComponent } from "../shared/components/expandable/expandable";
import { NativePageTransitions } from "@ionic-native/native-page-transitions";
import localePt from "@angular/common/locales/pt";
import { LOCALE_ID } from "@angular/core";
import { registerLocaleData } from "@angular/common";
import { OneSignal } from "@ionic-native/onesignal";
import { PushNotification } from "../shared/pushNotification";
import { Pro } from "@ionic/pro";
import { MeuCartaoAdicionarPage } from "../paginas/meuCartaoAdicionar/meuCartaoAdicionar";
import { AtividadeDetalheModal } from "../paginas/modais/atividadeDetalhe/atividadeDetalhe";
import { CalendarioPage } from "../paginas/calendario/calendario";
import { CalendarioAdicionarModal } from "../paginas/modais/calendarioAdicionar/calendarioAdicionar";
import { Calendar } from "@ionic-native/calendar";
import { PitacosService } from "../provedores/extra/pitacos";
import { PitacosPage } from "../paginas/extras/pitacos/pitacos";
import { MeusPitacosPage } from "../paginas/extras/pitacos/meusPitacos/meusPitacos";
import { FeedbackModal } from "../paginas/modais/feedback/feedback";

registerLocaleData(localePt);

Pro.init("fb4e1808", {
  appVersion: "1.1.1"
});

@Injectable()
export class MyErrorHandler implements ErrorHandler {
  ionicErrorHandler: IonicErrorHandler;
  constructor(injector: Injector) {
    try {
      this.ionicErrorHandler = injector.get(IonicErrorHandler);
    } catch (e) {}
  }

  handleError(err: any): void {
    console.log("err");
    Pro.monitoring.handleNewError(err);
    this.ionicErrorHandler && this.ionicErrorHandler.handleError(err);
  }
}

@NgModule({
  declarations: [
    LDApp,
    SplashScreenPage,
    TutorialPage,
    BemVindoPage,
    TabsPage,
    ContatoPage,
    CalendarioPage,
    PerfilPage,
    ResumoPage,
    MaisPage,
    AtividadeDetalheModal,
    MeuCartaoAdicionarPage,
    MeuCartaoPage,
    PitacosPage,
    MeusPitacosPage,
    CalendarioAdicionarModal,
    FeedbackModal,
    ExpandableComponent
  ],
  imports: [
    MaterialModule,
    FormsModule,
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    HttpModule,
    IonicModule.forRoot(LDApp, {
      tabsHideOnSubPages: true,
      scrollAssist: true,
      autoFocusAssist: true
    })
  ],
  exports: [MaterialModule],
  bootstrap: [IonicApp],
  entryComponents: [
    LDApp,
    SplashScreenPage,
    TutorialPage,
    BemVindoPage,
    TabsPage,
    ContatoPage,
    CalendarioPage,
    PerfilPage,
    ResumoPage,
    MaisPage,
    AtividadeDetalheModal,
    MeuCartaoAdicionarPage,
    MeuCartaoPage,
    PitacosPage,
    MeusPitacosPage,
    CalendarioAdicionarModal,
    FeedbackModal,
    ExpandableComponent
  ],
  providers: [
    Api,
    OneSignal,
    Util,
    Usuario,
    SplashScreen,
    StatusBar,
    CalendarioService,
    PitacosService,
    Network,
    NativePageTransitions,
    PushNotification,
    IonicErrorHandler,
    Calendar,
    { provide: ErrorHandler, useClass: MyErrorHandler },
    { provide: MatPaginatorIntl, useClass: MatPaginatorIntlCro },
    { provide: LOCALE_ID, useValue: "pt" }
  ]
})
export class AppModule {}
