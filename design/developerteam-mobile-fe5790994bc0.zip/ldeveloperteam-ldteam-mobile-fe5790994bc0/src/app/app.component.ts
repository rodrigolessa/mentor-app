import { Component, ViewChild } from "@angular/core";
import { SplashScreen } from "@ionic-native/splash-screen";
import { StatusBar } from "@ionic-native/status-bar";
import { Config, Platform, AlertController, Nav, App } from "ionic-angular";
import { SplashScreenPage } from "../paginas/splashScreen/splashScreen";
import { Keyboard } from "ionic-angular/platform/keyboard";
import { PushNotification } from "../shared/pushNotification";
declare let Appsee: any;

@Component({
  templateUrl: "app.html"
})
export class LDApp {
  @ViewChild(Nav) nav: Nav;
  rootPage: any = SplashScreenPage;
  showedAlert: boolean;
  confirmAlert: any;

  constructor(
    private platform: Platform,
    private config: Config,
    private statusBar: StatusBar,
    private splashScreen: SplashScreen,
    private alertCtrl: AlertController,
    private app: App,
    private keyboard: Keyboard,
    private pushNotification: PushNotification
  ) {
    this.initializeApp();
  }

  initializeApp() {
    this.platform.ready().then(() => {
      console.log("App carregou!");

      this.splashScreen.hide();
      this.statusBar.styleDefault();
      this.pushNotification.init();

      if (this.platform.is("cordova")) {
        document.body.classList.add("isCordova");
      }

      this.keyboard.willShow.subscribe(() => {
        document.body.classList.add("keyboard-open");
      });

      this.keyboard.willHide.subscribe(() => {
        document.body.classList.remove("keyboard-open");
      });

      window.addEventListener("native.keyboardshow", function () {
        document.body.classList.add("keyboard-open");
      });

      window.addEventListener("native.keyboardhide", function () {
        document.body.classList.remove("keyboard-open");
      });

      this.platform.registerBackButtonAction((e: any) => {
        let nav = this.app.getActiveNavs()[0];
        let activeView = nav.getActive();

        if (activeView != null) {
          if (nav.canGoBack()) nav.pop();
          else if (typeof activeView.instance.backButtonAction === "function")
            activeView.instance.backButtonAction();
          else {
            if (!this.showedAlert) {
              this.confirmExitApp();
            } else {
              this.showedAlert = false;
              this.confirmAlert.dismiss();
            }
          }
        }
      });

      if (typeof Appsee !== "undefined")
        Appsee.start("24abb4cdb9dc46f6a9b2c217ab0f16ec");
    });

    this.config.set("ios", "backButtonText", "Voltar");
  }

  confirmExitApp() {
    this.showedAlert = true;

    this.confirmAlert = this.alertCtrl.create({
      title: "Sair",
      message: "Você deseja realmente sair do aplicativo?",
      buttons: [
        {
          text: "Não",
          handler: () => {
            this.showedAlert = false;
            return;
          }
        },
        {
          text: "Sim",
          handler: () => {
            if (typeof Appsee !== "undefined") {
              Appsee.addScreenAction("Fechando o aplicativo no botão voltar");
            }
            this.platform.exitApp();
          }
        }
      ]
    });

    this.confirmAlert.present();
  }
}
