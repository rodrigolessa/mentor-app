export interface ItemCalendario {
  Nome: string;
  DataInicio: Date;
  DataFim: Date;
  FoiCancelado: boolean;
  Local: string;
  Organizador: string;
  Link: string;
  StatusResposta: string;
}
