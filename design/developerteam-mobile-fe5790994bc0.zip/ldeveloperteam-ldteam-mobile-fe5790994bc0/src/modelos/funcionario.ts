export interface Funcionario {
  nome: string;
  dataNacimento: Date;
  ramal: number;
  celular: number;
  token: string;
}
