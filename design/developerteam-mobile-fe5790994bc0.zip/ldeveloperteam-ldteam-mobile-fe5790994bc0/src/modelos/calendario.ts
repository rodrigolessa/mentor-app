import { ItemCalendario } from "./itemCalendario";

export interface Calendario {
  Nome: string;
  Itens: ItemCalendario[];
  Cor: string;
}
