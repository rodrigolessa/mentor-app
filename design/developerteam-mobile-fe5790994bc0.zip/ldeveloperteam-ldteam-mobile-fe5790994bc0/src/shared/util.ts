import "rxjs/add/operator/toPromise";
import { Injectable } from "@angular/core";
import { App, NavController } from "ionic-angular";
import { SplashScreenPage } from "../paginas/splashScreen/splashScreen";

@Injectable()
export class Util {
  constructor(private app: App) {}

  get navCtrl(): NavController {
    return this.app.getRootNav();
  }

  logout() {
    window.localStorage.removeItem("token");
    window.localStorage.removeItem("funcionario");
    this.navCtrl.setRoot(SplashScreenPage);
  }

  verificarAtualizacao() {
    this.navCtrl.setRoot(SplashScreenPage);
  }

  formataData(valor: string) {
    let aux = valor.split("/");
    aux[1] = aux[1][0] == "0" ? aux[1][1] : aux[1];

    return new Date(aux.reverse().join("/"));
  }

  dataAtualFormatada() {
    let data = new Date();
    let ano = data.getFullYear();
    let mes = data.getMonth() + 1;
    let dia = data.getDate();

    return new Date(`${ano}/${mes}/${dia}`);
  }

  dataAtualFormatadaTexto() {
    let data = new Date();
    let ano = data.getFullYear();
    let mes =
      data.getMonth() + 1 < 10
        ? "0" + (data.getMonth() + 1)
        : data.getMonth() + 1;
    let dia = data.getDate();

    return `${dia}/${mes}/${ano}`;
  }

  dataAtualFormatadaCompletaSemAnoTexto() {
    let data = new Date();
    let mes =
      data.getMonth() + 1 < 10
        ? "0" + (data.getMonth() + 1)
        : data.getMonth() + 1;
    let dia = data.getDate() + 1 < 10 ? "0" + data.getDate() : data.getDate();

    return `${dia}/${mes}`;
  }

  dataAtualFormatadaSemAnoTexto() {
    let data = new Date();
    let mes =
      data.getMonth() + 1 < 10
        ? "0" + (data.getMonth() + 1)
        : data.getMonth() + 1;
    let dia = data.getDate();

    return `${dia}/${mes}`;
  }
}
