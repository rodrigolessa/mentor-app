import {
    MatTooltipModule,
    MatChipsModule,
    MatDialogModule,
    MatProgressSpinnerModule,
    MatButtonModule,
    MatInputModule,
    MatCheckboxModule,
    MatSidenavModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatCardModule,
    MatDividerModule,
    MatExpansionModule,
    MatGridListModule,
    MatTabsModule,
    MatListModule,
    MatSelectModule,
    MatSlideToggleModule,
    MatAutocompleteModule,
    MatDatepickerModule,
    MatFormFieldModule,
    MatMenuModule,
    MatToolbarModule,
    MatIconModule
  } from "@angular/material";
import { NgModule } from "@angular/core";
  
  const MaterialModules = [
    MatTooltipModule,
    MatChipsModule,
    MatDialogModule,
    MatProgressSpinnerModule,
    MatButtonModule,
    MatInputModule,
    MatCheckboxModule,
    MatSidenavModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatCardModule,
    MatDividerModule,
    MatExpansionModule,
    MatGridListModule,
    MatTabsModule,
    MatListModule,
    MatSelectModule,
    MatSlideToggleModule,
    MatAutocompleteModule,
    MatDatepickerModule,
    MatFormFieldModule,
    MatMenuModule,
    MatToolbarModule,
    MatIconModule
  ];

@NgModule({
    imports: [
        MaterialModules,
    ],
    exports: [
        MaterialModules
    ],
    declarations: [
    ],
  })
  export class MaterialModule { }