import { OneSignal } from "@ionic-native/onesignal";
import { Injectable } from "@angular/core";
import { Platform } from "ionic-angular";

@Injectable()
export class PushNotification {
  constructor(private platform: Platform, private oneSignal: OneSignal) {}

  init() {
    if (!this.platform.is("cordova")) {
      return;
    }

    this.oneSignal.startInit(
      "f0a14105-c429-41c2-909f-b66be35b7bd4",
      "675873458113"
    );

    this.oneSignal.inFocusDisplaying(
      this.oneSignal.OSInFocusDisplayOption.None
    );

    this.oneSignal.handleNotificationReceived().subscribe((jsonData: any) => {
      // do something when notification is received
      console.log("notificationReceivedCallback: " + JSON.stringify(jsonData));
    });

    this.oneSignal.handleNotificationOpened().subscribe((jsonData: any) => {
      // let alert = this.alertCtrl.create({
      //   title: jsonData.notification.payload.title,
      //   subTitle: jsonData.notification.payload.body,
      //   buttons: ["OK"]
      // });
      // alert.present();
      console.log("notificationOpenedCallback: " + JSON.stringify(jsonData));
    });

    this.oneSignal.endInit();

    this.oneSignal.promptForPushNotificationsWithUserResponse().then(
      (data: any) => {
        console.log("permissão push: " + JSON.stringify(data));
      },
      (erro: any) => {
        console.log("Erro permissão push: " + JSON.stringify(erro));
      }
    );

    this.oneSignal.getPermissionSubscriptionState().then(
      (data: any) => {
        console.log("Status permissão push: " + JSON.stringify(data));
      },
      (erro: any) => {
        console.log("Erro status permissão push: " + JSON.stringify(erro));
      }
    );
  }

  definirTag(tag: string, valor: string) {
    this.oneSignal.sendTag(tag, valor);
  }
}
