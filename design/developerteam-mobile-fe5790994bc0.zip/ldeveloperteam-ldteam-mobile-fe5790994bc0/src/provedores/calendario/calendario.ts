import "rxjs/add/operator/toPromise";
import "rxjs/add/operator/delay";
import { Injectable } from "@angular/core";
import { Api } from "../api/api";
import {
  ToastController,
  NavController,
  App
} from "ionic-angular";
import { HttpHeaders } from "@angular/common/http";
import { Util } from "../../shared/util";
import "rxjs/add/operator/timeout";
import { Observable } from "rxjs/Observable";
import { Subject } from "rxjs/Subject";

@Injectable()
export class CalendarioService {
  _controller: string = "api/calendario/";

  constructor(
    public api: Api,
    public toastCtrl: ToastController,
    private app: App,
    private util: Util
  ) {}

  get navCtrl(): NavController {
    return this.app.getRootNav();
  }

  obterCalendario(dataInicial?: Date, dataFinal?: Date): Observable<any> {
    if (dataInicial == null) {
      dataInicial = new Date();
    }
    if (dataFinal == null) {
      dataFinal = new Date();
      dataFinal.setDate(dataFinal.getDate() + 7);
    }

    let token = window.localStorage.getItem("token");

    let headers = new HttpHeaders();
    headers = headers.set("Content-Type", "application/json; charset=utf-8");
    headers = headers.set("Authorization", `Bearer ${token}`);
    headers = headers.set("CodigoEmpresa", "ldsoft");

    var pollSubject = new Subject<any>();

    this.api
      .get(
        `${
          this._controller
        }?dataInicial=${dataInicial.toISOString()}&dataFinal=${dataFinal.toISOString()}`,
        null,
        { headers: headers }
      )
      .subscribe(
        (res: any) => {
          if (res.sucesso == true) {
            pollSubject.next(res.objeto);
          } else {
            if (!res.autorizado) {
              this.util.logout();
            } else {
              pollSubject.next(res.objeto);
            }
          }
        },
        err => {
          console.error("ERRO", err);

          let erro = "Algo deu errado ao tentar obter o calendario!";
          this.api.exibirErros([erro], true);
          pollSubject.next();
        }
      );

    return pollSubject.asObservable();
  }

  obterCalendarioRecorrente(
    dataInicial?: Date,
    dataFinal?: Date
  ): Observable<any> {
    if (dataInicial == null) {
      dataInicial = new Date();
    }
    if (dataFinal == null) {
      dataFinal = new Date();
      dataFinal.setDate(dataFinal.getDate() + 7);
    }

    let token = window.localStorage.getItem("token");

    let headers = new HttpHeaders();
    headers = headers.set("Content-Type", "application/json; charset=utf-8");
    headers = headers.set("Authorization", `Bearer ${token}`);
    headers = headers.set("CodigoEmpresa", "ldsoft");

    var pollSubject = new Subject<any>();

    var subscribeToNewRequestObservable = () => {
      this.api
        .get(
          `${
            this._controller
          }?dataInicial=${dataInicial.toISOString()}&dataFinal=${dataFinal.toISOString()}`,
          null,
          { headers: headers }
        )
        .subscribe(
          (res: any) => {
            if (res.sucesso == true) {
              pollSubject.next(res.objeto);
            } else {
              if (!res.autorizado) {
                this.util.logout();
              } else {
                pollSubject.next(res.objeto);
              }
            }
          },
          err => {
            console.error("ERRO", err);
            pollSubject.next();
          }
        );
    };

    pollSubject.delay(5000).subscribe(subscribeToNewRequestObservable);

    subscribeToNewRequestObservable();

    return pollSubject.asObservable();
  }
}
