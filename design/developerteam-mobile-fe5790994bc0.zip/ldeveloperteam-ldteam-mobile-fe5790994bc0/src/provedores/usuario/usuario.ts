import "rxjs/add/operator/toPromise";
import { Injectable } from "@angular/core";
import { Api } from "../api/api";
import { ToastController, App, NavController } from "ionic-angular";
import "rxjs/add/operator/timeout";
import { HttpHeaders } from "@angular/common/http";

@Injectable()
export class Usuario {
  _usuario: any;
  _controller: string = "api/autenticacao/";
  _controllerFuncionario: string = "api/funcionario/";
  _controllerPonto: string = "api/ponto/";

  constructor(
    public api: Api,
    public toastCtrl: ToastController,
    private app: App
  ) {}

  get navCtrl(): NavController {
    return this.app.getRootNav();
  }

  login(accountInfo: any) {
    let headers = new HttpHeaders();
    headers = headers.set("Content-Type", "application/json; charset=utf-8");
    headers = headers.set("CodigoEmpresa", "ldsoft");

    let promise = new Promise((resolve, reject) => {
      this.api
        .post(
          this._controller + "efetuarLogin",
          {
            Usuario: accountInfo.email,
            Senha: accountInfo.password
          },
          { headers: headers }
        )
        .timeout(30000)
        .subscribe(
          (res: any) => {
            if (res.sucesso == true) {
              resolve(res);
            } else {
              this.api.exibirErros(res.mensagens);
              reject(res.mensagens);
            }
          },
          err => {
            console.error("ERRO", err);

            let erro = "Algo deu errado ao tentar efetuar o login!";
            this.api.exibirErros([erro]);
            reject(erro);
          }
        );
    });

    return promise;
  }

  obter() {
    let token = window.localStorage.getItem("token");

    let headers = new HttpHeaders();
    headers = headers.set("Content-Type", "application/json; charset=utf-8");
    headers = headers.set("Authorization", `Bearer ${token}`);
    headers = headers.set("CodigoEmpresa", "ldsoft");

    let promise = new Promise((resolve, reject) => {
      this.api
        .get(this._controllerFuncionario, null, { headers: headers })
        .timeout(30000)
        .subscribe(
          (res: any) => {
            if (res.sucesso == true) {
              resolve(res);
            } else {
              reject(res.mensagens);
            }
          },
          err => {
            console.error("ERRO", err);

            let erro = "Algo deu errado ao tentar efetuar o login!";
            reject(erro);
          }
        );
    });

    return promise;
  }

  obterColaboradores() {
    let token = window.localStorage.getItem("token");

    let headers = new HttpHeaders();
    headers = headers.set("Content-Type", "application/json; charset=utf-8");
    headers = headers.set("Authorization", `Bearer ${token}`);
    headers = headers.set("CodigoEmpresa", "ldsoft");

    let promise = new Promise((resolve, reject) => {
      this.api
        .get(this._controllerFuncionario + "listar", null, { headers: headers })
        .timeout(20000)
        .subscribe(
          (res: any) => {
            if (res.sucesso == true) {
              resolve(res);
            } else {
              reject(res.mensagens);
            }
          },
          err => {
            console.error("ERRO", err);

            let erro = "Algo deu errado ao tentar obter os colaboradores!";
            // this.api.exibirErros([erro]);
            reject(erro);
          }
        );
    });

    return promise;
  }

  obterFelicitacoes() {
    let token = window.localStorage.getItem("token");

    let headers = new HttpHeaders();
    headers = headers.set("Content-Type", "application/json; charset=utf-8");
    headers = headers.set("Authorization", `Bearer ${token}`);
    headers = headers.set("CodigoEmpresa", "ldsoft");

    let promise = new Promise((resolve, reject) => {
      this.api
        .get(this._controllerFuncionario + "listarFelicitacoes", null, {
          headers: headers
        })
        .timeout(20000)
        .subscribe(
          (res: any) => {
            if (res.sucesso == true) {
              resolve(res);
            } else {
              reject(res.mensagens);
            }
          },
          err => {
            console.error("ERRO", err);

            let erro = "Algo deu errado ao tentar obter as felicitações!";
            this.api.exibirErros([erro], true);
            reject(erro);
          }
        );
    });

    return promise;
  }

  obterAniversariantes() {
    let token = window.localStorage.getItem("token");

    let headers = new HttpHeaders();
    headers = headers.set("Content-Type", "application/json; charset=utf-8");
    headers = headers.set("Authorization", `Bearer ${token}`);
    headers = headers.set("CodigoEmpresa", "ldsoft");

    let promise = new Promise((resolve, reject) => {
      this.api
        .get(this._controllerFuncionario + "listarAniversariantes", null, {
          headers: headers
        })
        .timeout(20000)
        .subscribe(
          (res: any) => {
            if (res.sucesso == true) {
              resolve(res);
            } else {
              reject(res.mensagens);
            }
          },
          err => {
            console.error("ERRO", err);

            let erro = "Algo deu errado ao tentar obter os aniversáriantes!";
            this.api.exibirErros([erro], true);
            reject(erro);
          }
        );
    });

    return promise;
  }

  adicionarFelicitacao(felicitacao: any) {
    let token = window.localStorage.getItem("token");

    let headers = new HttpHeaders();
    headers = headers.set("Content-Type", "application/json; charset=utf-8");
    headers = headers.set("Authorization", `Bearer ${token}`);
    headers = headers.set("CodigoEmpresa", "ldsoft");

    let promise = new Promise((resolve, reject) => {
      this.api
        .post(
          this._controllerFuncionario + "adicionarFelicitacao",
          felicitacao,
          {
            headers: headers
          }
        )
        .timeout(20000)
        .subscribe(
          (res: any) => {
            if (res.sucesso == true) {
              resolve(res);
            } else {
              this.api.exibirErros(res.mensagens);
              reject(res.mensagens);
            }
          },
          err => {
            console.error("ERRO", err);

            let erro = "Algo deu errado ao tentar adicionar a felicitação!";
            this.api.exibirErros([erro]);
            reject(erro);
          }
        );
    });

    return promise;
  }

  enviarFeedback(msg: string) {
    let token = window.localStorage.getItem("token");

    let headers = new HttpHeaders();
    headers = headers.set("Content-Type", "application/json; charset=utf-8");
    headers = headers.set("Authorization", `Bearer ${token}`);
    headers = headers.set("CodigoEmpresa", "ldsoft");

    let promise = new Promise((resolve, reject) => {
      this.api
        .get(this._controllerFuncionario + "enviarFeedback?mensagem=" + msg, null, {
          headers: headers
        })
        .timeout(20000)
        .subscribe(
          (res: any) => {
            if (res.sucesso == true) {
              resolve(res);
            } else {
              this.api.exibirErros(res.mensagens);
              reject(res.mensagens);
            }
          },
          err => {
            console.error("ERRO", err);

            let erro = "Algo deu errado ao tentar enviar feedback!";
            this.api.exibirErros([erro]);
            reject(erro);
          }
        );
    });

    return promise;
  }

  salvarTokenPushNotification(tokenPush: string) {
    let token = window.localStorage.getItem("token");

    let headers = new HttpHeaders();
    headers = headers.set("Content-Type", "application/json; charset=utf-8");
    headers = headers.set("Authorization", `Bearer ${token}`);
    headers = headers.set("CodigoEmpresa", "ldsoft");

    let promise = new Promise((resolve, reject) => {
      this.api
        .post(
          this._controllerFuncionario + "salvarTokenPushNotification",
          tokenPush,
          {
            headers: headers
          }
        )
        .timeout(20000)
        .subscribe(
          (res: any) => {
            if (res.sucesso == true) {
              resolve(res);
            } else {
              // this.api.exibirErros(res.mensagens);
              reject(res.mensagens);
            }
          },
          err => {
            console.error("ERRO", err);

            let erro =
              "Algo deu errado ao tentar salvar o token do push notification";
            // this.api.exibirErros([erro]);
            reject(erro);
          }
        );
    });

    return promise;
  }

  adicionarContaAcesso(contaAcesso: any) {
    let token = window.localStorage.getItem("token");

    let headers = new HttpHeaders();
    headers = headers.set("Content-Type", "application/json; charset=utf-8");
    headers = headers.set("Authorization", `Bearer ${token}`);
    headers = headers.set("CodigoEmpresa", "ldsoft");

    let promise = new Promise((resolve, reject) => {
      this.api
        .post(
          this._controllerFuncionario + "adicionarContaAcesso",
          contaAcesso,
          {
            headers: headers
          }
        )
        .timeout(20000)
        .subscribe(
          (res: any) => {
            if (res.sucesso == true) {
              resolve(res);
            } else {
              this.api.exibirErros(res.mensagens);
              reject(res.mensagens);
            }
          },
          err => {
            console.error("ERRO", err);

            let erro = "Algo deu errado ao tentar adicionar a conta de acesso!";
            this.api.exibirErros([erro]);
            reject(erro);
          }
        );
    });

    return promise;
  }

  removerContaAcesso(idContaAcesso: number) {
    let token = window.localStorage.getItem("token");

    let headers = new HttpHeaders();
    headers = headers.set("Content-Type", "application/json; charset=utf-8");
    headers = headers.set("Authorization", `Bearer ${token}`);
    headers = headers.set("CodigoEmpresa", "ldsoft");

    let promise = new Promise((resolve, reject) => {
      this.api
        .delete(
          this._controllerFuncionario +
            "removerContaAcesso?id=" +
            idContaAcesso,
          {
            headers: headers
          }
        )
        .timeout(20000)
        .subscribe(
          (res: any) => {
            if (res.sucesso == true) {
              resolve(res);
            } else {
              this.api.exibirErros(res.mensagens);
              reject(res.mensagens);
            }
          },
          err => {
            console.error("ERRO", err);

            let erro = "Algo deu errado ao tentar remover a conta de acesso!";
            this.api.exibirErros([erro]);
            reject(erro);
          }
        );
    });

    return promise;
  }

  obterTiposContasAcessos() {
    let token = window.localStorage.getItem("token");

    let headers = new HttpHeaders();
    headers = headers.set("Content-Type", "application/json; charset=utf-8");
    headers = headers.set("Authorization", `Bearer ${token}`);
    headers = headers.set("CodigoEmpresa", "ldsoft");

    let promise = new Promise((resolve, reject) => {
      this.api
        .get(this._controllerFuncionario + "obterTiposContasAcessos", null, {
          headers: headers
        })
        .timeout(20000)
        .subscribe(
          (res: any) => {
            if (res.sucesso == true) {
              resolve(res);
            } else {
              this.api.exibirErros(res.mensagens);
              reject(res.mensagens);
            }
          },
          err => {
            console.error("ERRO", err);

            let erro =
              "Algo deu errado ao tentar obter os tipos de conta de acesso!";
            this.api.exibirErros([erro], true);
            reject(erro);
          }
        );
    });

    return promise;
  }

  obterContasAcesso() {
    let token = window.localStorage.getItem("token");

    let headers = new HttpHeaders();
    headers = headers.set("Content-Type", "application/json; charset=utf-8");
    headers = headers.set("Authorization", `Bearer ${token}`);
    headers = headers.set("CodigoEmpresa", "ldsoft");

    let promise = new Promise((resolve, reject) => {
      this.api
        .get(this._controllerFuncionario + "obterContasAcesso", null, {
          headers: headers
        })
        .timeout(20000)
        .subscribe(
          (res: any) => {
            if (res.sucesso == true) {
              resolve(res);
            } else {
              // this.api.exibirErros(res.mensagens);
              reject(res.mensagens);
            }
          },
          err => {
            console.error("ERRO", err);

            let erro = "Algo deu errado ao tentar obter as contas de acesso!";
            // this.api.exibirErros([erro], true);
            reject(erro);
          }
        );
    });

    return promise;
  }

  obterCartoesTicket() {
    let token = window.localStorage.getItem("token");

    let headers = new HttpHeaders();
    headers = headers.set("Content-Type", "application/json; charset=utf-8");
    headers = headers.set("Authorization", `Bearer ${token}`);
    headers = headers.set("CodigoEmpresa", "ldsoft");

    let promise = new Promise((resolve, reject) => {
      this.api
        .get(this._controllerFuncionario + "obterCartoesTicket", null, {
          headers: headers
        })
        .timeout(20000)
        .subscribe(
          (res: any) => {
            if (res.sucesso == true) {
              resolve(res);
            } else {
              // this.api.exibirErros(res.mensagens);
              reject(res.mensagens);
            }
          },
          err => {
            console.error("ERRO", err);

            let erro = "Algo deu errado ao tentar obter os cartões do ticket!";
            // this.api.exibirErros([erro], true);
            reject(erro);
          }
        );
    });

    return promise;
  }

  obterSaldoPonto() {
    let token = window.localStorage.getItem("token");

    let headers = new HttpHeaders();
    headers = headers.set("Content-Type", "application/json; charset=utf-8");
    headers = headers.set("Authorization", `Bearer ${token}`);
    headers = headers.set("CodigoEmpresa", "ldsoft");

    let promise = new Promise((resolve, reject) => {
      this.api
        .get(this._controllerPonto + "obterSaldo", null, { headers: headers })
        .timeout(20000)
        .subscribe(
          (res: any) => {
            if (res.sucesso == true) {
              resolve(res);
            } else {
              this.api.exibirErros(res.mensagens, true);
              reject(res.mensagens);
            }
          },
          err => {
            console.error("ERRO", err);

            let erro = "Algo deu errado ao tentar obter o saldo do ponto!";
            this.api.exibirErros([erro], true);
            reject(erro);
          }
        );
    });

    return promise;
  }

  obterConsumoPonto(dataInicial?: Date, dataFinal?: Date) {
    let token = window.localStorage.getItem("token");
    let dataString =
      dataInicial != null
        ? `?dataInicial=${dataInicial.toISOString()}&dataFinal=${dataFinal.toISOString()}`
        : "";
    let headers = new HttpHeaders();
    headers = headers.set("Content-Type", "application/json; charset=utf-8");
    headers = headers.set("Authorization", `Bearer ${token}`);
    headers = headers.set("CodigoEmpresa", "ldsoft");

    let promise = new Promise((resolve, reject) => {
      this.api
        .get(this._controllerPonto + "obterConsumo" + dataString, null, {
          headers: headers
        })
        .timeout(20000)
        .subscribe(
          (res: any) => {
            if (res.sucesso == true) {
              resolve(res);
            } else {
              this.api.exibirErros(res.mensagens, true);
              reject(res.mensagens);
            }
          },
          err => {
            console.error("ERRO", err);

            let erro = "Algo deu errado ao tentar obter o consumo do ponto!";
            this.api.exibirErros([erro], true);
            reject(erro);
          }
        );
    });

    return promise;
  }

  obterErrosPonto() {
    let token = window.localStorage.getItem("token");

    let headers = new HttpHeaders();
    headers = headers.set("Content-Type", "application/json; charset=utf-8");
    headers = headers.set("Authorization", `Bearer ${token}`);
    headers = headers.set("CodigoEmpresa", "ldsoft");

    let promise = new Promise((resolve, reject) => {
      this.api
        .get(this._controllerPonto + "obterErrosPonto", null, {
          headers: headers
        })
        .timeout(20000)
        .subscribe(
          (res: any) => {
            if (res.sucesso == true) {
              resolve(res);
            } else {
              this.api.exibirErros(res.mensagens, true);
              reject(res.mensagens);
            }
          },
          err => {
            console.error("ERRO", err);

            let erro = "Algo deu errado ao tentar obter os erros de ponto!";
            this.api.exibirErros([erro], true);
            reject(erro);
          }
        );
    });

    return promise;
  }

  _logar(funcionario) {
    this._usuario = funcionario;
  }
}
