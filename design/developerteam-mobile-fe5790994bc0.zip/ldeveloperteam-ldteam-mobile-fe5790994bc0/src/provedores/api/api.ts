import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { AlertController } from "ionic-angular";
import { Network } from "@ionic-native/network";

@Injectable()
export class Api {
  _tempoUltimaAlerta: Date;
  url: string = "http://interno.ldsoft.com.br:4080/ldteam";
  //url: string = "http://192.168.0.17/ldteam";
  //url: string = "http://localhost:5000";
  //url: string = "http://localhost:59688";

  constructor(
    public http: HttpClient,
    public alertCtrl: AlertController,
    private network: Network
  ) {}

  get(endpoint: string, params?: any, reqOpts?: any) {
    if (!reqOpts) {
      reqOpts = {
        params: new HttpParams()
      };
    }

    if (params) {
      reqOpts.params = new HttpParams();
      for (let k in params) {
        reqOpts.params = reqOpts.params.set(k, params[k]);
      }
    }

    return this.http.get(this.url + "/" + endpoint, reqOpts);
  }

  post(endpoint: string, body: any, reqOpts?: any) {
    return this.http.post(this.url + "/" + endpoint, body, reqOpts);
  }

  put(endpoint: string, body: any, reqOpts?: any) {
    return this.http.put(this.url + "/" + endpoint, body, reqOpts);
  }

  delete(endpoint: string, reqOpts?: any) {
    return this.http.delete(this.url + "/" + endpoint, reqOpts);
  }

  patch(endpoint: string, body: any, reqOpts?: any) {
    return this.http.patch(this.url + "/" + endpoint, body, reqOpts);
  }

  exibirErros(erros: string[], msgPadrao?: boolean) {
    let tempoFinal = new Date();
    tempoFinal.setSeconds(tempoFinal.getSeconds() - 50);

    if (
      this._tempoUltimaAlerta == null ||
      this._tempoUltimaAlerta < tempoFinal ||
      !msgPadrao
    ) {
      let text = "";

      if (
        this.network.type != null &&
        (this.network.type == "unknown" ||
          this.network.type == "none" ||
          this.network.type == "2g")
      ) {
        text =
          "Ops! Não foi possível carregar algumas informações. Verifiquei sua conexão de internet";
      } else {
        text = "Ops! Tivemos um problema ao obter as informações";
      }

      if (msgPadrao) {
        this._tempoUltimaAlerta = new Date();
      }

      let msg = "<ul><li><b>" + erros.join("</b></li><li><b>") + "</ul>";
      let alert = this.alertCtrl.create({
        title: "Atenção",
        subTitle: msgPadrao ? text : "Erros encontrados:<br />" + msg,
        buttons: ["OK"]
      });
      alert.present();
    }
  }
}
