import "rxjs/add/operator/toPromise";
import { Injectable } from "@angular/core";
import { Api } from "../api/api";
import { ToastController, App, NavController } from "ionic-angular";
import "rxjs/add/operator/timeout";
import { HttpHeaders } from "@angular/common/http";

@Injectable()
export class PitacosService {
  _usuario: any;
  _controller: string = "api/extra/pitacos/";

  constructor(
    public api: Api,
    public toastCtrl: ToastController,
    private app: App
  ) {}

  get navCtrl(): NavController {
    return this.app.getRootNav();
  }

  obterRanking() {
    let token = window.localStorage.getItem("token");

    let headers = new HttpHeaders();
    headers = headers.set("Content-Type", "application/json; charset=utf-8");
    headers = headers.set("Authorization", `Bearer ${token}`);
    headers = headers.set("CodigoEmpresa", "ldsoft");

    let promise = new Promise((resolve, reject) => {
      this.api
        .get(this._controller + "obterRanking", null, { headers: headers })
        .timeout(20000)
        .subscribe(
          (res: any) => {
            if (res.sucesso == true) {
              resolve(res);
            } else {
              reject(res.mensagens);
            }
          },
          err => {
            console.error("ERRO", err);

            let erro =
              "Algo deu errado ao tentar obter as colocações do bolão!";
            // this.api.exibirErros([erro]);
            reject(erro);
          }
        );
    });

    return promise;
  }

  obterMeusPitacos(request: any) {
    let token = window.localStorage.getItem("token");

    let headers = new HttpHeaders();
    headers = headers.set("Content-Type", "application/json; charset=utf-8");
    headers = headers.set("Authorization", `Bearer ${token}`);
    headers = headers.set("CodigoEmpresa", "ldsoft");

    let promise = new Promise((resolve, reject) => {
      this.api
        .get(
          this._controller +
            "obterMeusPitacos?email=" +
            request.email +
            "&senha=" +
            request.senha,
          null,
          { headers: headers }
        )
        .timeout(20000)
        .subscribe(
          (res: any) => {
            if (res.sucesso == true) {
              resolve(res);
            } else {
              this.api.exibirErros(res.mensagens);
              reject(res.mensagens);
            }
          },
          err => {
            console.error("ERRO", err);

            let erro = "Algo deu errado ao tentar obter os lançes do bolão!";
            this.api.exibirErros([erro]);
            reject(erro);
          }
        );
    });

    return promise;
  }

  salvarPlacar(request: any) {
    let token = window.localStorage.getItem("token");

    let headers = new HttpHeaders();
    headers = headers.set("Content-Type", "application/json; charset=utf-8");
    headers = headers.set("Authorization", `Bearer ${token}`);
    headers = headers.set("CodigoEmpresa", "ldsoft");

    let promise = new Promise((resolve, reject) => {
      this.api
        .get(
          this._controller +
            "salvarPlacar?email=" +
            request.email +
            "&senha=" +
            request.senha +
            "&id=" +
            request.id +
            "&placarA=" +
            request.placarA +
            "&placarB=" +
            request.placarB,
          null,
          { headers: headers }
        )
        .timeout(20000)
        .subscribe(
          (res: any) => {
            if (res.sucesso == true) {
              resolve(res);
            } else {
              this.api.exibirErros(res.mensagens);
              reject(res.mensagens);
            }
          },
          err => {
            console.error("ERRO", err);

            let erro = "Algo deu errado ao tentar salvar os lançes do bolão!";
            this.api.exibirErros([erro]);
            reject(erro);
          }
        );
    });

    return promise;
  }
}
